using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class BorosAbility : Ability
{
    public List<Tile> summonTiles;
    public float howManyminions;
    public float minionHp;
    public float minionDamage;
    public float minionDefence;
    public float minionCrit;
    public float moveSpeed;
    public float minionAttackSpeed;

    private void Start()
    {
        cooldownTimer = 8;
    }
    public override void Effect()
    {
        summonTiles.Clear();
        for (int i = 0; i < howManyminions; i++) SummonMinion();
    }
    public void SummonMinion()
    {
        Boros b = (Boros)character;
        Minion w = Instantiate(b.minion, b.transform);
        w.move = w.GetComponent<Move>();
        w.transform.SetParent(DungeonManager.instance.currentDungeon.currentEncounter.transform);
        w.move.character = w;
        DungeonManager.instance.currentDungeon.currentEncounter.bossMinionSummons.Add(w);
        w.transform.SetParent(DungeonManager.instance.currentDungeon.currentEncounter.transform);
        Tile t = FindTile.instance.FindClosestUnoccupiedTileAdjacentToTarget(target.move.currentTile, character.move.currentTile, summonTiles);
        summonTiles.Add(t);
        w.transform.position = t.transform.position;
        w.move.CurrentTile();
        w.move.on = true;
        w.playerUI = w.GetComponent<CharacterUI>();        
        w.AbilityAdd(AbilityList.instance.basicAttack);
        w.ability[0].character = w;
        w.characterName = "minion " + summonTiles.Count.ToString();
        w.move.prevPosition = w.transform.position;
        w.health = w.maxHealth.baseValue = w.GetComponent<Minion>().maxHealth.baseValue = minionHp;
        w.movement.baseValue = moveSpeed;
        w.defence.baseValue = minionDefence;
        w.damage.baseValue = minionDamage;
        w.crit.baseValue = minionCrit;
        w.ability[0].castTime = minionAttackSpeed;
        w.name = $"Local Tough";
    }
}
