using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class ArcanosEncounter : EncounterFeatures
{
    public override void SpawnPOI()
    {
        base.SpawnPOI();
        Pillar(3, 4);
        Pillar(4, 4);
        Pillar(5, 4);
    }

    private void Pillar(int v1, int v2)
    {
        List<Tile> tileList = GetComponent<Encounter>().tileList;
        foreach (Tile t in tileList)
        {
            if (t.x == v1 && t.y == v2)
            {
                t.id = 2;
                t.GetComponent<SpriteRenderer>().sprite = SpriteList.instance.arcanosPillar;
                t.pic = SpriteList.instance.arcanosPillar;
                break;
            }
        }
        
    }
}