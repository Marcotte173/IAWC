using System.Linq;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UIElements;

public class ArcanosAbility : Ability
{
    public int abilityChoice = 0;
    public float timer;
    public float width;
    public float length;
    public List<float> threshhold;
    public int fireBlasts;
    public float fireBlastDamage;
    public float aoeDamage;
    private void Start()
    {
        cooldownTimer = 0;
    }
    public override void Effect()
    {
        if (abilityChoice == 0)
        {
            character.target = target = null;
            verb = "Circle of Flames";
            //FireBlast Ability
            int maxBlast = (DungeonManager.instance.currentDungeon.currentEncounter.Player().Count >= fireBlasts) ? fireBlasts : DungeonManager.instance.currentDungeon.currentEncounter.Player().Count;
            List<Character> targets = new List<Character> { };
            while (maxBlast > 0)
            {
                Character a = DungeonManager.instance.currentDungeon.currentEncounter.Player()[Random.Range(0, DungeonManager.instance.currentDungeon.currentEncounter.Player().Count)];
                if (!targets.Contains(a))
                {
                    targets.Add(a);
                    maxBlast--;
                }
            }
            Debug.Log(targets.Count);
            foreach(Character a in targets)
            {
                Projectile p = Instantiate(GameObjectList.instance.enemyProjectile, character.transform);
                p.transform.position = character.transform.position;
                p.GetComponent<SpriteRenderer>().sprite = SpriteList.instance.fireblast;
                p.speed = 7f;
                p.damage = fireBlastDamage;
                p.target = a;
                p.projectileName = "Fire Blast";
                p.attacker = character;
            }
            abilityChoice = 1;
        }
        else
        {
            verb = "FireBlast";
            //Circle of Flames Ability
            OrcHazard r = Instantiate(GameObjectList.instance.orcHazard, DungeonManager.instance.currentDungeon.currentEncounter.transform);
            r.transform.position = character.target.transform.position;
            r.timer = timer;
            r.threshHold = threshhold.ToList();
            r.damage = aoeDamage;
            r.attacker = character;
            r.threat = threat;
            r.transform.localScale = new Vector3(width, length);
            r.Timer();
            abilityChoice = 0;
        }
    }
}
