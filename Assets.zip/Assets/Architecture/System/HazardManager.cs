using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class HazardManager : MonoBehaviour
{
    public static HazardManager instance;
    private void Awake()
    {
        instance = this;
    }
    private void Update()
    {
        if(EncounterManager.instance.currentEncounter != null)
        {
            if(EncounterManager.instance.currentEncounter.raidMode == RaidMode.Combat)
            {
                if (EncounterManager.instance.currentEncounter.playerHazards.Count > 0)
                {
                    foreach (Hazard h in EncounterManager.instance.currentEncounter.playerHazards)
                    {
                        h.agents.Clear();
                        foreach (Agent a in EncounterManager.instance.currentEncounter.BossAndMinion())
                        {
                            if (h.tiles.Contains(a.GetComponent<Move>().currentTile))
                            {
                                h.agents.Add(a);
                            }
                        }
                    }
                }
            }            
        }        
    }
}
