using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class CreateAgent : MonoBehaviour
{
    public static CreateAgent instance;
    public int characterIdCounter;
    public int bossIdCounter;
    private void Awake()
    {
        instance = this;        
    }
    public void CreatePlayers()
    {
        for (int i = 0; i < 2; i++) CreateNewPlayer(0,1.7f,2.6f);
        for (int i = 0; i < 2; i++) CreateNewPlayer(1,1.7f,2.6f);
        for (int i = 0; i < 2; i++) CreateNewPlayer(2,1.7f,2.6f);
        for (int i = 0; i < 2; i++) CreateNewPlayer(3,1.7f,2.6f);
        for (int i = 0; i < 2; i++) CreateNewPlayer(4,1.7f,2.6f);
        for (int i = 0; i < 2; i++) CreateNewPlayer(5,1.7f,2.6f);
    
    }

    public void CreateNewPlayer(int x,float min, float max)
    {
        Player p = Instantiate(GameObjectList.instance.player, transform);
        Move m = p.GetComponent<Move>();
        GameObject g = Instantiate(GameObjectList.instance.agent, p.transform);        
        Class c = null;
        string name = Names.instance.userName[UnityEngine.Random.Range(0, Names.instance.userName.Count)];       
        Names.instance.userName.Remove(name);
        if (name == "FemboyEthnoState")
        {
            name = Names.instance.userName[UnityEngine.Random.Range(0, Names.instance.userName.Count)];
            Names.instance.userName.Remove(name);
        }
        //Create specific class and give skill
        if (x == 0)
        {
            g.AddComponent<Beserker>();
            g.AddComponent<BeserkerDecision>();
            c = g.GetComponent<Beserker>();
            p.beserkerSkill = (float)Math.Round(UnityEngine.Random.Range(min, max), 1);
        }
        if (x == 1)
        {
            g.AddComponent<Druid>();
            g.AddComponent<DruidDecision>();
            c = g.GetComponent<Druid>();
            p.druidSkill = (float)Math.Round(UnityEngine.Random.Range(min, max), 1);
        }
        if (x == 2)
        {
            g.AddComponent<Rogue>();
            g.AddComponent<RogueDecision>();
            c = g.GetComponent<Rogue>();
            p.rogueSkill = (float)Math.Round(UnityEngine.Random.Range(min, max), 1);
        }
        if (x == 3)
        {
            g.AddComponent<Mage>();
            g.AddComponent<MageDecision>();
            c = g.GetComponent<Mage>();
            p.mageSkill = (float)Math.Round(UnityEngine.Random.Range(min, max), 1);
        }
        if (x == 4)
        {
            g.AddComponent<ShieldBearer>();
            g.AddComponent<ShieldBearerDecision>();
            c = g.GetComponent<ShieldBearer>();
            p.shieldBearerSkill = (float)Math.Round(UnityEngine.Random.Range(min, max), 1);
        }
        if (x == 5)
        {
            g.AddComponent<Bard>();
            g.AddComponent<BardDecision>();
            c = g.GetComponent<Bard>();
            p.bardSkill = (float)Math.Round(UnityEngine.Random.Range(min, max), 1);
        }
        //Add to main list
        CharacterList.instance.charactersInTheGame.Add(p);
        //Character Set Up
        c.weapon.character = c;        
        c.chest.character = c;
        c.legs.character = c;
        c.feet.character = c;
        c.trinket.character = c;
        c.weapon.character = c;
        c.offHand.character = c;
        c.ability = new List<Ability>();
        c.headSets = new List<ItemSO>();
        c.chestSets = new List<ItemSO>();
        c.legSets = new List<ItemSO>();
        c.feetSets = new List<ItemSO>();
        c.trinketSets = new List<ItemSO>();
        c.weaponSets = new List<ItemSO>();
        c.offHandSets = new List<ItemSO>();
        c.buff = new List<Effect>();
        c.debuff = new List<Effect>();
        c.maxHealth = new CharacterAttribute();
        c.maxMana = new CharacterAttribute();
        c.defence = new CharacterAttribute();
        c.attackPower = new CharacterAttribute();
        c.spellpower = new CharacterAttribute();
        c.damage = new CharacterAttribute();
        c.crit = new CharacterAttribute();
        c.vamp = new CharacterAttribute();
        c.movement = new CharacterAttribute();
        c.haste = new CharacterAttribute();
        c.thorns = new CharacterAttribute();
        c.manaRegenTime = new CharacterAttribute();
        c.manaRegenValue = new CharacterAttribute();
        c.physicalDamageMod = new CharacterAttribute();
        c.magicDamageMod = new CharacterAttribute();
        c.manaRegenMod = new CharacterAttribute();
        c.damageTakenMod = new CharacterAttribute();
        c.healingMod = new CharacterAttribute();
        c.energyCostMod = new CharacterAttribute();        
        p.move = m;
        p.mainClass = c;
        m.character = c;
        m.player = p;
        c.move = m;
        c.player = p;
        c.playerUI = p.playerUI;
        p.id = c.id = characterIdCounter;
        characterIdCounter++;
        p.playerName = name;
        c.characterName = p.playerName;
        p.SetUpChar(c, p, m);           
        p.Main();
        p.UpdateName();
        p.ambition = UnityEngine.Random.Range(0,p.currentSkill*20+10);
        p.ambition = p.ambition > 99 ? 99 : p.ambition;
        p.GetAvailabilty();
        int traitRoll = UnityEngine.Random.Range(1,101);
        if(traitRoll >90)
        {
            List<int> available = new List<int> { };
            for (int i = 0; i < GameObjectList.instance.traits.Count; i++) available.Add(i);
            int a = available[UnityEngine.Random.Range(0, available.Count)];
            available.Remove(a);
            int b = available[UnityEngine.Random.Range(0, available.Count)];
            AddTrait(a,p);
            AddTrait(b,p);
        }
        else if (traitRoll > 70) AddTrait(UnityEngine.Random.Range(0, GameObjectList.instance.traits.Count),p);        
        c.playerUI.GetComponent<SpriteRenderer>().sprite = c.GetComponent<SpriteRenderer>().sprite = SpriteList.instance.characters[(int)c.species];
        c.SpriteOff();
        c.name = c.characterName;
    }

    private void AddTrait(int a,Player p)
    {
        Trait trait = Instantiate(GameObjectList.instance.traits[a],p.transform);
        trait.player = p;
        trait.name = trait.traitName = GameObjectList.instance.traits[a].name;
        if (trait.immediate) trait.Effect();
        p.traits.Add(trait);
    }
}
