using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class CreateAgent : MonoBehaviour
{
    public static CreateAgent instance;
    public int characterIdCounter;
    public int bossIdCounter;
    private void Awake()
    {
        instance = this;        
    }
    public void CreatePlayers()
    {
        for (int i = 0; i < Names.instance.warriorPlayerList.Count; i++) CreateNewWoLPlayer(GameObjectList.instance.beserker, Names.instance.warriorPlayerList[i], Names.instance.warriorCharacterList[i]);
        for (int i = 0; i < Names.instance.priestPlayerList.Count; i++) CreateNewWoLPlayer(GameObjectList.instance.druid, Names.instance.priestPlayerList[i], Names.instance.priestCharacterList[i]);
        for (int i = 0; i < Names.instance.roguePlayerList.Count; i++) CreateNewWoLPlayer(GameObjectList.instance.rogue, Names.instance.roguePlayerList[i], Names.instance.rogueCharacterList[i]);
        for (int i = 0; i < Names.instance.magePlayerList.Count; i++) CreateNewWoLPlayer(GameObjectList.instance.mage, Names.instance.magePlayerList[i], Names.instance.mageCharacterList[i]);
        for (int i = 0; i < Names.instance.paladinPlayerList.Count; i++) CreateNewWoLPlayer(GameObjectList.instance.shieldBearer, Names.instance.paladinPlayerList[i], Names.instance.paladinCharacterList[i]);
        for (int i = 0; i < Names.instance.druidPlayerList.Count; i++) CreateNewWoLPlayer(GameObjectList.instance.bard, Names.instance.druidPlayerList[i], Names.instance.druidCharacterList[i]);
    }

    public void CreateNewWoLPlayer(Agent agent,string playerName, string characterName)
    {
        Agent a = Instantiate(agent,transform);     
        CharacterList.instance.charactersInTheGame.Add(a);
        Class core = a.GetComponent<Class>();    
        core.characterName = characterName;
        core.characterNameText.text = "";
        a.GetComponent<Player>().playerName = playerName;
        a.name = $"{characterName} - {Utility.instance.Class(a)} - {a.GetComponent<Character>().Score()}";        
    }
}
