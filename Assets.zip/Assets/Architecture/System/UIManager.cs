using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class UIManager : MonoBehaviour
{
    public static UIManager instance;
    public GameObject menu;
    public GameObject events;
    public GameObject guild;
    public Image background;
    private void Start()
    {
        instance = this;
        Menu();
    }
    public void Menu()
    {
        Utility.instance.TurnOn(background.gameObject);
        global::Recruit.instance.leftPage = 0;
        global::Recruit.instance.rightPage = 0;
        global::Menu.instance.pve = false;
        global::Recruit.instance.pveLoad = false;
        global::Recruit.instance.recruit = false;
        global::Recruit.instance.target = null;
        global::Menu.instance.target = null;
        Utility.instance.TurnOff(guild);
        if(events!= null)Utility.instance.TurnOff(events);
        Utility.instance.TurnOn(menu);        
        background.sprite = SpriteList.instance.menuBackGround;
        global::Menu.instance.UpdateButtons();
    }
    public void Recruit()
    {
        Utility.instance.TurnOn(background.gameObject);
        Utility.instance.TurnOff(menu);
        if (events != null) Utility.instance.TurnOff(events);
        Utility.instance.TurnOn(guild);
        global::Recruit.instance.recruit = true;        
        global::Recruit.instance.UpdateInfo();
    }
    public void ViewGuild() 
    {
        Utility.instance.TurnOn(background.gameObject);
        Utility.instance.TurnOff(menu);
        if (events != null) Utility.instance.TurnOff(events);
        Utility.instance.TurnOn(guild);        
        global::Recruit.instance.UpdateInfo();
    }
    public void PVEMenu()
    {
        Utility.instance.TurnOn(background.gameObject);
        Utility.instance.TurnOn(menu);
        if (events != null) Utility.instance.TurnOff(events);
        Utility.instance.TurnOff(guild);
        global::Menu.instance.pve = true;
        background.sprite = SpriteList.instance.menuBackGround;
        global::Menu.instance.UpdateButtons();
    }
    public void PVELoadStart()
    {
        Utility.instance.TurnOn(background.gameObject);
        Utility.instance.TurnOff(menu);
        if (events != null) Utility.instance.TurnOff(events);
        Utility.instance.TurnOn(guild);
        global::Recruit.instance.pveLoad = true;
        global::Recruit.instance.UpdateInfo();
    }

    public void PVEStart()
    {
        Utility.instance.TurnOff(menu);
        Utility.instance.TurnOff(guild);
        Utility.instance.TurnOff(background.gameObject);
        Utility.instance.TurnOn(events.gameObject);
        //if (global::Menu.instance.target.agentsInEvent.Count == global::Menu.instance.target.maxPlayers) 
        EventManager.instance.Event(0);
    }
}
