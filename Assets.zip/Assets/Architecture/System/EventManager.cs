using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class EventManager : MonoBehaviour
{
    public static EventManager instance;
    public List<Event> pve;
    private void Awake()
    {
        instance = this;
        for (int i = 0; i < pve.Count; i++)
        {
            pve[i] = Instantiate(pve[0], transform) ;
            pve[i].transform.position = new Vector2(0, 0);
            pve[i].name = pve[i].eventName;
            pve[i].agentsInEvent.Clear();
        }
    }

    internal void Event(int x)
    {
        EncounterManager.instance.Begin(Menu.instance.target.encounter[x]);
    }
}
