using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Equip : MonoBehaviour
{
    public static Equip instance;
    private void Awake()
    {
        instance = this;
    }

    public void EquipHead(ItemSO give, Head receive)
    {
        receive.id = give.id;
        receive.itemName = give.itemName;
        receive.rarity = give.rarity;
        receive.type = give.type;        
        receive.health = give.health;
        receive.mana = give.mana;
        receive.defence = give.defence;
        receive.crit = give.crit;
        receive.attackPower = give.attackPower;
        receive.spellpower = give.spellpower;
        receive.score = give.score;
        receive.value = give.value;
        receive.vamp = give.vamp;
        receive.armorType = give.armorType;
    }
    public void EquipChest(ItemSO give, Chest receive)
    {
        receive.id = give.id;
        receive.itemName = give.itemName;
        receive.rarity = give.rarity;
        receive.type = give.type;
        receive.health = give.health;
        receive.mana = give.mana;
        receive.defence = give.defence;
        receive.crit = give.crit;
        receive.attackPower = give.attackPower;
        receive.spellpower = give.spellpower;
        receive.score = give.score;
        receive.value = give.value;
        receive.vamp = give.vamp;
        receive.armorType = give.armorType;
    }
    public void EquipLegs(ItemSO give, Legs receive)
    {
        receive.id = give.id;
        receive.itemName = give.itemName;
        receive.rarity = give.rarity;
        receive.type = give.type;
        receive.health = give.health;
        receive.mana = give.mana;
        receive.defence = give.defence;
        receive.crit = give.crit;
        receive.attackPower = give.attackPower;
        receive.spellpower = give.spellpower;
        receive.score = give.score;
        receive.value = give.value;
        receive.vamp = give.vamp;
        receive.armorType = give.armorType;
    }
    public void EquipFeet(ItemSO give, Feet receive)
    {
        receive.id = give.id;
        receive.itemName = give.itemName;
        receive.rarity = give.rarity;
        receive.type = give.type;
        receive.health = give.health;
        receive.mana = give.mana;
        receive.defence = give.defence;
        receive.crit = give.crit;
        receive.attackPower = give.attackPower;
        receive.spellpower = give.spellpower;
        receive.score = give.score;
        receive.value = give.value;
        receive.vamp = give.vamp;
        receive.armorType = give.armorType;
    }
    public void EquipTrinket(ItemSO give, Trinket receive)
    {
        receive.id = give.id;
        receive.itemName = give.itemName;
        receive.rarity = give.rarity;
        receive.type = give.type;
        receive.health = give.health;
        receive.mana = give.mana;
        receive.defence = give.defence;
        receive.crit = give.crit;
        receive.attackPower = give.attackPower;
        receive.spellpower = give.spellpower;
        receive.score = give.score;
        receive.vamp = give.vamp;
        receive.value = give.value;
    }
    public void EquipWeapon(ItemSO give, Weapon receive)
    {
        receive.id = give.id;
        receive.itemName = give.itemName;
        receive.rarity = give.rarity;
        receive.type = give.type;
        receive.health = give.health;
        receive.mana = give.mana;
        receive.defence = give.defence;
        receive.crit = give.crit;
        receive.attackPower = give.attackPower;
        receive.spellpower = give.spellpower;
        receive.damage = give.damage;
        receive.score = give.score;
        receive.vamp = give.vamp;
        receive.value = give.value;
    }
    public void EquipOffHand(ItemSO give, OffHand receive)
    {
        receive.id = give.id;
        receive.itemName = give.itemName;
        receive.rarity = give.rarity;
        receive.type = give.type;
        receive.health = give.health;
        receive.mana = give.mana;
        receive.defence = give.defence;
        receive.crit = give.crit;
        receive.attackPower = give.attackPower;
        receive.spellpower = give.spellpower;
        receive.damage = give.damage;
        receive.score = give.score;
        receive.vamp = give.vamp;
        receive.value = give.value;
    }
}
