using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class DungeonManager : MonoBehaviour
{
    public static DungeonManager instance;
    public List<Dungeon> pve;
    public Dungeon currentDungeon;    
    public RaidMode raidMode;
    public GameObject dungeonAgents;
    private void Awake()
    {
        instance = this;
        for (int i = 0; i < pve.Count; i++)
        {
            Dungeon e = Instantiate(pve[i], transform);
            e.name = pve[i].DungeonName;
            pve[i] = e; 
        }
    }

    internal void Raid(Dungeon e)
    {
        currentDungeon = e;
        currentDungeon.agentsInDungeon.Clear();
        foreach (Character a in Guild.instance.todaysRoster.roster) LoadInDungeon(a.player);
        currentDungeon.GetComponent<EncounterManager>().Begin(currentDungeon.encounter[currentDungeon.encountersCompleted]);
    }

    internal void TestRaid(Dungeon dungeon, List<Player> players)
    {
        currentDungeon = dungeon;
        currentDungeon.agentsInDungeon.Clear();
        foreach (Player a in players) LoadInDungeon(a);
        currentDungeon.GetComponent<EncounterManager>().Begin(currentDungeon.encounter[currentDungeon.encountersCompleted]);
    }

    public void SendToFight(Player p)
    {
        currentDungeon.currentEncounter.player.Add(p.currentClass);      
        p.transform.SetParent(currentDungeon.currentEncounter.encounterUI.charactersGameObject.transform);
    }
    public void SendToFight(Player p, Vector2 position)
    {
        currentDungeon.currentEncounter.player.Add(p.currentClass);              
        p.transform.SetParent(currentDungeon.currentEncounter.encounterUI.charactersGameObject.transform);
        p.transform.position = position;
    }
    public void SendToFight(Character p)
    {
        currentDungeon.currentEncounter.boss.Add(p);
        p.transform.SetParent(currentDungeon.currentEncounter.encounterUI.charactersGameObject.transform);
    }
    public void SendToFight(Character p, Vector2 position)
    {
        currentDungeon.currentEncounter.boss.Add(p);        
        p.transform.SetParent(currentDungeon.currentEncounter.encounterUI.charactersGameObject.transform);
        p.transform.position = position;
    }
    public void SendHome(Player p)
    {
        if(currentDungeon.currentEncounter.player.Contains(p.currentClass)) currentDungeon.currentEncounter.player.Remove(p.currentClass);
        p.transform.SetParent(GameManager.instance.guild.transform);
    }
    public void LoadInDungeon(Player p)
    {
        currentDungeon.agentsInDungeon.Add(p.currentClass);
        p.transform.SetParent(dungeonAgents.transform);
    }
    public void DungeonToLoad(Character p)
    {
        Guild.instance.todaysRoster.roster.Add(p);
        p.player.transform.SetParent(dungeonAgents.transform);
    }
}
