using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
public enum Meters {Damage,Threat}
public class EncounterUI : MonoBehaviour
{
    public static EncounterUI instance;
    public List<Button> background;
    public List<Button> background2;
    public List<Image> agentPic;
    public List<Text>  agentNameText;
    public List<Text>  agentHealthText;
    public List<Text>  agentManaText;
    public List<Text>  agentActionText;
    public List<Image> enemyPic;
    public List<Text>  enemyNameText;
    public List<Text>  enemyHealthText;
    public List<Text>  enemyManaText;
    public List<Text>  enemyActionText;
    public List<Slider> agentHealthBar;
    public List<Slider> agentManaBar;
    public List<Image> agentMana;
    public List<Slider> enemyHealthBar;
    public List<Slider> enemyManaBar;
    public GameObject preFightBox;
    public List<Text> playerMeter;
    public List<Text> damageMeter;
    public Button damageMeterButton;
    public Button threatMeterButton;
    public Button minimizeMaximiseButton;
    public GameObject meterBox;
    public Meters meter;
    public bool minimized;
    public List<Image> player1Buffs;
    public List<Image> player2Buffs;
    public List<Image> player3Buffs;
    public List<Image> player4Buffs;
    public List<Image> player5Buffs;
    public List<Image> enemy1Buffs;
    public List<Image> enemy2Buffs;
    public List<Image> enemy3Buffs;
    public List<Image> enemy4Buffs;
    public List<Image> enemy5Buffs;

    private void Awake()
    {
        instance = this;
    }
    private void Update()
    {
        if(EncounterManager.instance.currentEncounter.raidMode == RaidMode.Setup|| EncounterManager.instance.currentEncounter.raidMode == RaidMode.Combat)
        {
            TurnOffBackgrounds();
            UpdatePlayerUIs();
            UpdateBossUIs();
            UpdateDamageMeters();
            UpdateThreatMeters();            
        }
    }

    private void UpdateBuffs(List<Image> buffList, Character c)
    {
        foreach (Image i in buffList) i.sprite = SpriteList.instance.none;
        List<Sprite> sList = new List<Sprite> { };
        foreach (Effect e in c.buff) sList.Add(e.sprite);
        foreach (Effect e in c.debuff) sList.Add(e.sprite);
        for (int i = 0; i < sList.Count; i++) buffList[i].sprite = sList[i];
    }

    public void TurnOffBackgrounds()
    {
        foreach (Button b in background) Utility.instance.TurnOff(b.gameObject);
        foreach (Button b in background2) Utility.instance.TurnOff(b.gameObject);
    }

    public void UpdatePlayerUIs()
    {
        for (int i = 0; i < GetComponent<Encounter>().player.Count; i++)
        {
            Agent player = GetComponent<Encounter>().player[i];
            Character core = player.GetComponent<Character>();
            Utility.instance.TurnOn(background[i].gameObject);
            agentPic[i].sprite = (player.ko) ? SpriteList.instance.dead : player.GetComponent<SpriteRenderer>().sprite;
            agentNameText[i].text = player.GetComponent<Character>().characterName;
            agentHealthText[i].text = (player.ko) ? "Dead" : System.Convert.ToInt32(player.GetComponent<Character>().Health()).ToString() + "/" + player.GetComponent<Character>().MaxHealth().ToString();
            agentManaText[i].text = (player.ko) ? "Dead" : player.GetComponent<Character>().Mana().ToString() + "/" + player.GetComponent<Character>().MaxMana().ToString();
            agentHealthBar[i].value = core.Health() / core.MaxHealth();
            agentManaBar[i].value = (core.MaxMana() <= 0) ? 0 : core.Mana() / core.MaxMana();
            agentMana[i].color = (GetComponent<Beserker>()) ? SpriteList.instance.rage : (GetComponent<Rogue>() ? SpriteList.instance.energy : SpriteList.instance.mana);
            agentActionText[i].text = (player.ko) ? "Dead" : core.action;
            UpdateBuffs((i == 0)?player1Buffs: (i == 1) ? player2Buffs:(i == 2) ? player3Buffs:(i == 3) ? player4Buffs: player5Buffs,core);
        }
    }

    public void UpdateBossUIs()
    {
        for (int i = 0; i < GetComponent<Encounter>().boss.Count; i++)
        {
            Agent boss = GetComponent<Encounter>().boss[i];
            Character core = boss.GetComponent<Character>();
            Utility.instance.TurnOn(background2[i].gameObject);
            enemyPic[i].sprite = (boss.ko) ? SpriteList.instance.dead : boss.GetComponent<SpriteRenderer>().sprite;
            enemyNameText[i].text = boss.GetComponent<Character>().characterName;
            enemyHealthBar[i].value = core.Health() / core.MaxHealth();
            enemyManaBar[i].value = (core.MaxMana() <= 0) ? 0 : core.Mana() / core.MaxMana();
            enemyHealthText[i].text = (boss.ko) ? "Dead" : Convert.ToInt32(boss.GetComponent<Character>().Health()).ToString() + "/" + boss.GetComponent<Character>().MaxHealth().ToString();
            enemyManaText[i].text = (boss.ko) ? "Dead" : boss.GetComponent<Character>().Mana().ToString() + "/" + boss.GetComponent<Character>().MaxMana().ToString();
            enemyActionText[i].text = (boss.ko) ? "Dead" : core.action;
            UpdateBuffs((i == 0) ? enemy1Buffs : (i == 1) ? enemy2Buffs : (i == 2) ? enemy3Buffs : (i == 3) ? enemy4Buffs : enemy5Buffs, core);
        }
    }

    public void UpdateDamageMeters()
    {
        if (meter == Meters.Damage)
        {
            List<Character> damageList = new List<Character> { };
            foreach (Agent a in EncounterManager.instance.currentEncounter.player) damageList.Add(a.GetComponent<Character>());
            SortDamage(damageList);
            for (int i = 0; i < damageList.Count; i++)
            {
                playerMeter[i].color = (damageList[i].GetType() == typeof(Beserker)) ? SpriteList.instance.beserker : (damageList[i].GetType() == typeof(Druid)) ? SpriteList.instance.druid : (damageList[i].GetType() == typeof(Bard)) ? SpriteList.instance.bard : (damageList[i].GetType() == typeof(Mage)) ? SpriteList.instance.mage : (damageList[i].GetType() == typeof(Rogue)) ? SpriteList.instance.rogue : SpriteList.instance.shieldBearer;
                playerMeter[i].text = damageList[i].characterName;
                damageMeter[i].text = Mathf.Round(damageList[i].damageDone).ToString();
            }
        }
        if (minimized) minimizeMaximiseButton.GetComponentInChildren<Text>().text = "Meters";
        else minimizeMaximiseButton.GetComponentInChildren<Text>().text = "Minimize";
    }

    public void UpdateThreatMeters()
    {
        if (meter == Meters.Threat)
        {
            foreach (Text t in playerMeter) t.text = "";
            foreach (Text t in damageMeter) t.text = "";
            List<Aggro> aggro = EncounterManager.instance.currentEncounter.Boss()[0].GetComponent<Boss>().aggro;
            if (aggro.Count != 0)
            {
                for (int i = 0; i < aggro.Count; i++)
                {
                    playerMeter[i].color = (aggro[i].agent.GetComponent<Beserker>()) ? SpriteList.instance.beserker : (aggro[i].agent.GetComponent<Druid>()) ? SpriteList.instance.druid : (aggro[i].agent.GetComponent<Bard>()) ? SpriteList.instance.bard : (aggro[i].agent.GetComponent<Mage>()) ? SpriteList.instance.mage : (aggro[i].agent.GetComponent<Rogue>()) ? SpriteList.instance.rogue : SpriteList.instance.shieldBearer;
                    playerMeter[i].text = aggro[i].agent.GetComponent<Character>().characterName;
                    damageMeter[i].text = Mathf.Round(aggro[i].aggro).ToString();
                }
            }
        }
    }

    public void FightBoxButton()
    {
        if(EncounterManager.instance.currentEncounter.raidMode == RaidMode.Setup)
        {
            Utility.instance.TurnOff(preFightBox.gameObject);
            EncounterManager.instance.currentEncounter.raidMode = RaidMode.Combat;
        }
        else if (EncounterManager.instance.currentEncounter.raidMode == RaidMode.After)
        {
            Utility.instance.TurnOff(preFightBox.gameObject);
            EncounterManager.instance.currentEncounter.raidMode = RaidMode.Off;
            if (EncounterManager.instance.currentEncounter.Player().Count == 0)
            {
                UIManager.instance.Menu();
            }
            else
            {
                //Rewards
            }

        }
    }
    private void SortDamage(List<Character> list)
    {
        Character temp;
        for (int j = 0; j <= list.Count - 2; j++)
        {
            for (int i = 0; i <= list.Count - 2; i++)
            {
                if (list[i].damageDone < list[i + 1].damageDone)
                {
                    temp = list[i + 1];
                    list[i + 1] = list[i];
                    list[i] = temp;
                }
            }
        }
    }
    public void DamageNumbersOn()
    {
        meter = Meters.Damage;
    }
    public void ThreatNumbersOn()
    {
        meter = Meters.Threat;
    }
    public void MinMax()
    {
        if (minimized)
        {
            Utility.instance.TurnOn(meterBox.gameObject);
            minimized = false;
        }
        else
        {
            Utility.instance.TurnOff(meterBox.gameObject);
            minimized = true;
        }
    }
}