using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class Menu : MonoBehaviour
{
    public static Menu instance;
    public bool pve;
    public Button backButton;
    public Image pveBox;
    public Text pveTitle;
    public List<Text> pveDescription;
    public Text gearScoreNumber;
    public List<Button> buttons;
    public Event target;
   
    private void Awake()
    {
        instance = this;
    }
    public void UpdateButtons()
    {
        if (!pve)
        {
            Utility.instance.TurnOff(pveBox.gameObject);
            Utility.instance.TurnOff(backButton.gameObject);
            foreach (Button b in buttons) Utility.instance.TurnOn(b.gameObject);
            buttons[0].GetComponentInChildren<Text>().text = "Recruit";
            buttons[1].GetComponentInChildren<Text>().text = "Guild Information";
            buttons[2].GetComponentInChildren<Text>().text = "PvE";
            buttons[3].GetComponentInChildren<Text>().text = "Take A Night Off";
            buttons[4].GetComponentInChildren<Text>().text = "Buy Items";
            buttons[5].GetComponentInChildren<Text>().text = "Use Items";
            buttons[6].GetComponentInChildren<Text>().text = "View Other Guilds";
            buttons[7].GetComponentInChildren<Text>().text = "Help";
        }
        else
        {
            Utility.instance.TurnOn(backButton.gameObject);
            if (target == null) Utility.instance.TurnOff(pveBox.gameObject);
            else
            {
                Utility.instance.TurnOn(pveBox.gameObject);
                gearScoreNumber.text = target.recommendedGearScore.ToString();
                pveTitle.text = target.eventName;
                for (int i = 0; i < target.description.Count; i++) pveDescription[i].text = target.description[i];
            }
            foreach (Button b in buttons) Utility.instance.TurnOff(b.gameObject);
            for (int i = 0; i < EventManager.instance.pve.Count; i++)
            {
                Utility.instance.TurnOn(buttons[i].gameObject);
                buttons[i].GetComponentInChildren<Text>().text = EventManager.instance.pve[i].eventName;
            }
        }
    }

    public void BackToMenu()
    {
        pve = false;
        UIManager.instance.background.sprite = SpriteList.instance.menuBackGround;
        UpdateButtons();
    }

    public void ButtonOne()
    {
        if (pve)
        {
            target = EventManager.instance.pve[0];
            UIManager.instance.background.sprite = SpriteList.instance.pveBackGround[0];
        }
        else UIManager.instance.Recruit();
        UpdateButtons();
    }
    public void ButtonTwo()
    {
        if (pve)
        {

        }
        else UIManager.instance.ViewGuild();
        UpdateButtons();
    }
    public void ButtonThree()
    {
        if (pve)
        {

        }
        else UIManager.instance.PVEMenu();
        UpdateButtons();
    }
    public void NullifyPVETarget()
    {
        target = null;
        UIManager.instance.background.sprite = SpriteList.instance.menuBackGround;
        UpdateButtons();
    }
    public void Test()
    {
        Utility.instance.TurnOff(UIManager.instance.menu);
        Utility.instance.TurnOff(UIManager.instance.guild);
        Utility.instance.TurnOff(UIManager.instance.background.gameObject);
        Utility.instance.TurnOn(UIManager.instance.events.gameObject);
        target = EventManager.instance.pve[0];
        EventManager.instance.pve[0].agentsInEvent.Add(CharacterList.instance.charactersInTheGame[0]);
        EventManager.instance.pve[0].agentsInEvent.Add(CharacterList.instance.charactersInTheGame[1]);
        EventManager.instance.pve[0].agentsInEvent.Add(CharacterList.instance.charactersInTheGame[26]);
        EventManager.instance.pve[0].agentsInEvent.Add(CharacterList.instance.charactersInTheGame[16]);
        EventManager.instance.pve[0].agentsInEvent.Add(CharacterList.instance.charactersInTheGame[17]);
        EncounterManager.instance.Begin(target.encounter[0]);
    }
}
