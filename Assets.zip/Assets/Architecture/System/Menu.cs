using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using TMPro;
using UnityEditor;

public class Menu : MonoBehaviour
{
    public static Menu instance;
    public Text pveTitle;
    public List<Button> buttons;
    public Button helpButton;
    public bool events;
   
    private void Awake()
    {
        instance = this;
    }
    public void UpdateButtons()
    {
        Utility.instance.TurnOn(helpButton.gameObject);
        foreach (Button b in buttons) Utility.instance.TurnOn(b.gameObject);
        buttons[0].GetComponentInChildren<Text>().text = "Manage Guild";
        buttons[1].GetComponentInChildren<Text>().text = "Guild Upgrades";
        buttons[2].GetComponentInChildren<Text>().text = "Something Else";
        buttons[3].GetComponentInChildren<Text>().text = "Codex";
        buttons[4].GetComponentInChildren<Text>().text = "Time";
        buttons[5].GetComponentInChildren<Text>().text = "Test";
    }

    public void BackToMenu()
    {
        Utility.instance.TurnOff(helpButton.gameObject);
        UIManager.instance.background.sprite = SpriteList.instance.menuBackGround;
        UpdateButtons();
    }

    public void ButtonOne()
    {
        if (!events)
        {
            Guild.instance.manageState = Guild.instance.roster.Count > 0 ? ManageState.View : ManageState.Recruit;
            GuildManagement();
        }
        UpdateButtons();
    }

    public void ButtonTwo()
    {
        if (!events)
        {
            Guild.instance.manageState =  ManageState.Upgrades;
            GuildUpgrades();
        }
        UpdateButtons();
    }

    

    public void ButtonThree()
    {
        
    }
    public void ButtonFour()
    {
        TimeManagement.instance.NewDay(1);
    }
    public void ButtonFive()
    {
        
    }
    public void ButtonSix()
    {
        if (!events) Test.instance.Begin();
        UpdateButtons();
    }
    public void Help()
    {
        if (!events)
        {
            Event();
            events = true;
            foreach (Event e in EventList.instance.events) if (e.id == 2) EventManager.instance.triggeredEvents.Add(e);
            EventManager.instance.Load();
        }
    }

    public void Event()
    {
        Utility.instance.TurnOn(UIManager.instance.background.gameObject);
        Utility.instance.TurnOff(UIManager.instance.guild);
        if (UIManager.instance.dungeons != null) Utility.instance.TurnOff(UIManager.instance.dungeons);
        Utility.instance.TurnOn(UIManager.instance.menu);
        Utility.instance.TurnOn(UIManager.instance.events);
        UIManager.instance.background.sprite = SpriteList.instance.menuBackGround;
        instance.UpdateButtons();
    }

    public void GuildManagement()
    {
        Utility.instance.TurnOn(UIManager.instance.background.gameObject);
        if (UIManager.instance.dungeons != null) Utility.instance.TurnOff(UIManager.instance.dungeons);
        Utility.instance.TurnOn(UIManager.instance.guild);
        Guild.instance.Manage();
    }
    private void GuildUpgrades()
    {
        Utility.instance.TurnOn(UIManager.instance.background.gameObject);
        Utility.instance.TurnOn(UIManager.instance.guild);
        if (UIManager.instance.dungeons != null) Utility.instance.TurnOff(UIManager.instance.dungeons);        
        Guild.instance.Manage();
    }
}