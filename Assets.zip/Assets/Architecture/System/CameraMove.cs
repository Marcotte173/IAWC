using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class CameraMove : MonoBehaviour
{
    public float cameraScroll = 5f;
    public float cameraMove = 7f;
    Rigidbody2D body;
    void Start()
    {
        body = GetComponent<Rigidbody2D>();
    }


    public void  Update()
    {
        body.velocity = new Vector2(Input.GetAxisRaw("Horizontal") * cameraMove, Input.GetAxisRaw("Vertical") * cameraMove);
        Camera.main.orthographicSize -= Input.GetAxis("Mouse ScrollWheel") * cameraScroll;
    }
}