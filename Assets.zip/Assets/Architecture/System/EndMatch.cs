using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class EndMatch : MonoBehaviour
{
    public static EndMatch instance;
    private void Awake()
    {
        instance = this;
    }

    public void FindWinner()
    {
        Utility.instance.TurnOn(EncounterUI.instance.preFightBox);
        EncounterUI.instance.UpdatePlayerUIs();
        EncounterUI.instance.UpdateBossUIs();
        EncounterUI.instance.UpdateDamageMeters();
        if (EncounterManager.instance.currentEncounter.Player().Count == 0)
        {
            EncounterUI.instance.preFightBox.GetComponentInChildren<Text>().text = "You Lose";
            EncounterUI.instance.preFightBox.GetComponentInChildren<Button>().GetComponentInChildren<Text>().text = "Go Home";
        }
        else
        {
            EncounterUI.instance.preFightBox.GetComponentInChildren<Text>().text = "You Win";
            EncounterUI.instance.preFightBox.GetComponentInChildren<Button>().GetComponentInChildren<Text>().text = "Rewards";
        }
    }
}
