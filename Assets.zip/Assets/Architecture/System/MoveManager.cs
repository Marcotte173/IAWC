using System;
using System.Linq;
using System.Collections.Generic;
using UnityEngine;

public class MoveManager : MonoBehaviour
{
    public static MoveManager instance;
    public float speed;
    public float margin;
    private void Awake()
    {
        instance = this;
    }

    internal void Move(Move move)
    {
        //Move Toward Position
        move.transform.position = Vector3.MoveTowards(move.transform.position, new Vector3(move.GetComponent<Move>().nextTile.transform.position.x, move.GetComponent<Move>().nextTile.transform.position.y), speed * (move.moveSpeed+move.moveBonus) * Time.deltaTime);        
    }

    public bool IsAtTile(Move move, Tile target) => (move.transform.position.x <= target.transform.position.x + margin && move.transform.position.x >= target.transform.position.x - margin && move.transform.position.y <= target.transform.position.y + margin && move.transform.position.y >= target.transform.position.y - margin);

    public bool GetNewPath(Agent g,Tile end)
    {
        Move move = g.GetComponent<Move>();
        List<Tile> closed = new List<Tile> { };
        List<Tile> open = new List<Tile> { };

        Tile start = move.currentTile;
        Tile current = start;
    
        move.unwalkable.Clear();
        move.path.Clear();
        open.Clear();
        closed.Clear();
        open.Add(start);
    
        //Find unwalkables//    
        //For each g 
        foreach (Agent agent in move.PeopleWhoAreNotMeOrMyTarget())
        {
            Move agentPawn = agent.GetComponent<Move>();
            if (agentPawn.isMoving) move.unwalkable.Add(agentPawn.nextTile);
            else move.unwalkable.Add(agentPawn.currentTile);
        }
        while (!closed.Contains(end))
        {
            foreach (Tile neighbor in current.neighbor)
            {
                //Calculate each neighbor's f value
                neighbor.g = (move.unwalkable.Contains(neighbor)) ? 200 : 1;
                neighbor.h = Vector3.Distance(neighbor.transform.position, end.transform.position);
                neighbor.f = (neighbor.g + neighbor.h);//Consider doubling g in calculation, to disensentivise diagonals
                //if(move.GetComponent<Player>())neighbor.f += HazardChange(neighbor, move) ;
                //Adding neighbor to the open list
                foreach (Tile t in open.ToList())
                {
                    if (neighbor == t && neighbor.f < t.f)
                    {
                        t.f = neighbor.f;
                        neighbor.parent = current;
                    }
                    else if (!open.Contains(neighbor) && (!closed.Contains(neighbor)) && !move.unwalkable.Contains(neighbor))
                    {
                        neighbor.parent = current;
                        open.Add(neighbor);
                    }
                }
            }
            open.Remove(current);
            closed.Add(current);
            if (open.Count > 0)
            {
                current = open[0];
                for (int i = 1; i < open.Count; i++) { if (open[i].f < current.f) current = open[i]; }
                if (current == end) break;
            }
            else break;
        }
        while (current.parent != start)
        {
            move.path.Add(current.parent);
            current = current.parent;
        }
        move.path.Reverse();
        if (move.path.Count > 0)
        {
            move.nextTile = move.path[0];
            return true;
        }
        else return false;
    }

    //private float HazardChange(Tile neighbor, Move move)
    //{
    //    if (neighbor.playerHazards.Count > 0)
    //    {
    //        HazardDecision dec = move.GetComponent<Player>().hazardDec;
    //        if (move.isMoving)
    //        {
    //            if (dec == HazardDecision.Avoid) return 200;
    //            else if (dec == HazardDecision.RunThrough) return 0;
    //        }
    //    }
    //    return 0;
    //}

    public void MoveAgent(Move move)
    {
        MoveAgent(move,(move.GetComponent<Character>().target.GetComponent<Move>().isMoving) ? move.GetComponent<Character>().target.GetComponent<Move>().nextTile : move.GetComponent<Character>().target.GetComponent<Move>().currentTile);
    }

    public void MoveAgent(Move move, Tile target)
    {
        move.isMoving = true;        
        if (move.path.Count == 0 || IsAtTile(move, move.nextTile)||move.unwalkable.Contains(move.nextTile)) GetNewPath(move.GetComponent<Agent>(), target);
        Move(move);
    }
    //public Tile ClosestNoHazardTile(Tile t)
    //{
    //    List<Tile> tileList = EncounterManager.instance.currentEncounter.NoHazardTile();
    //    Tile closest = tileList[0];
    //    //Calculate Distance to target
    //    float distance = Vector3.Distance(t.transform.position, closest.transform.position);
    //    //Check each other in the list
    //    foreach (Tile c in tileList)
    //    {
    //        //If the distance to them is shorter
    //        if (Vector3.Distance(t.transform.position, c.transform.position) < distance)
    //        {
    //            //They are the target, new distance
    //            closest = c;
    //            distance = Vector3.Distance(t.transform.position, c.transform.position);
    //        }
    //    }
    //    return closest;
    //}
    //public Tile ClosestNoHazardTileToTarget(Tile targetTile, Tile myTile)
    //{
    //    List<Tile> tileList = EncounterManager.instance.currentEncounter.NoHazardTile();
    //    Tile closest = tileList[0];
    //    //Calculate Distance to target
    //    float distance = Vector2.Distance(myTile.transform.position, closest.transform.position) + Vector2.Distance(targetTile.transform.position, closest.transform.position);
    //    //Check each other in the list
    //    foreach (Tile c in tileList)
    //    {
    //        //If the distance to them is shorter
    //        if (Vector2.Distance(myTile.transform.position, c.transform.position) + Vector2.Distance(targetTile.transform.position, c.transform.position) < distance)
    //        {
    //            //They are the target, new distance
    //            closest = c;
    //            distance = Vector2.Distance(myTile.transform.position, c.transform.position) + Vector2.Distance(targetTile.transform.position, c.transform.position);
    //        }
    //    }
    //    return closest;
    //}
    //public Tile Run(Tile targetTile, Tile myTile, int x)
    //{
    //    List<Tile> tileList = EncounterManager.instance.currentEncounter.NoHazardTile();
    //    Tile closest = tileList[0];
    //    //Calculate Distance to target
    //    float distance = Vector2.Distance(myTile.transform.position, closest.transform.position) + Vector2.Distance(targetTile.transform.position, closest.transform.position);
    //    //Check each other in the list
    //    foreach (Tile c in tileList)
    //    {
    //        //If the distance to them is shorter
    //        if (Vector2.Distance(myTile.transform.position, c.transform.position) + Vector2.Distance(targetTile.transform.position, c.transform.position) < distance)
    //        {
    //            //They are the target, new distance
    //            closest = c;
    //            distance = Vector2.Distance(myTile.transform.position, c.transform.position) + Vector2.Distance(targetTile.transform.position, c.transform.position);
    //        }
    //    }
    //    return closest;
    //}
    public Tile AdjacentUnoccupiedTile(Tile targetTile, Tile myTile,List<Tile> exclusions)
    {
        List<Tile> tileList = new List<Tile> { };
        foreach (Tile t in myTile.neighbor) tileList.Add(t);
        foreach (Agent a in EncounterManager.instance.currentEncounter.Agents()) foreach (Tile t in tileList.ToList()) if (a.GetComponent<Move>().currentTile == t) tileList.Remove(t);
        if (exclusions!=null) if (exclusions.Count >0) foreach (Tile t in exclusions) if(tileList.Contains(t))tileList.Remove(t);
        Tile closest = tileList[0];
        //Calculate Distance to target
        float distance = Vector2.Distance(myTile.transform.position, closest.transform.position) + Vector2.Distance(targetTile.transform.position, closest.transform.position);
        //Check each other in the list
        foreach (Tile c in tileList)
        {
            //If the distance to them is shorter
            if (Vector2.Distance(myTile.transform.position, c.transform.position) + Vector2.Distance(targetTile.transform.position, c.transform.position) < distance)
            {
                //They are the target, new distance
                closest = c;
                distance = Vector2.Distance(myTile.transform.position, c.transform.position) + Vector2.Distance(targetTile.transform.position, c.transform.position);
            }
        }        
        return closest;
    }
}
