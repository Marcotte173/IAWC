using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Target : MonoBehaviour
{
    public static Target instance;
    private void Awake()
    {
        instance = this;
    }

    public Agent Closest(Agent a, List<Agent> list)
    {
        Agent target = list[0];
        //Calculate Distance to target
        float distance = Vector3.Distance(a.transform.position, target.transform.position);
        //Check each other in the list
        foreach (Agent c in list)
        {
            if (c.GetComponent<Character>().untargetable) continue;
            //If the distance to them is shorter
            if (Vector3.Distance(a.transform.position, c.transform.position) < Vector3.Distance(a.transform.position, target.transform.position)) target = c;
        }
        return target;
    }
    public Agent Farthest(Agent a,List<Agent> list)
    {
        Agent target = list[0];
        //Check each other in the list
        foreach (Agent c in list)
        {      
            if (c.GetComponent<Character>().untargetable) continue;
            //If the distance to them is shorter
            if (Vector2.Distance(a.transform.position, c.transform.position) > Vector2.Distance(a.transform.position, target.transform.position)) target = c;
        }
        return target;
    }
    public Agent HighestAggro(List<Aggro> list)
    {
        Aggro target = list[0];
        //Calculate Distance to target
        float aggro = target.aggro;
        //Check each other in the list
        foreach (Aggro c in list)
        {
            //If the distance to them is shorter
            if (c.aggro > aggro)
            {
                //They are the target, new distance
                target = c;
                aggro =c.aggro;
            }
        }
        return target.agent;
    }
    public Agent LowHealth(List<Agent> list)
    {
        Agent target = list[0];
        float health = target.GetComponent<Character>().Health();
        //Check each other in the list
        foreach (Agent c in list)
        {
            if (c.GetComponent<Character>().untargetable) continue;
            //If the distance to them is shorter
            if (c.GetComponent<Character>().Health() < health)
            {
                //They are the target, new health
                target = c;
                health = c.GetComponent<Character>().Health();
            }
        }
        return target;
    }    
}