using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public enum RaidMode { Off, Setup, Combat,After }
public class EncounterManager : MonoBehaviour
{
    public static EncounterManager instance;
    public Encounter currentEncounter;
    private void Awake()
    {
        instance = this;
    }

    internal void Begin(EncounterSO e)
    {
        Encounter enc = Instantiate(GameObjectList.instance.encounter, Menu.instance.target.transform);
        enc.transform.position = new Vector2(0,0);
        currentEncounter = enc;
        CopyEncounter(e, enc);        
        CreateArena(enc);
        SpawnPOI(enc);
        PopulateBosses(enc);
        PopulatePlayers(enc);
        BeginPlacement();
        foreach (Tile t in enc.tileList)
        {
            if (t.x > 0 && t.x < enc.arenaSizeX-1 && t.y > 0 && t.y <= enc.maximumYPlace)
            {
                Tile tile = Instantiate(GameObjectList.instance.tile, t.transform);
                tile.transform.position = t.transform.position;
                tile.GetComponent<SpriteRenderer>().sortingOrder =0;
                tile.GetComponent<SpriteRenderer>().sprite = SpriteList.instance.placeTile;
                enc.placeTiles.Add(tile);                
            }
        }
    }


    private void CopyEncounter(EncounterSO give, Encounter receive)
    {
        receive.id = give.id;
        receive.bossSummon = give.bossSummon;
        receive.arena = give.arena;
        receive.arenaSizeX = give.arenaSizeX;
        receive.arenaSizeY = give.arenaSizeY;
        receive.cameraY = give.cameraY;
        receive.drops = give.drops;
        receive.flavor = give.flavor;
        receive.name = give.name;
        receive.maximumYPlace = give.maximumYPlace;
    }

    private void SpawnPOI(Encounter e)
    {
        if(e.arena == 0)foreach (Tile t in e.tileList) t.GetComponent<SpriteRenderer>().sprite = SpriteList.instance.grass[UnityEngine.Random.Range(0,SpriteList.instance.grass.Count)];
        if (e.arena == 1)
        {
            foreach (Tile t in e.tileList)
            {
                if(t.x == 0||t.x == e.arenaSizeX-1||t.y == 0||t.y ==e.arenaSizeY-1) t.GetComponent<SpriteRenderer>().sprite = SpriteList.instance.greyArena[2];
                else t.GetComponent<SpriteRenderer>().sprite = SpriteList.instance.greyArena[0];
            }
        }
    }

    private void BeginPlacement()
    {
        Utility.instance.TurnOn(EncounterUI.instance.preFightBox);
        EncounterUI.instance.preFightBox.GetComponentInChildren<Text>().text = "Move your team into position\nPress the Start Button to begin";
        EncounterUI.instance.preFightBox.GetComponentInChildren<Button>().GetComponentInChildren<Text>().text = "Start";
        foreach (Agent a in currentEncounter.Agents())
        {
            a.GetComponent<Move>().on = true;
        }
        currentEncounter.raidMode = RaidMode.Setup;
    }

    private void PopulatePlayers(Encounter e)
    {
        for (int i = 0; i < Menu.instance.target.agentsInEvent.Count; i++)
        {
            e.player.Add(Menu.instance.target.agentsInEvent[i]);
            Menu.instance.target.agentsInEvent[i].GetComponent<AgentInteract>().NewPosition(i + 1, 1);
            Menu.instance.target.agentsInEvent[i].transform.SetParent(e.transform);
        }
        foreach(Agent a in e.player)
        {
            a.GetComponent<Class>().StartEncounter();
            a.GetComponent<Class>().SpriteOn();
            if (!a.GetComponent<Beserker>())a.GetComponent<Class>().mana = a.GetComponent<Class>().MaxMana();
            a.GetComponent<Class>().health = a.GetComponent<Class>().MaxHealth();
            a.GetComponent<Move>().prevPosition = a.transform.position;
            a.GetComponent<Move>().moveSpeed = a.GetComponent<Class>().movement;
        }
    }

    private void PopulateBosses(Encounter e)
    {
        for (int i = 0; i < e.bossSummon.Count; i++)
        {
            e.boss.Add(BossList.instance.boss[e.bossSummon[i]]);
            BossList.instance.boss[e.bossSummon[i]].GetComponent<Boss>().NewPosition(BossList.instance.boss[e.bossSummon[i]].GetComponent<Boss>().startX, BossList.instance.boss[e.bossSummon[i]].GetComponent<Boss>().startY);
            BossList.instance.boss[e.bossSummon[i]].transform.SetParent(e.transform);
            e.boss[i].GetComponent<Move>().moveSpeed = e.boss[i].GetComponent<Boss>().movement;
        }        
    }

    private void CreateArena(Encounter e)
    {
        for (int y = 0; y < e.arenaSizeX; y++)
        {
            for (int x = 0; x < e.arenaSizeY; x++)
            {
                Tile l = Instantiate(GameObjectList.instance.tile, e.transform);
                l.x = x;
                l.y = y;
                e.tileList.Add(l);
                l.transform.position = new Vector2(l.x, l.y);
                l.name = $"{l.x} , {l.y}";
            }
        }
        foreach (Tile l in e.tileList)
        {
            foreach (Tile loc in e.tileList)
            {
                if (loc.x == l.x + 1 && loc.y == l.y) if (!l.neighbor.Contains(loc)) l.neighbor.Add(loc);
                if (loc.x == l.x - 1 && loc.y == l.y) if (!l.neighbor.Contains(loc)) l.neighbor.Add(loc);
                if (loc.x == l.x && loc.y == l.y + 1) if (!l.neighbor.Contains(loc)) l.neighbor.Add(loc);
                if (loc.x == l.x && loc.y == l.y - 1) if (!l.neighbor.Contains(loc)) l.neighbor.Add(loc);

                if (loc.x == l.x + 1 && loc.y == l.y + 1) if (!l.neighbor.Contains(loc)) l.neighbor.Add(loc);
                if (loc.x == l.x - 1 && loc.y == l.y + 1) if (!l.neighbor.Contains(loc)) l.neighbor.Add(loc);
                if (loc.x == l.x + 1 && loc.y == l.y - 1) if (!l.neighbor.Contains(loc)) l.neighbor.Add(loc);
                if (loc.x == l.x - 1 && loc.y == l.y - 1) if (!l.neighbor.Contains(loc)) l.neighbor.Add(loc);
            }
        }
        Camera.main.transform.position = new Vector3(e.arenaSizeX / 2, e.cameraY,-10);
        Camera.main.orthographicSize = e.arenaSizeX / 2;
    }
    private void Update()
    {
        if (currentEncounter != null)
        {
            foreach (Agent a in currentEncounter.Boss()) if (currentEncounter.raidMode == RaidMode.Combat)  a.GetComponent<Boss>().State();
            foreach (Agent a in currentEncounter.Player()) if (currentEncounter.raidMode == RaidMode.Combat)  a.GetComponent<Class>().State();
            if (currentEncounter.PlayerMinion().Count >0)foreach (Agent a in currentEncounter.PlayerMinion()) if (currentEncounter.raidMode == RaidMode.Combat) a.GetComponent<Class>().State();
            if (currentEncounter.BossMinion().Count > 0) foreach (Agent a in currentEncounter.BossMinion()) if (currentEncounter.raidMode == RaidMode.Combat) a.GetComponent<Class>().State();
        }        
    }
    public Tile Location(Transform a, List<Tile> tileList)
    {
        foreach (Tile loc in tileList) if (loc.x == a.position.x && loc.y == a.position.y) return loc;
        return null;
    }
    public Tile Location(Transform a)
    {
        foreach (Tile loc in currentEncounter.tileList) if (loc.x == a.position.x && loc.y == a.position.y) return loc;
        return null;
    }
    public Tile Location(Vector2 position)
    {
        foreach (Tile loc in currentEncounter.tileList) if (loc.x == position.x && loc.y == position.y) return loc;
        return null;
    }
    public Tile Location(int x, int y, List<Tile> tileList)
    {
        foreach (Tile loc in currentEncounter.tileList) if (loc.x == x && loc.y == y) return loc;
        return null;
    }
    public Tile Location(int x, int y)
    {
        foreach (Tile loc in currentEncounter.tileList) if (loc.x == x && loc.y == y) return loc;
        return null;
    }
    internal Tile OppositeTile(Tile defenderTile, Tile attackerTile)
    {
        int x = attackerTile.x - defenderTile.x;
        int y = attackerTile.y - defenderTile.y;
        foreach (Tile l in currentEncounter.tileList) if (l.x == defenderTile.x - x && l.y == defenderTile.y - y) return l;
        return null;
    }    
}
