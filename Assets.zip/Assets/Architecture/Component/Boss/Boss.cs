using System;
using System.Linq;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class Boss : Character
{
    public List<Aggro> aggro;
    public int startX;
    public int startY;
    
    public override void Create()
    {
        Equipment();
    }
    public override void Decision()
    {
       
    }
    public override void UpdateStuff()
    {
        base.UpdateStuff();
        foreach (Aggro a in aggro.ToList()) if (a.agent.ko) aggro.Remove(a);
        if (aggro.Count > 1) Utility.instance.SortAggro(aggro);
    }

    public override void GetTarget()
    {
        if (targetFromTaunt != null) target = targetFromTaunt;
        else if (aggro.Count > 1)
        {
            target = aggro[0].agent;
        }
        else
        {
            target = Target.instance.Closest(GetComponent<Agent>(),EncounterManager.instance.currentEncounter.Player());
        }
        rangeToTarget = Vector3.Distance(transform.position, target.transform.position);
    }    
    
    public virtual void Equipment()
    {
        Equip.instance.EquipHead(ItemList.instance.noItem, head);
        Equip.instance.EquipChest(ItemList.instance.noItem, chest);
        Equip.instance.EquipLegs(ItemList.instance.noItem, legs);
        Equip.instance.EquipFeet(ItemList.instance.noItem, feet);
        Equip.instance.EquipTrinket(ItemList.instance.noItem, trinket);
        Equip.instance.EquipWeapon(ItemList.instance.noItem, weapon);
        Equip.instance.EquipOffHand(ItemList.instance.noItem, offHand);
    }
    public void NewPosition(float newX, float newY)
    {
        transform.position = new Vector2(newX, newY);
    }
    public void TakeDamage(Agent attacker, float damage,float aggroNumber,bool physical)
    {
        bool crit = false;
        Character aChar = attacker.GetComponent<Character>();
        //Damage
        if (physical)
        {
            if (UnityEngine.Random.Range(1, 101) < aChar.Crit())
            {
                damage *= 2;
                crit = true;
            }
        }
        if (physical) damage *= (200 / (200 + Defence()));
        if (aChar.Vamp() > 0) aChar.Heal(damage * attacker.GetComponent<Character>().Vamp() / 100f);
        health -= damage;
        damageTaken += damage;
        if (attacker.GetComponent<Class>()) attacker.GetComponent<Class>().damageDone += damage;
        Utility.instance.DamageNumber(this, Convert.ToInt32(damage).ToString(), (crit) ? SpriteList.instance.critColor : (physical) ? SpriteList.instance.damageColor : SpriteList.instance.magicColor);
        Utility.instance.Aggro(this, attacker, aggroNumber);
        if (Health() <= 0) Death();
    }

    public override void Death()
    {
        base.Death();
    }

    public void CreateAggro(Agent attacker, float aggroNumber)
    {
        Aggro a = Instantiate(GameObjectList.instance.aggro, transform);
        a.name = $"{attacker.GetComponent<Character>().characterName}: {aggroNumber}";
        a.agent = attacker;
        a.aggro = aggroNumber;
        aggro.Add(a);
    }    
}
