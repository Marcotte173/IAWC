using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Orc : Boss
{
    public float hazardCooldownTime;
    public float hazardCooldownTimer;
    public override void UpdateStuff()
    {
        base.UpdateStuff();
    }
    public override void Cast()
    {
        if (basicAttack) Attack1Cast();
    }
    public override void Decision()
    {
        if (hazardCooldownTimer <= 0)
        {
            state = DecisionState.Attack2;
        }
        else if (basicAttackCooldownTimer <= 0)
        {
            state = DecisionState.Attack1;
        }
    }
    public override void Attack2()
    {
        base.Attack2();
        action = $"Attacking {target.GetComponent<Class>().characterName}";
        Hazard h = Instantiate(GameObjectList.instance.enemyHazard, EncounterManager.instance.currentEncounter.transform);
        h.transform.position = Target.instance.Farthest(GetComponent<Agent>(), EncounterManager.instance.currentEncounter.Player()).transform.position;
        EncounterManager.instance.currentEncounter.enemyHazards.Add(h);
        state = DecisionState.Downtime;
        hazardCooldownTimer = hazardCooldownTime;
    }
    public override void Attack3()
    {
        base.Attack3();
    }
    public override void Attack4()
    {
        base.Attack4();
    }

}
