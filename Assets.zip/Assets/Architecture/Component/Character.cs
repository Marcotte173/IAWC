using System;
using System.Linq;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
public enum DecisionState { Downtime, Decision, Attack1, Attack2, Attack3, Attack4, Attack5, StopDPS,Move,Wait,Asleep,Cast }
public enum GenericOrder { PlayerChoice, Closer, Farther, FindSafety, Target }
public class Character : MonoBehaviour
{
    [HideInInspector]
    public int id;
    [HideInInspector]
    public Head head;
    [HideInInspector]
    public Chest chest;
    [HideInInspector]
    public Legs legs;
    [HideInInspector]
    public Feet feet;
    [HideInInspector]
    public Trinket trinket;
    [HideInInspector]
    public Weapon weapon;
    [HideInInspector]
    public OffHand offHand;
    public Agent target;
    [HideInInspector]
    public Agent targetFromTaunt;
    [HideInInspector]
    public Agent orderTarget;
    [HideInInspector]
    public string characterName;
    [HideInInspector]
    public float resPriority;
    public float gold;
    [Header("------------------------------------------------------")]
    [Header("Stats")]
    public float maxHealth;
    public float health;
    public float mana;
    public float maxMana;
    public float defence;
    public float attackPower;
    public float spellpower;
    public float damage;
    public float crit;
    public float vamp;
    public float movement;
    public float haste;
    [Header("------------------------------------------------------")]
    [Header("Bonuses")]
    public float bonusDef;
    public float bonusCrit;
    public float bonusDamage;
    public float physicalDamageMod;
    public float magicDamageMod;
    public float energyCost;
    public float bonusHealth;
    public float bonusMana;
    public float bonusVamp;
    public float manaRegenTime;
    public float bonusHaste;
    public float manaRegenValue;
    public float manaRegenMod;
    [HideInInspector]
    public float manaRegenTimer;
    [HideInInspector]
    public bool untargetable;
    [HideInInspector]
    public float castTimer;
    [HideInInspector]
    public float rangeToTarget;
    [HideInInspector]
    public float decisionTimer;
    [HideInInspector]
    public float downTimer;
    [Header("------------------------------------------------------")]
    [Header("Control")]
    public float decisionTime;
    [HideInInspector]
    public float waitTimer;
    public float downTime;
    public float waitTime = 3;
    [HideInInspector]
    public float damageDone;
    [HideInInspector]
    public float damageTaken;
    public DecisionState state;
    public GenericOrder gOrder;
    [HideInInspector]
    public List<Hazard> hazards;
    [HideInInspector]
    public Text characterNameText;
    protected Move move;
    protected Player player;
    [HideInInspector]
    public string action;
    [Header("------------------------------------------------------")]
    [Header("Buff/Debuff")]
    public List<Effect> buff;
    public List<Effect> debuff;
    [Header("------------------------------------------------------")]
    [Header("Basic Attack")]
    public float basicAttackCooldownTime;
    [HideInInspector]
    public float basicAttackCooldownTimer;
    [HideInInspector]
    public bool basicAttack;
    public float basicAttackCastTime;
    public float basicAttackRangeRequired;
    public float basicAttackThreat;
    public bool canCastSpells;

    public void Awake()
    {
        characterNameText = GetComponentInChildren<Text>();
        move = GetComponent<Move>();
        if(GetComponent<Player>()) player = GetComponent<Player>();
        Create();
    }
    private void Update()
    {
        if(EncounterManager.instance.currentEncounter != null && EncounterManager.instance.currentEncounter.raidMode == RaidMode.Combat) UpdateStuff();
    }
    public virtual void UpdateStuff()
    {
        basicAttackCooldownTimer -= Time.deltaTime;
    }
    public virtual void Create()
    {
    }
    public virtual void StartEncounter()
    {
        canCastSpells = true;
    }
    public void State()
    {
        if (state == DecisionState.Asleep) { }
        else if (state == DecisionState.Move) Move();
        else if (state == DecisionState.Wait) Wait();
        else if (state == DecisionState.StopDPS) StopDPS();
        else if (state == DecisionState.Cast) Cast();
        else if (state == DecisionState.Downtime)
        {
            move.isMoving = false;
            downTimer -= Time.deltaTime;
            if (downTimer <= 0)
            {
                action = $"Waiting";
                state = DecisionState.Decision;
                downTimer = downTime;
            }
        }
        else if (GetComponent<Player>() && player.AggroHigh()) player.AggroInterupt();
        else if (GetComponent<Player>() && hazards.Count > 0 && player.hazardDec != HazardDecision.Tank) player.HazardInterupt();
        else if (state == DecisionState.Decision)
        {
            decisionTimer -= Time.deltaTime;
            if (decisionTimer <= 0)
            {
                action = $"Thinking";
                decisionTimer = decisionTime;
                if (gOrder == GenericOrder.Target) target = orderTarget;
                else GetTarget();
                rangeToTarget = Vector3.Distance(transform.position, target.transform.position);
                Decision();
            }
        }
        else if (target.ko)
        {
            GetTarget();
            state = DecisionState.Decision;
        }
        else if (state == DecisionState.Attack1) Attack1();
        else if (state == DecisionState.Attack2) Attack2();
        else if (state == DecisionState.Attack3) Attack3();
        else if (state == DecisionState.Attack4) Attack4();
        else if (state == DecisionState.Attack5) Attack5();
    }

    public virtual void Cast()
    {
        
    }

    private void Wait()
    {
        waitTimer -= Time.deltaTime;
        if (waitTimer <= 0)
        {
            waitTimer = waitTime;
            state = DecisionState.Downtime;
        }
    }

    public virtual void StopDPS()
    {
        action = "Waiting for aggro to drop";
        if (!player.AggroHigh()) state = DecisionState.Downtime;
    }

    public virtual void Move()
    {
        if (hazards.Count < 1)
        {
            action = "";
            state = DecisionState.Downtime;
        }
        else
        {
            action = "Moving";
            //if (player.moveTarget == null || player.moveTarget.playerHazards.Count > 0) player.moveTarget = MoveManager.instance.ClosestNoHazardTileToTarget(target.GetComponent<Move>().currentTile, move.currentTile);
            MoveManager.instance.MoveAgent(move, move.GetComponent<Player>().moveTarget);
        }
    }

    public virtual void Decision()
    {
        
    }

    public virtual void GetTarget()
    {
        
    }

    public float Vamp() => vamp + bonusVamp + head.vamp + chest.vamp + legs.vamp + feet.vamp + trinket.vamp + weapon.vamp + offHand.vamp;
    public float MaxHealth() => maxHealth + bonusHealth + head.health + chest.health + legs.health + feet.health + trinket.health + weapon.health + offHand.health;
    public float MaxMana() => (GetComponent<Rogue>() || GetComponent<Beserker>())?100:maxMana + +bonusMana+head.mana + chest.mana + legs.mana + feet.mana + trinket.mana + weapon.mana + offHand.mana;
    public float Health() => health;
    public float Mana() => mana;
    public float Defence() => defence + bonusDef + head.defence + chest.defence + legs.defence + feet.defence + trinket.defence + weapon.defence + offHand.defence;
    public float AttackPower() => attackPower + head.attackPower + chest.attackPower + legs.attackPower + feet.attackPower + trinket.attackPower + weapon.attackPower + offHand.attackPower;
    public float SpellPower() => spellpower + head.spellpower + chest.spellpower + legs.spellpower + feet.spellpower + trinket.spellpower + weapon.spellpower + offHand.spellpower;
    public float Damage() => damage + bonusDamage + weapon.damage + offHand.damage + AttackPower()/10;
    public float Crit() => crit + bonusCrit+head.crit + chest.crit + legs.crit + feet.crit + trinket.crit + weapon.crit + offHand.crit;
    public float Gold() => gold;
    public float Score() => head.score + chest.score + legs.score + feet.score + trinket.score + weapon.score + offHand.score;
    public virtual void Attack1()
    {
        action = $"Moving toward {target.GetComponent<Character>().characterName}";
        rangeToTarget = Vector3.Distance(transform.position, GetComponent<Character>().target.transform.position);
        if (InRange(basicAttackRangeRequired))
        {
            castTimer = CastTimer(basicAttackCastTime);
            basicAttack = true;
            state = DecisionState.Cast;
        }
    }
    public virtual void Attack2()
    {
        rangeToTarget = Vector3.Distance(transform.position, GetComponent<Character>().target.transform.position);
    }
    public virtual void Attack3()
    {
        rangeToTarget = Vector3.Distance(transform.position, GetComponent<Character>().target.transform.position);
    }
    public virtual void Attack4()
    {
        rangeToTarget = Vector3.Distance(transform.position, GetComponent<Character>().target.transform.position);
    }
    public virtual void Attack5()
    {
        rangeToTarget = Vector3.Distance(transform.position, GetComponent<Character>().target.transform.position);
    }
    public virtual void Attack1Cast()
    {
        Class c = GetComponent<Class>();
        action = $"Attacking {target.GetComponent<Character>().characterName}";
        castTimer -= Time.deltaTime;
        if (castTimer <= .1f)
        {
            if (GetComponent<Class>())
            {
                target.GetComponent<Boss>().TakeDamage(GetComponent<Agent>(), Damage(), Utility.instance.Threat(Damage(), basicAttackThreat,(GetComponent<Class>().spec == Spec.Stalwart)), true);
            }
            else target.GetComponent<Class>().TakeDamage(GetComponent<Agent>(), Damage(), true);
            basicAttack = false;
            state = DecisionState.Downtime;
            EnergyGain();
            basicAttackCooldownTimer = CastTimer(basicAttackCooldownTime);
        }        
    }

    public virtual void EnergyGain()
    {
        
    }

    public virtual void Attack2ACast()
    {

    }
    public virtual void Attack2BCast()
    {

    }

    internal void Heal(float x)
    {
        float healing = (Health() + x <= MaxHealth()) ? x : MaxHealth()- Health();
        health += healing;
        Utility.instance.DamageNumber(this, Convert.ToInt32(x).ToString(),  SpriteList.instance.healColor);
    }
    public virtual void Death()
    {
        foreach (Effect e in buff.ToList()) Destroy(e.gameObject);
        foreach (Effect e in debuff.ToList()) Destroy(e.gameObject);
        buff.Clear();
        debuff.Clear();
        state = DecisionState.Downtime; 
        Utility.instance.DamageNumber(this, "KO", SpriteList.instance.rage);
        GetComponent<Agent>().ko = true;
        SpriteOff();
        if (EncounterManager.instance.currentEncounter.Player().Count == 0 || EncounterManager.instance.currentEncounter.Boss().Count == 0)
        {
            EncounterManager.instance.currentEncounter.raidMode = RaidMode.After;
            EndMatch.instance.FindWinner();
        }
    }

    public void SpriteOff()
    {
        GetComponent<SpriteRenderer>().sprite = SpriteList.instance.none;
        characterNameText.text = characterName+": KO";
    }
    public virtual void SpriteOn()
    {
        
    }
    public float CastTimer(float timer)
    {        
        return timer *= (1 + haste + bonusHaste);
    }

    public bool InRange(float range)
    {
        if (rangeToTarget <= range && !move.unwalkable.Contains(move.currentTile))
        {
            if (MoveManager.instance.IsAtTile(move, move.currentTile)) return true;
            else MoveManager.instance.Move(move);
        }
        else MoveManager.instance.MoveAgent(GetComponent<Move>());
        return false;
    }
}
