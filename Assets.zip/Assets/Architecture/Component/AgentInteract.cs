using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class AgentInteract : MonoBehaviour
{
    public bool drag;
    public bool selected;
    Vector2 mousePosition;
    Vector2 objPosition;

    private void Start()
    {
        NewPosition(Mathf.Round(transform.position.x), Mathf.Round(transform.position.y));
    }

    private void OnMouseDrag()
    {        
        if (EncounterManager.instance.currentEncounter.raidMode == RaidMode.Setup) drag = true;
        //selected = true;
    }
    private void OnMouseUp()
    {
        foreach (Tile t in EncounterManager.instance.currentEncounter.placeTiles) t.GetComponent<SpriteRenderer>().sortingOrder = 0;
        Vector2 old = GetComponent<Move>().prevPosition;
        //selected = false;
        if (EncounterManager.instance.currentEncounter.raidMode == RaidMode.Setup)
        {
            drag = false;
            if (transform.position.x >= 1 && transform.position.x < EncounterManager.instance.currentEncounter.arenaSizeX && transform.position.y >= 1 && transform.position.y <= EncounterManager.instance.currentEncounter.maximumYPlace)
            {
                NewPosition(Mathf.Round(objPosition.x), Mathf.Round(objPosition.y));
                GetComponent<Move>().prevPosition = transform.position;
            }
            else NewPosition(GetComponent<Move>().prevPosition.x, GetComponent<Move>().prevPosition.y);
        }
    }
    private void Update()
    {
        if (drag)
        {
            foreach (Tile t in EncounterManager.instance.currentEncounter.placeTiles) t.GetComponent<SpriteRenderer>().sortingOrder = 2; 
            mousePosition = new Vector2(Input.mousePosition.x, Input.mousePosition.y);
            objPosition = Camera.main.ScreenToWorldPoint(mousePosition);
            transform.position = new Vector2(objPosition.x, objPosition.y);
        }
    }

    public void NewPosition(float newX, float newY)
    {
        transform.position = new Vector2(newX, newY);      
    }
}
