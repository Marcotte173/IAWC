using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Hazard : MonoBehaviour
{
    public List<Agent> agents;
    public List<Tile> tiles;
    public float hazardTimer;
    public List<float> hazardThreshHold = new List<float> { 10, 8, 6, 4, 2, 0 };
    public int hazardCheck;
    public float damage;
    public Agent attacker;
    public float threat;
    public void OnTriggerEnter2D(Collider2D collision)
    {
        if (collision.GetComponent<Tile>())
        {
            tiles.Add(collision.GetComponent<Tile>());
        }
    }
    public void OnTriggerExit2D(Collider2D collision)
    {
        if (collision.GetComponent<Tile>())
        {
            tiles.Remove(collision.GetComponent<Tile>());
        }
    }
}
