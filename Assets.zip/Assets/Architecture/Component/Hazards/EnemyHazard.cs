using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class EnemyHazard : Hazard
{
    
    private void Update()
    {
        hazardTimer -= Time.deltaTime;
        if (hazardTimer <= 0) Destroy(gameObject);
        else if (hazardTimer <= hazardThreshHold[hazardCheck])
        {
            //Tick Damage
            if (agents.Count > 0) foreach (Agent a in agents) Debug.Log($"Dot Tick: {a.GetComponent<Class>().characterName}");
            else Debug.Log("Dot Tick");
            hazardCheck++;
        }
    }
    public void OnTriggerEnter2D(Collider2D collision)
    {
        if (collision.GetComponentInParent<Class>())
        {
            if (collision.GetComponentInParent<Agent>() && collision.gameObject.tag == "Agent")
            {
                collision.GetComponentInParent<Class>().hazards.Add(this);
                agents.Add(collision.GetComponentInParent<Agent>());
            }
        }
        if (collision.GetComponent<Tile>())
        {
            tiles.Add(collision.GetComponent<Tile>());
        }
    }
    public void OnTriggerExit2D(Collider2D collision)
    {
        if (collision.GetComponentInParent<Class>())
        {
            if (collision.GetComponentInParent<Agent>() && collision.gameObject.tag == "Location")
            {
                collision.GetComponentInParent<Class>().hazards.Remove(this);
                agents.Remove(collision.GetComponentInParent<Agent>());
            }            
        } 
        if (collision.GetComponent<Tile>())
        {
            tiles.Remove(collision.GetComponent<Tile>());
        }
    }
}
