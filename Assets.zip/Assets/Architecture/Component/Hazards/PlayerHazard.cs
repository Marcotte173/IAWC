using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PlayerHazard : Hazard
{
    private void Start()
    {
        EncounterManager.instance.currentEncounter.playerHazards.Add(this);
    }
    private void Update()
    {
        hazardTimer -= Time.deltaTime;
        if (hazardTimer <= 0) Destroy(gameObject);
        else if (hazardTimer <= hazardThreshHold[hazardCheck])
        {
            //Tick Damage
            if (agents.Count > 0) foreach (Agent a in agents) a.GetComponent<Boss>().TakeDamage(attacker, damage, Utility.instance.Threat(damage, threat), false);
            hazardCheck++;
        }
    }
    
}
