using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public enum Spec { Stalwart, Focused, Explosive, Redemptive, Wrathful,Tranquil, Inspiring };
public class Class : Character
{
    [HideInInspector]
    public int specNumber;
    [HideInInspector]
    public Spec spec;

    public override void Create()
    {
        id = GetComponent<Agent>().id = CreateAgent.instance.characterIdCounter;
        CreateAgent.instance.characterIdCounter++;
        specNumber = id % 2;
    }
    public virtual void ChangeSpec()
    {

    }
    

    public override void GetTarget()
    {
        GetComponent<Character>().target = Target.instance.Closest(GetComponent<Agent>(), EncounterManager.instance.currentEncounter.Boss());
    }

    public override void Decision()
    {
        
    }
    public virtual void StartingCoreStats()
    {

    }
    public virtual void StartingEquipment()
    {

    }
    public virtual void TakeDamage(Agent attacker, float damage,bool physical)
    {
        bool crit = false;
        Character aChar = attacker.GetComponent<Character>();
        //Damage
        if (physical)
        {
            if (UnityEngine.Random.Range(1, 101) < attacker.GetComponent<Character>().Crit())
            {
                damage *= 2;
                crit = true;
            }
        }
        if (physical) damage *= (200 / (200 + Defence()));
        health -= damage;
        damageTaken += damage;
        if (attacker.GetComponent<Boss>()) attacker.GetComponent<Boss>().damageDone += damage;
        if (aChar.Vamp() > 0) aChar.Heal(damage * aChar.Vamp() / 100f);
        Utility.instance.DamageNumber(this, Convert.ToInt32(damage).ToString(), (crit) ? SpriteList.instance.critColor : (physical) ? SpriteList.instance.damageColor : SpriteList.instance.magicColor);
        if (Health() <= 0) Death();
    }
    public override void Death()
    {
        base.Death();
    }
    public List<Character> EnemiesInRange(Character c, float range)
    {
        List<Character> newList = new List<Character> { };
        foreach (Agent a in EncounterManager.instance.currentEncounter.Boss()) if (Vector2.Distance(c.transform.position, a.transform.position) <= range) newList.Add(a.GetComponent<Character>());
        return newList;
    }
    
    
}
