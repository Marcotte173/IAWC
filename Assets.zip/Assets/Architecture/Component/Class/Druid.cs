using System;
using System.Linq;
using System.Collections.Generic;
using UnityEngine;

public class Druid : Class
{
    [Header("------------------------------------------------------")]
    [Header("REDEMPTIVE")]
    [Header("Small Heal")]
    public float smallPrimaryHealThreshold;
    public float smallPartyHealThreshold;
    public float smallHealRangeRequired;
    public float smallHealEnergyRequired;
    public float smallHealCooldownTime;
    [HideInInspector]
    public float smallHealCooldownTimer;
    public float smallHealCastTime;
    public float smallHealDamage;
    public float smallHealThreat;
    [HideInInspector]
    public bool smallHeal;
    [Header("Big Heal")]
    public float bigPrimaryHealThreshold;
    public float bigPartyHealThreshold;
    public float bigHealRangeRequired;
    public float bigHealEnergyRequired;
    public float bigHealCooldownTime;
    [HideInInspector]
    public float bigHealCooldownTimer;
    public float bigHealCast;
    public float bigHealDamage;
    public float bigHealThreat;
    [HideInInspector]
    public bool bigHealHot;
    [Header("Big Heal Hot")]
    public float bigHealHotTime;
    public float bigHealHotDamage;
    public float bigHealHotThreat;
    [HideInInspector]
    public bool bigHeal;
    public List<float> bigHealHotThreshHold = new List<float> { 10, 8, 6, 4, 2, 0 };
    [HideInInspector]
    public int bigHealHotCheck;
    [Header("Hibernate")]
    public List<float> hibernateThreshHold = new List<float> { };
    public float hibernateRangeRequired;
    public float hibernateEnergyRequired;
    public float hibernateSleepTime;
    public float hibernateCooldownTime;
    public float hibernateUseThreshHold;
    [HideInInspector]
    public float hibernateCooldownTimer;
    public float hibernateCastTime;
    public float hibernateDamage;
    public float hibernateThreat;
    [HideInInspector]
    public bool hibernate;
    [Header("Ressurect")]
    public float ressurectCooldownTime;
    [HideInInspector]
    public float ressurectCooldownTimer;
    public float ressurectCastTime;
    public float ressurectHealth;
    public float ressurectRangeRequired;
    public float ressurectEnergyRequired;
    [HideInInspector]
    public bool ressurect;
    [HideInInspector]
    public Agent ressurectTarget;
    [Header("------------------------------------------------------")]
    [Header("WRATHFUL")]
    [Header("Rot")]
    public float rotRangeRequired;
    public float rotEnergyRequired;
    public float rotCooldownTime;
    [HideInInspector]
    public float rotCooldownTimer;
    public float rotCastTime;
    public float rotDamage;
    public float rotThreat;
    public float rotTime;
    [HideInInspector]
    public bool rot;
    public List<float> rotThreshHold = new List<float> { 10, 8, 6, 4, 2, 0 };
    [Header("Snake Bite")]
    public float snakeBiteRangeRequired;
    public float snakeBiteEnergyRequired;
    public float snakeBiteCooldownTime;
    [HideInInspector]
    public float snakeBiteCooldownTimer;
    public float snakeBiteCastTime;
    public float snakeBiteDamage;
    public float snakeBiteDotDamage;
    public float snakeBiteThreat;
    public float snakeBiteTime;
    [HideInInspector]
    public bool snakeBite;
    public List<float> snakeBiteThreshHold = new List<float> { 8, 6, 4, 2, 0 };
    [Header("Nature's Ally")]
    public float naturesAllyRangeRequired;
    public float naturesAllyEnergyRequired;
    public float naturesAllyCooldownTime;
    [HideInInspector]
    public bool naturesAlly;
    [HideInInspector]
    public float naturesAllyCooldownTimer;
    public float naturesAllyCastTime;
    public float naturesAllyHowManyWolves;
    public float naturesAllyWolfHp;
    public float naturesAllyWolfDamage;
    public float naturesAllyWolfDefence;
    public float naturesAllyWolfCrit;
    public float naturesAllyDuration;
    public float naturesAllyWolfBasicAttackCooldown;
    [Header("Blight")]
    public float blightRangeRequired;
    public float blightEnergyRequired;
    public float blightCooldownTime;
    [HideInInspector]
    public bool blight;
    [HideInInspector]
    public float blightCooldownTimer;
    public float blightCastTime;
    public float blightDamage;
    public float blightRotDamage;
    public float blightSnakeBiteDamage;
    public float blightThreat;
    [HideInInspector]
    public List<Tile> summonTiles;
    [HideInInspector]
    public Character primaryHealTarget;
    [HideInInspector]
    public Character healTarget;
    public override void Create()
    {
        base.Create();
        ChangeSpec();
        StartingEquipment();
        StartingCoreStats();
    }

    public override void UpdateStuff()
    {
        base.UpdateStuff();
        if (primaryHealTarget == null) GetPrimaryHealTarget();
        Cooldowns();
        ManaRegen();
    }
    private void GetPrimaryHealTarget()
    {
        if (EncounterManager.instance.currentEncounter.Player().Count == 1) primaryHealTarget = this;
        else
        {
            List<Agent> potential = new List<Agent> { };
            foreach (Agent a in EncounterManager.instance.currentEncounter.Player()) if (a != GetComponent<Agent>()) if (a.GetComponent<Class>().spec == Spec.Stalwart) potential.Add(a);
            if (potential.Count == 0) foreach (Agent a in EncounterManager.instance.currentEncounter.Player()) if (a != GetComponent<Agent>()) if (a.GetComponent<Bard>() || a.GetComponent<Rogue>()) potential.Add(a);
            if (potential.Count == 0) foreach (Agent a in EncounterManager.instance.currentEncounter.Player()) if (a != GetComponent<Agent>()) potential.Add(a);
            primaryHealTarget = potential[0].GetComponent<Character>();
            if (potential.Count > 1) for (int i = 1; i < potential.Count; i++) if (potential[i].GetComponent<Character>().MaxHealth() > primaryHealTarget.MaxHealth()) primaryHealTarget = potential[i].GetComponent<Character>();
        }
    }

    private void ManaRegen()
    {
        manaRegenTimer -= Time.deltaTime;
        if (Mana() <= MaxMana())
        {
            if (manaRegenTimer <= 0)
            {
                mana += manaRegenValue;
                manaRegenTimer = manaRegenTime;
            }
        }
    }

    private void Cooldowns()
    {
        smallHealCooldownTimer -= Time.deltaTime;
        bigHealCooldownTimer -= Time.deltaTime;
        rotCooldownTimer -= Time.deltaTime;
        hibernateCooldownTimer -= Time.deltaTime;
        blightCooldownTimer -= Time.deltaTime;
        ressurectCooldownTimer -= Time.deltaTime;
        snakeBiteCooldownTimer -= Time.deltaTime;
        naturesAllyCooldownTimer -= Time.deltaTime;
    }

    public override void Cast()
    {
        if (smallHeal) SmallHealCast();
        else if (bigHeal) BigHealCast();
        else if (hibernate) HibernateCast();
        else if (ressurect) RessurectCast();
        else if (rot) RotCast();
        else if (blight) BlightCast();
        else if (snakeBite) SnakeBiteCast();
        else if (naturesAlly) NaturesAllyCast();
        else if (basicAttack) Attack1Cast();
    }
    public override void Death()
    {
        base.Death();
        smallHeal = false;
        bigHeal = false;
        hibernate = false;
        ressurect = false;
        rot = false;
        blight = false;
        snakeBite = false;
        naturesAlly = false;
        basicAttack = false;
    }

    public override void Decision()
    {
        if (spec == Spec.Wrathful)
        {
            //NATURES ALLY
            if (Mana() >= naturesAllyEnergyRequired && naturesAllyCooldownTimer <= 0)
            {
                action = $"Moving Towards {target.GetComponent<Boss>().characterName}";
                state = DecisionState.Attack4;
            }
            //BLIGHT
            else if (MyRot(target.GetComponent<Character>()) != null && MySnakeBite(target.GetComponent<Character>()) != null && Mana() >= blightEnergyRequired && blightCooldownTimer <= 0)
            {
                action = $"Moving Towards {target.GetComponent<Boss>().characterName}";
                state = DecisionState.Attack5;
            }
            //ROT
            else if (RotCheck() && Mana() >= rotEnergyRequired && rotCooldownTimer <= 0 )
            {
                action = $"Moving Towards {target.GetComponent<Boss>().characterName}";
                state = DecisionState.Attack2;
            }           
            //SNAKEBITE
            else if (SnakeBiteCheck() && Mana() >= snakeBiteEnergyRequired && snakeBiteCooldownTimer <= 0)
            {
                action = $"Moving Towards {target.GetComponent<Boss>().characterName}";
                state = DecisionState.Attack3;
            }            
            else if (basicAttackCooldownTimer <= 0)
            {
                action = $"Moving Towards {target.GetComponent<Boss>().characterName}";
                state = DecisionState.Attack1;
            }
        }
        else if (spec == Spec.Redemptive)
        {
            //RESSURECT
            ressurectTarget = null;
            if (EncounterManager.instance.currentEncounter.KOPlayer().Count > 0)
            {
                
                ressurectTarget = FindRessurectTarget();
                Debug.Log(ressurectTarget.name);
            }
            if (ressurectTarget != null && Mana() >= ressurectEnergyRequired)
            {
                action = $"Moving Towards {target.GetComponent<Boss>().characterName}";
                state = DecisionState.Attack5;
            }
            /////////
            //HEALS//
            /////////
            //HIBERNATE TANK
            if (primaryHealTarget.Health() / primaryHealTarget.MaxHealth() < hibernateUseThreshHold / 100 && hibernateCooldownTimer <= 0)
            {
                healTarget = primaryHealTarget;
                action = $"Moving Towards {target.GetComponent<Boss>().characterName}";
                state = DecisionState.Attack4;
            }
            //HIBERNATE PARTY
            else if (SecondaryHealTarget(hibernateUseThreshHold) != null && hibernateCooldownTimer <= 0)
            {
                healTarget = SecondaryHealTarget(hibernateUseThreshHold);
                action = $"Moving Towards {target.GetComponent<Boss>().characterName}";
                state = DecisionState.Attack4;
            }
            //BIG HEAL TANK
            else if (primaryHealTarget.Health() / primaryHealTarget.MaxHealth() < bigPrimaryHealThreshold / 100 && bigHealCooldownTimer <= 0) BigHeal(primaryHealTarget);
            //BIG HEAL SELF
            else if (Health() / MaxHealth() < bigPrimaryHealThreshold / 100) BigHeal(this);
            //SMALL HEAL TANK
            else if (primaryHealTarget.Health() / primaryHealTarget.MaxHealth() < smallPrimaryHealThreshold / 100 && smallHealCooldownTimer <= 0) SmallHeal(primaryHealTarget);
            //BIG HEAL PARTY
            else if (SecondaryHealTarget(bigPartyHealThreshold) != null && bigHealCooldownTimer <= 0) BigHeal(SecondaryHealTarget(bigPartyHealThreshold));
            //SMALL HEAL SELF
            else if (Health() / MaxHealth() < smallPrimaryHealThreshold / 100 && smallHealCooldownTimer <= 0) SmallHeal(this);
            //SMALL HEAL PARTY
            else if (SecondaryHealTarget(smallPartyHealThreshold) != null && smallHealCooldownTimer <= 0) SmallHeal(SecondaryHealTarget(bigPartyHealThreshold));
            //END HEALS
            //BASIC ATTACK
            else if (basicAttackCooldownTimer <= 0)
            {
                action = $"Attacking {target.GetComponent<Boss>().characterName}";
                state = DecisionState.Attack1;
            }
        }
    }    

    public override void ChangeSpec()
    {
        spec = (specNumber == 0) ? Spec.Wrathful : Spec.Redemptive;
    }
    public override void SpriteOn()
    {
        GetComponent<SpriteRenderer>().sprite = SpriteList.instance.druidSprite[specNumber];
        characterNameText.text = characterName;
    }
    public override void StartingEquipment()
    {
        Equip.instance.EquipHead(ItemList.instance.startingHead[0], head);
        Equip.instance.EquipChest(ItemList.instance.startingChest[0], chest);
        Equip.instance.EquipLegs(ItemList.instance.startingLegs[0], legs);
        Equip.instance.EquipFeet(ItemList.instance.startingFeet[0], feet);
        Equip.instance.EquipTrinket((spec == Spec.Wrathful)?ItemList.instance.startingTrinket[0]: ItemList.instance.startingTrinket[2], trinket);
        Equip.instance.EquipWeapon((spec == Spec.Wrathful) ? ItemList.instance.startingWeapon[0]: ItemList.instance.startingWeapon[2], weapon);
        Equip.instance.EquipOffHand((spec == Spec.Wrathful) ? ItemList.instance.startingOffHand[0] : ItemList.instance.startingOffHand[2], offHand);
    }
    public override void Attack2()
    {
        base.Attack2();
        if (spec == Spec.Wrathful && InRange(rotRangeRequired)) Rot();
        else if (spec == Spec.Redemptive && InRange(smallHealRangeRequired)) SmallHeal();     
    }    

    public override void Attack3()
    {
        base.Attack3();
        if (spec == Spec.Wrathful && InRange(snakeBiteRangeRequired)) SnakeBite();
        if (spec == Spec.Redemptive && InRange(bigHealRangeRequired)) BigHeal();
    }  

    public override void Attack4()
    {
        base.Attack4();
        if (spec == Spec.Wrathful && InRange(naturesAllyRangeRequired)) NaturesAlly();
        if (spec == Spec.Redemptive && InRange(hibernateRangeRequired)) Hibernate();

    }
    public override void Attack5()
    {
        base.Attack5();
        if (spec == Spec.Wrathful && InRange(blightRangeRequired)) Blight();
        else if (spec == Spec.Redemptive && InRange(ressurectRangeRequired)) Ressurect();
    }    

    //////
    /////
    ////
    ///
    //ABILITIES
    ///
    ////
    /////

    private void BigHeal(Character target)
    {
        if (Mana() >= bigHealEnergyRequired && bigHealCooldownTimer <= 0)
        {
            healTarget = target;
            state = DecisionState.Attack3;
            action = $"Moving Towards {healTarget.GetComponent<Class>().characterName}";
        }
        else
        {
            action = $"Waiting to cast";
        }
    }

    private void BigHeal()
    {
        action = $"Casting Verdure on {healTarget.characterName}";
        if (bigHeal == false)
        {
            bigHeal = true;            
            castTimer = CastTimer(bigHealCast);           
            state = DecisionState.Cast;
        }
    }
    private void BigHealCast()
    {
        castTimer -= Time.deltaTime;
        if (castTimer <= 0)
        {
            bigHeal = false;
            mana -= bigHealEnergyRequired;
            bigHealCooldownTimer = bigHealCooldownTime;
            Utility.instance.DamageNumber(this, "Verdure", SpriteList.instance.druid);
            healTarget.Heal(bigHealDamage * SpellPower()/100);
            foreach (Agent a in EncounterManager.instance.currentEncounter.Boss()) Utility.instance.Aggro(a.GetComponent<Boss>(), GetComponent<Agent>(), (bigHealDamage / 100 * SpellPower()) * bigHealThreat / 100);
            if (GreaterHealHotCheck(healTarget.GetComponent<Character>()) == null) BigHealHot();
            else GreaterHealHotCheck(healTarget.GetComponent<Character>()).timer = bigHealHotTime;
            state = DecisionState.Downtime;
        }
    }

    private void BigHealHot()
    {
        GreaterHealHot h = Instantiate(GameObjectList.instance.greaterHealHot, healTarget.transform);
        h.attacker = GetComponent<Agent>();
        h.damage = SpellPower() * bigHealHotDamage / 100;
        h.threat = h.damage * bigHealHotThreat / 100;
        h.threshHold = bigHealHotThreshHold.ToList();
        h.timer = bigHealHotTime;
        h.target = healTarget.GetComponent<Character>();
    }
    private void Blight()
    {
        action = $"Casting Blight on {target.GetComponent<Boss>().characterName}";
        if (blight == false)
        {
            blight = true;
            castTimer = CastTimer(blightCastTime);
            state = DecisionState.Cast;
        }
    }
    private void BlightCast()
    {
        castTimer -= Time.deltaTime;
        if (castTimer <= 0)
        {
            float dotBonus = 0;
            mana -= blightEnergyRequired;
            blightCooldownTimer = blightCooldownTime;
            blight = false;
            if (MyRot(target.GetComponent<Character>()) != null)
            {
                Rot r = MyRot(target.GetComponent<Character>());
                target.GetComponent<Character>().debuff.Remove(r);
                Destroy(r.gameObject.gameObject);
                dotBonus += blightRotDamage;
            }
            if (MySnakeBite(target.GetComponent<Character>())!= null)
            {
                SnakeBite r = MySnakeBite(target.GetComponent<Character>());
                target.GetComponent<Character>().debuff.Remove(r);
                Destroy(r.gameObject.gameObject);
                dotBonus += blightSnakeBiteDamage;
            }
            float damage = SpellPower() * (blightDamage + dotBonus) / 100 * magicDamageMod;
            target.GetComponent<Boss>().TakeDamage(GetComponent<Agent>(), damage, Utility.instance.Threat(damage, blightThreat), false);
            state = DecisionState.Downtime;
        }
    }
    private void Hibernate()
    {
        action = $"Casting Hibernation on {healTarget.characterName}";
        if (hibernate == false)
        {
            hibernate = true;           
            castTimer = CastTimer(hibernateCastTime);            
            state = DecisionState.Cast;
        }
    }
    private void HibernateCast()
    {
        castTimer -= Time.deltaTime;
        if (castTimer <= 0)
        {
            mana -= hibernateEnergyRequired;
            hibernateCooldownTimer = hibernateCooldownTime;
            hibernate = false;
            HibernateDot();
            state = DecisionState.Downtime;
        }
    }
    public void HibernateDot()
    {
        Hibernate h = Instantiate(GameObjectList.instance.hibernate, healTarget.transform);
        h.attacker = GetComponent<Agent>();
        h.damage = SpellPower() * hibernateDamage / 100;
        h.threat = h.damage * hibernateThreat / 100;
        for (int i = 0; i < hibernateThreshHold.Count; i++)
        {
            if (hibernateThreshHold[i] != 0) h.threshHold.Add(hibernateThreshHold[i] / (1 + SpellPower() / 100));
            else h.threshHold.Add(hibernateThreshHold[i]);
        }
        h.timer = hibernateSleepTime / (1 + (SpellPower() / 100));
        h.target = healTarget.GetComponent<Character>();
    }

    private void NaturesAlly()
    {
        action = $"Casting Nature's Ally";
        if (naturesAlly == false)
        {
            naturesAlly = true;
            castTimer = CastTimer(naturesAllyCastTime);
            state = DecisionState.Cast;
        }
    }

    private void NaturesAllyCast()
    {
        castTimer -= Time.deltaTime;
        if (castTimer <= .1f)
        {
            summonTiles.Clear();
            naturesAlly = false;
            mana -= naturesAllyEnergyRequired;
            naturesAllyCooldownTimer = naturesAllyCooldownTime;
            for (int i = 0; i < naturesAllyHowManyWolves; i++) NaturesAllySummonWolf();
            state = DecisionState.Downtime;
        }
    }

    private void NaturesAllySummonWolf()
    {
        Agent w = Instantiate(GameObjectList.instance.wolf, transform);
        EncounterManager.instance.currentEncounter.playerMinionSummons.Add(w);
        w.transform.SetParent(EncounterManager.instance.currentEncounter.transform);
        Wolf wolf = w.GetComponent<Wolf>();        
        Tile t = MoveManager.instance.AdjacentUnoccupiedTile(target.GetComponent<Move>().currentTile, GetComponent<Move>().currentTile,summonTiles);
        summonTiles.Add(t);
        w.GetComponent<AgentInteract>().NewPosition(t.x, t.y);
        w.GetComponent<Move>().on = true;
        w.GetComponent<Move>().prevPosition = w.transform.position;
        w.GetComponent<Move>().moveSpeed = w.GetComponent<Class>().movement;
        w.GetComponent<Summon>().time = naturesAllyDuration;
        wolf.maxHealth = w.GetComponent<Wolf>().health = naturesAllyWolfHp;
        wolf.defence = naturesAllyWolfDefence;
        wolf.damage = naturesAllyWolfDamage;
        wolf.crit = naturesAllyWolfCrit;
        wolf.basicAttackCooldownTime = naturesAllyWolfBasicAttackCooldown;
        wolf.characterName = characterName;
        wolf.name = $"Wolf";
    }

    private void Ressurect()
    {
        action = $"Casting Rebirth {ressurectTarget.GetComponent<Character>().characterName}";
        if (ressurect == false)
        {
            ressurect = true;
            castTimer = CastTimer(bigHealCast);
            state = DecisionState.Cast;
        }
    }
    private void RessurectCast()
    {
        castTimer -= Time.deltaTime;
        if (castTimer <= .1f)
        {           
            Character resTarget = ressurectTarget.GetComponent<Character>();
            Utility.instance.DamageNumber(resTarget, "Nature's Medicine", SpriteList.instance.druid);
            mana -= ressurectEnergyRequired;
            ressurectCooldownTimer = ressurectCooldownTime;
            ressurect = false;
            ressurectTarget.ko = false;
            resTarget.canCastSpells = true;
            resTarget.SpriteOn();
            Tile t = MoveManager.instance.AdjacentUnoccupiedTile(target.GetComponent<Move>().currentTile, GetComponent<Move>().currentTile,null);
            resTarget.transform.position = new Vector2(t.x, t.y);
            resTarget.GetComponent<Move>().prevPosition = t.transform.position;
            resTarget.health = Mathf.Round(resTarget.MaxHealth() * .2f);
            resTarget.mana = Mathf.Round(resTarget.MaxMana() * .2f);
            state = DecisionState.Downtime;
        }
    }

    private void Rot()
    {
        action = $"Casting Rot on {target.GetComponent<Boss>().characterName}";
        if (rot == false)
        {
            rot = true;           
            castTimer = CastTimer(rotCastTime);            
            state = DecisionState.Cast;
        }
    }
    private void RotCast()
    {
        castTimer -= Time.deltaTime;
        if (castTimer <= .1f)
        {
            mana -= rotEnergyRequired;
            rotCooldownTimer = rotCooldownTime;
            rot = false;
            if (MyRot(target.GetComponent<Character>()) == null) RotDot();
            else
            {
                MyRot(target.GetComponent<Character>()).timer = rotTime;
                MyRot(target.GetComponent<Character>()).threshHold = rotThreshHold.ToList();
            }            
            state = DecisionState.Downtime;
        }
    }
    public void RotDot()
    {
        Rot r = Instantiate(GameObjectList.instance.rot, target.transform);
        r.attacker = GetComponent<Agent>();
        r.damage = SpellPower() * rotDamage / 100;
        r.threat = r.damage * rotThreat / 100;
        r.threshHold = rotThreshHold.ToList();
        r.timer = rotTime;
        r.target = target.GetComponent<Character>();
    }
    private void SnakeBite()
    {
        action = $"Casting Snake Bite on {target.GetComponent<Boss>().characterName}";
        if (snakeBite == false)
        {
            snakeBite = true;
            castTimer = CastTimer(snakeBiteCastTime);
            state = DecisionState.Cast;
        }
    }
    private void SnakeBiteCast()
    {
        castTimer -= Time.deltaTime;
        if (castTimer <= .1f)
        {
            mana -= snakeBiteEnergyRequired;
            float damage = SpellPower() * snakeBiteDamage / 100 * magicDamageMod;
            target.GetComponent<Boss>().TakeDamage(GetComponent<Agent>(), damage, Utility.instance.Threat(damage, snakeBiteThreat), false);
            snakeBiteCooldownTime = snakeBiteCooldownTimer;
            snakeBite = false;
            if (MySnakeBite(target.GetComponent<Character>()) == null) SnakeBiteDot();
            else
            {
                MySnakeBite(target.GetComponent<Character>()).timer = snakeBiteTime;
                MySnakeBite(target.GetComponent<Character>()).threshHold = snakeBiteThreshHold.ToList();
            }            
            state = DecisionState.Downtime;
        }
    }

    public void SnakeBiteDot()
    {
        SnakeBite r = Instantiate(GameObjectList.instance.snakeBite, target.transform);
        r.attacker = GetComponent<Agent>();
        r.damage = SpellPower() * snakeBiteDotDamage / 100;
        r.threat = r.damage * snakeBiteThreat / 100;
        r.threshHold = snakeBiteThreshHold.ToList();
        r.timer = snakeBiteTime;
        r.target = target.GetComponent<Character>();
    }

    public void SmallHeal(Character target)
    {
        if (Mana() >= smallHealEnergyRequired && smallHealCooldownTimer <= 0)
        {
            healTarget = target;
            castTimer = CastTimer(smallHealCastTime);
            state = DecisionState.Attack2;
            action = $"Moving Towards {healTarget.GetComponent<Class>().characterName}";
        }
        else
        {
            action = $"Waiting to cast";
        }
    }
    private void SmallHeal()
    {
        action = $"Casting Nature's Medicine on {healTarget.characterName}";
        if (smallHeal == false)
        {
            smallHeal = true;            
            castTimer = CastTimer(smallHealCastTime);            
            state = DecisionState.Cast;
        }
    }
    private void SmallHealCast()
    {
        castTimer -= Time.deltaTime;
        if (castTimer <= 0)
        {
            mana -= smallHealEnergyRequired;
            bigHealCooldownTimer = smallHealCooldownTime;
            smallHeal = false;
            Utility.instance.DamageNumber(this, "Nature's Medicine", SpriteList.instance.druid);
            healTarget.Heal(smallHealDamage * SpellPower()/100);
            foreach (Agent a in EncounterManager.instance.currentEncounter.Boss()) Utility.instance.Aggro(a.GetComponent<Boss>(), GetComponent<Agent>(), (smallHealDamage + SpellPower()) * smallHealThreat / 100);
            state = DecisionState.Downtime;
        }
    }


    //////
    /////
    ////
    ///
    //CHECKS
    ///
    ////
    /////
    /////

    private bool RotCheck()
    {
        if (MyRot(target.GetComponent<Character>()) == null || MyRot(target.GetComponent<Character>()).timer < 2f) return true;
        return false;
    }
    private bool SnakeBiteCheck()
    {
        if (MySnakeBite(target.GetComponent<Character>()) == null || MySnakeBite(target.GetComponent<Character>()).timer < 2f) return true;
        return false;
    }

    public bool CastingRot()
    {
        foreach (Agent e in EncounterManager.instance.currentEncounter.Druid()) if (e.GetComponent<Character>().state == DecisionState.Attack2 ) return true;
        return false;
    }

    public bool CastingSnakeBite()
    {
        foreach (Agent e in EncounterManager.instance.currentEncounter.Druid()) if (e.GetComponent<Character>().state == DecisionState.Attack3) return true;
        return false;
    }

    private Agent FindRessurectTarget()
    {
        return EncounterManager.instance.currentEncounter.KOPlayer()[0];
    }

    public Effect GreaterHealHotCheck(Character target)
    {
        foreach (Effect e in target.buff) if (e.GetType() == typeof(GreaterHealHot)) return e;
        return null;
    }

    private Character SecondaryHealTarget(float threshold)
    {
        if (EncounterManager.instance.currentEncounter.Player().Count > 1)
        {
            List<Agent> potential = new List<Agent> { };
            foreach (Agent a in EncounterManager.instance.currentEncounter.Player()) if (a != GetComponent<Agent>() && a.GetComponent<Class>().spec != Spec.Stalwart && a.GetComponent<Character>().Health() / a.GetComponent<Character>().MaxHealth() < threshold / 100) potential.Add(a);
            if (potential.Count > 0)
            {
                Character target = potential[0].GetComponent<Character>();
                if (potential.Count > 1) for (int i = 1; i < potential.Count; i++) if (potential[i].GetComponent<Character>().Health() < target.Health()) target = potential[i].GetComponent<Character>();
                return target;
            }
        }
        return null;
    }

    public Rot MyRot(Character target)
    {
        foreach (Effect e in target.debuff) if (e.GetType() == typeof(Rot) && e.attacker == GetComponent<Agent>()) return (Rot)e;
        return null;
    }
    public SnakeBite MySnakeBite(Character target)
    {
        foreach (Effect e in target.debuff) if (e.GetType() == typeof(SnakeBite) && e.attacker == GetComponent<Agent>()) return (SnakeBite)e;
        return null;
    }
}