using System;
using System.Linq;
using System.Collections.Generic;
using UnityEngine;

public class Mage : Class
{
    [Header("------------------------------------------------------")]
    [Header("FOCUS")]
    [Header("Arcane Missile")]    
    public float arcaneMissileRangeRequired;
    public float arcaneMissileEnergyRequired;
    public float arcaneMissileCooldownTime;
    [HideInInspector]
    public float arcaneMissileCooldownTimer;    
    public float arcaneMissileCastTime;
    public float arcaneMissileDamage;
    public float arcaneMissileThreat;
    [HideInInspector]
    public bool arcaneMissileCast;
    public List<float> arcaneMissileCastTick = new List<float> { };
    [HideInInspector]
    public int arcaneMissileCastCheck;
    [Header("Arcane Shackle")]    
    public float arcaneShackleRangeRequired;
    [HideInInspector]
    public bool arcaneShackles;
    public float arcaneShackleEnergyRequired;
    public float arcaneShackleCastTime;
    public float arcaneShackleCooldownTime;
    public float arcaneShackleCooldownTimer;
    public float arcaneShackleTendrilDamage;
    public float arcaneShackleThreat;
    public float arcaneShackleTendrils;
    public float arcaneShackleAttackSpeedDown;
    public float arcaneShackleMovementSpeedDown;
    public float arcaneShackleTendrilDuration;
    [Header("Essence Burn")]    
    public float essenceBurnRangeRequired;
    [HideInInspector]
    public bool essenceBurn;
    public float essenceBurnEnergyRequired;
    public float essenceBurnCastTime;
    public float essenceBurnDamageMod;
    public float essenceBurnCooldownTime;
    [HideInInspector]
    public float essenceBurnCooldownTimer;
    public float essenceBurnSpellCost;
    public float essenceBurnDuration;
    [HideInInspector]
    public float essenceRecovery;
    public float essenceRecoveryDuration;
    public float essenceRecoveryManaRegenMod;
    [Header("Disintigrate")]
    public float disintigrateRangeRequired;
    public float disintigrateEnergyRequired;
    public float disintigrateCooldownTime;
    [HideInInspector]
    public bool disintigrate;
    [HideInInspector]
    public float disintigrateCooldownTimer;    
    public float disintigrateCastTime;
    public float disintigrateDamage;
    public float disintigrateThreat;
    [Header("------------------------------------------------------")]
    [Header("Explosive")]
    [Header("Arcane Missile")]
    public float arcaneAOEMissileRangeRequired;
    public float arcaneAOEMissileEnergyRequired;
    public float arcaneAOEMissileCooldownTime;
    [HideInInspector]
    public float arcaneAOEMissileCooldownTimer;
    public float arcaneAOEMissileCastTime;
    public float arcaneAOEMissileRange;
    public float arcaneAOEMissileDamage;
    public float arcaneAOEMissileAOEDamage;
    public float arcaneAOEMissileThreat;
    [HideInInspector]
    public bool arcaneAOEMissileCast;
    public List<float> arcaneAOEMissileCastTick = new List<float> { };
    [HideInInspector]
    public int arcaneAOEMissileCastCheck;
    [Header("Fireball")]
    public float fireballRangeRequired;
    public float fireballEnergyRequired;
    public float fireballCooldownTime;
    [HideInInspector]
    public bool fireball;
    [HideInInspector]
    public float fireballCooldownTimer;
    public float fireballCastTime;
    public float fireballRadius;
    public float fireballDamage;
    public float fireballThreat;
    [Header("Claws From The Deep")]
    public float clawsFromTheDeepRangeRequired;
    public float clawsFromTheDeepEnergyRequired;
    public float clawsFromTheDeepCooldownTime;
    [HideInInspector]
    public bool clawsFromTheDeep;
    [HideInInspector]
    public float clawsFromTheDeepCooldownTimer;
    public float clawsFromTheDeepCastTime;
    public float clawsFromTheDeepRadius;
    public float clawsFromTheDeepDamage;
    public float clawsFromTheDeepDuration;
    public float clawsFromTheDeepThreat;
    public List<float> ClawsFromTheDeepThreshold = new List<float> {3.2f,2.2f,1.2f,0.2f};
    [Header("Time Decay")]
    public float timeDecayRangeRequired;
    public float timeDecayEnergyRequired;
    public float timeDecayCooldownTime;
    [HideInInspector]
    public float timeDecayCooldownTimer;
    public float timeDecayCastTime;
    public float timeDecayDotDamage;
    public float timeDecayThreat;
    public float timeDecayTime;
    public float timeDecayMoveBonus;
    [HideInInspector]
    public bool timeDecay;
    public List<float> timeDecayThreshHold = new List<float> { 8, 6, 4, 2, 0 }; 

    public override void Create()
    {
        base.Create();
        ChangeSpec();
        StartingEquipment();
        StartingCoreStats();
    }
    public override void UpdateStuff()
    {
        base.UpdateStuff();
        Cooldowns();
        ManaRegen();           
    }

    private void ManaRegen()
    {
        manaRegenTimer -= Time.deltaTime;
        if (manaRegenTimer <= 0)
        {
            if (Mana() + manaRegenValue * manaRegenMod <= MaxMana()) mana += manaRegenValue * manaRegenMod;
            else mana = MaxMana();
            manaRegenTimer = manaRegenTime;
        }
    }

    private void Cooldowns()
    {
        arcaneMissileCooldownTimer -= Time.deltaTime;
        arcaneShackleCooldownTimer -= Time.deltaTime;
        essenceBurnCooldownTimer -= Time.deltaTime;
        disintigrateCooldownTimer -= Time.deltaTime;
        arcaneAOEMissileCooldownTimer -= Time.deltaTime;
        fireballCooldownTimer -= Time.deltaTime;
        clawsFromTheDeepCooldownTimer -= Time.deltaTime;
        timeDecayCooldownTimer -= Time.deltaTime;
    }

    public override void Cast()
    {
        if (arcaneMissileCast) ArcaneMissileCast();
        else if (disintigrate) DisintigrateCast();
        else if (arcaneShackles) ArcaneShacklesCast();
        else if (essenceBurn) EssenceBurnCast();
        else if (arcaneAOEMissileCast) ArcaneAoeMissileCast();
        else if (fireball) FireBallCast();
        else if (clawsFromTheDeep) ClawsFromTheDeepCast();
        if (timeDecay) TimeDecayCast();
        else if (basicAttack) Attack1Cast();
    }

    

    public override void Death()
    {
        base.Death();
        arcaneMissileCast = false;
        disintigrate = false;
        arcaneShackles = false;
        essenceBurn = false;
        arcaneAOEMissileCast = false;
        fireball = false;
        clawsFromTheDeep = false;
        basicAttack = false;
        timeDecay = false;
        basicAttack = false;
    }

    public override void Decision()
    {
        if (spec == Spec.Explosive)
        {
            if (canCastSpells && Mana() > timeDecayEnergyRequired && timeDecayCooldownTimer <= 0)
            {
                action = $"Moving Towards {target.GetComponent<Boss>().characterName}";
                state = DecisionState.Attack5;
            }
            else if (canCastSpells && Mana() > clawsFromTheDeepEnergyRequired && clawsFromTheDeepCooldownTimer <= 0)
            {
                action = $"Moving Towards {target.GetComponent<Boss>().characterName}";
                state = DecisionState.Attack4;
            }
            else if (canCastSpells && Mana() > fireballEnergyRequired && fireballCooldownTimer <= 0)
            {
                action = $"Moving Towards {target.GetComponent<Boss>().characterName}";
                state = DecisionState.Attack3;
            }
            else if (canCastSpells && Mana() > arcaneAOEMissileEnergyRequired && arcaneAOEMissileCooldownTimer <= 0)
            {
                action = $"Moving Towards {target.GetComponent<Boss>().characterName}";
                state = DecisionState.Attack2;
            }
            else if (basicAttackCooldownTimer <= 0)
            {
                action = $"Moving Towards {target.GetComponent<Boss>().characterName}";
                state = DecisionState.Attack1;
            }
        }
        else if (spec == Spec.Focused)
        {
            if (canCastSpells  && Mana() >= essenceBurnEnergyRequired && essenceBurnCooldownTimer <= 0)
            {
                state = DecisionState.Attack4;
            }
            else if (canCastSpells && Mana() >= disintigrateEnergyRequired && disintigrateCooldownTimer <= 0)
            {
                Debug.Log(Mana());
                action = $"Moving Towards {target.GetComponent<Boss>().characterName}";
                state = DecisionState.Attack5;
            }
            else if (canCastSpells && Mana() >= arcaneShackleEnergyRequired && arcaneShackleCooldownTimer <= 0 && !CastingArcaneShackles())
            {
                action = $"Moving Towards {target.GetComponent<Boss>().characterName}";
                state = DecisionState.Attack3;
            }
            else if (canCastSpells && Mana() > arcaneMissileEnergyRequired && arcaneMissileCooldownTimer <= 0)
            {
                action = $"Moving Towards {target.GetComponent<Boss>().characterName}";
                state = DecisionState.Attack2;
            }
            else if (basicAttackCooldownTimer <= 0)
            {
                action = $"Moving Towards {target.GetComponent<Boss>().characterName}";
                state = DecisionState.Attack1;
            }
        }        
    }
    

    public override void ChangeSpec()
    {
        spec = (specNumber == 0) ? Spec.Explosive : Spec.Focused;
    }
    public override void SpriteOn()
    {
        characterNameText.text = characterName;
        GetComponent<SpriteRenderer>().sprite = SpriteList.instance.mageSprite[specNumber];
    }

    public override void StartingEquipment()
    {
        Equip.instance.EquipHead(ItemList.instance.startingHead[0], head);
        Equip.instance.EquipChest(ItemList.instance.startingChest[0], chest);
        Equip.instance.EquipLegs(ItemList.instance.startingLegs[0], legs);
        Equip.instance.EquipFeet(ItemList.instance.startingFeet[0], feet);
        Equip.instance.EquipTrinket(ItemList.instance.startingTrinket[0], trinket);
        Equip.instance.EquipWeapon(ItemList.instance.startingWeapon[0], weapon);
        Equip.instance.EquipOffHand(ItemList.instance.startingOffHand[0], offHand);
    }
    public override void Attack2()
    {
        base.Attack2();
        if (spec == Spec.Focused && InRange(arcaneMissileRangeRequired)) ArcaneMissile();  
        else if (spec == Spec.Explosive && InRange(arcaneAOEMissileRangeRequired)) ArcaneAoeMissile();
    }

    

    public override void Attack3()
    {
        base.Attack3();
        if (spec == Spec.Focused && InRange(arcaneShackleRangeRequired)) ArcaneShackles();
        else if (spec == Spec.Explosive && InRange(fireballRangeRequired)) FireBall();
    }

    

    public override void Attack4()
    {
        base.Attack4();
        if (spec == Spec.Focused && InRange(essenceBurnRangeRequired)) EssenceBurn();
        else if (spec == Spec.Explosive && InRange(clawsFromTheDeepRangeRequired)) ClawsFromTheDeep();
        {

        }
    }    

    public override void Attack5()
    {
        base.Attack5();
        if (spec == Spec.Focused && InRange(disintigrateRangeRequired)) Disintigrate();
        else if (spec == Spec.Explosive && InRange(timeDecayRangeRequired)) TimeDecay();
    }

    /////
    ///
    /// Abilities
    /// 
    /////
    private void ArcaneMissile()
    {
        action = $"Casting Magic Missiles at {target.GetComponent<Boss>().characterName}";
        if (arcaneMissileCast == false)
        {
            Utility.instance.DamageNumber(this, "Arcane Missiles", SpriteList.instance.mage);
            arcaneMissileCast = true;            
            castTimer = CastTimer(arcaneMissileCastTime);
            mana -= arcaneMissileEnergyRequired;
            arcaneMissileCooldownTimer = arcaneMissileCooldownTime;
            state = DecisionState.Cast;
        }
    }

    private void ArcaneMissileCast()
    {               
        castTimer -= Time.deltaTime;
        if (castTimer <= .1f)
        {
            ArcaneMissileProjectile();
            arcaneMissileCastCheck = 0;
            arcaneMissileCast = false;
            state = DecisionState.Downtime;
        }
        if (castTimer <= arcaneMissileCastTick[arcaneMissileCastCheck])
        {
            ArcaneMissileProjectile();
            arcaneMissileCastCheck++;
        }
    }   

    private void ArcaneMissileProjectile()
    {
        Projectile p = Instantiate(GameObjectList.instance.playerProjectile);
        p.transform.position = transform.position;
        p.GetComponent<SpriteRenderer>().sprite = SpriteList.instance.arcaneMissile;
        p.speed = 7f;
        p.damage = SpellPower() * arcaneMissileDamage / 100 * magicDamageMod;
        p.aggro = Utility.instance.Threat(p.damage, arcaneMissileThreat);
        p.target = target;
        p.attacker = GetComponent<Agent>();
    }
    private void ArcaneAoeMissile()
    {
        action = $"Casting Magic Missiles at {target.GetComponent<Boss>().characterName}";
        if (arcaneMissileCast == false)
        {
            Utility.instance.DamageNumber(this, "Arcane Missiles", SpriteList.instance.mage);
            arcaneAOEMissileCast = true;
            castTimer = CastTimer(arcaneAOEMissileCastTime);
            mana -= arcaneAOEMissileEnergyRequired;
            arcaneAOEMissileCooldownTimer = arcaneAOEMissileCooldownTime;
            state = DecisionState.Cast;
        }
    }

    private void ArcaneAoeMissileCast()
    {
        castTimer -= Time.deltaTime;
        if (castTimer <= .1f)
        {
            ArcaneAoeMissileProjectile();
            arcaneAOEMissileCastCheck = 0;
            arcaneAOEMissileCast = false;
            state = DecisionState.Downtime;
        }
        if (castTimer <= arcaneAOEMissileCastTick[arcaneAOEMissileCastCheck])
        {
            ArcaneAoeMissileProjectile();
            arcaneAOEMissileCastCheck++;
        }
    }

    private void ArcaneAoeMissileProjectile()
    {
        Projectile p = Instantiate(GameObjectList.instance.playerProjectile);
        p.transform.position = transform.position;
        p.GetComponent<SpriteRenderer>().sprite = SpriteList.instance.arcaneAoeMissile;
        p.effectAnimator = GameObjectList.instance.explosion;
        p.speed = 7f;
        p.damage = SpellPower() * arcaneMissileDamage / 100 * magicDamageMod;
        p.aggro = Utility.instance.Threat(p.damage, arcaneMissileThreat);
        p.aoe = true;
        p.range = arcaneAOEMissileRange;
        p.target = target;
        p.attacker = GetComponent<Agent>();
    }

    private void ArcaneShackles()
    {
        action = $"Casting Arcane shackles on {target.GetComponent<Boss>().characterName}";
        if (arcaneShackles == false)
        {
            arcaneShackles = true;            
            castTimer = CastTimer(arcaneShackleCastTime);           
            state = DecisionState.Cast;
        }
        
    }
    private void ArcaneShacklesCast()
    {        
        castTimer -= Time.deltaTime;
        if (castTimer <= .1f)
        {
            mana -= arcaneShackleEnergyRequired;
            arcaneShackleCooldownTimer = arcaneShackleCooldownTime;
            arcaneShackles = false;
            if (ArcaneTendril(target.GetComponent<Character>()) == null) ArcaneShacklesDot();
            else ArcaneTendril(target.GetComponent<Character>()).timer = arcaneShackleTendrilDuration;
            float damage = SpellPower() * arcaneShackleTendrilDamage / 100 * magicDamageMod;            
            for (int i = 0; i < arcaneShackleTendrils; i++) target.GetComponent<Boss>().TakeDamage(GetComponent<Agent>(), damage, Utility.instance.Threat(damage, arcaneShackleThreat), false);
            state = DecisionState.Downtime;
        }
    }

    public void ArcaneShacklesDot()
    {
        ArcaneTendrils r = Instantiate(GameObjectList.instance.arcaneTendrils, target.transform);
        r.attacker = GetComponent<Agent>();
        r.timer = arcaneShackleTendrilDuration;
        r.target = target.GetComponent<Character>();
        r.hasteChange = arcaneShackleAttackSpeedDown;
        r.moveChange = arcaneShackleMovementSpeedDown;
    }
    private void ClawsFromTheDeep()
    {
        action = $"Casting Claws From The Deep on {target.GetComponent<Boss>().characterName}";
        if (clawsFromTheDeep == false)
        {
            clawsFromTheDeep = true;
            castTimer = CastTimer(clawsFromTheDeepCastTime);
            state = DecisionState.Cast;
        }
    }

    private void ClawsFromTheDeepCast()
    {
        castTimer -= Time.deltaTime;
        if (castTimer <= .1f)
        {
            mana -= clawsFromTheDeepEnergyRequired;
            clawsFromTheDeepCooldownTimer = clawsFromTheDeepCooldownTime;
            ClawsFromTheDeepHazard();
            clawsFromTheDeep = false;
            state = DecisionState.Downtime;
        }
    }

    private void ClawsFromTheDeepHazard()
    {
        PlayerHazard r = Instantiate(GameObjectList.instance.playerHazard, EncounterManager.instance.currentEncounter.transform);
        r.hazardTimer = clawsFromTheDeepDuration;
        r.damage = SpellPower() * clawsFromTheDeepDamage / 100 * magicDamageMod;
        r.attacker = GetComponent<Agent>();
        r.threat = clawsFromTheDeepThreat;
        r.transform.localScale = new Vector3(clawsFromTheDeepRadius, clawsFromTheDeepRadius);
        r.transform.position = target.transform.position;
    }

    private void Disintigrate()
    {
        action = $"Casting Disintigrate on {target.GetComponent<Boss>().characterName}";
        if (disintigrate == false)
        {           
            disintigrate = true;           
            castTimer = CastTimer(disintigrateCastTime);            
            state = DecisionState.Cast;
        }
    }
    private void DisintigrateCast()
    {        
        castTimer -= Time.deltaTime;
        if (castTimer <= .1f)
        {
            mana -= disintigrateEnergyRequired;
            disintigrateCooldownTimer = disintigrateCooldownTime;
            DisintigrateSpell();
            disintigrate = false;
            state = DecisionState.Downtime;
        }
    }
    private void DisintigrateSpell()
    {
        Utility.instance.DamageNumber(this, "Disintigrate", SpriteList.instance.mage);
        Animator r = Instantiate(GameObjectList.instance.animator);
        r.GetComponent<DestroyOverTime>().time = 0.5f;
        r.transform.position = new Vector3(target.transform.position.x, target.transform.position.y);
        r.runtimeAnimatorController = GameObjectList.instance.disintigrate;
        float damage = SpellPower() * disintigrateDamage / 100 * magicDamageMod;
        target.GetComponent<Boss>().TakeDamage(GetComponent<Agent>(), damage, Utility.instance.Threat(damage, disintigrateThreat), false);
    }

    private void EssenceBurn()
    {
        action = $"Casting Essence Burn";
        if (essenceBurn == false)
        {
            essenceBurn = true;
            castTimer = CastTimer(essenceBurnCastTime);
            state = DecisionState.Cast;
        }
    }
    private void EssenceBurnCast()
    {
        castTimer -= Time.deltaTime;
        if (castTimer <= .1f)
        {
            mana -= essenceBurnEnergyRequired;
            essenceBurnCooldownTimer = essenceBurnCooldownTime;
            EssenceBurnHot();
            essenceBurn = false;
            state = DecisionState.Downtime;
        }
    }
    private void EssenceBurnHot()
    {
        EssenceBurn r = Instantiate(GameObjectList.instance.essenceBurn);
        r.target = this;
        r.timer = essenceBurnDuration;
        r.damage = essenceBurnDamageMod;
        r.cost = essenceBurnSpellCost;
    }
    public void EssenceRecoveryHot()
    {
        EssenceRecovery r = Instantiate(GameObjectList.instance.essenceRecovery);
        r.target = this;
        r.timer = essenceRecoveryDuration;
        r.damage = essenceRecoveryManaRegenMod;
    }
    private void FireBall()
    {
        action = $"Casting Fireball on {target.GetComponent<Boss>().characterName}";
        if (fireball == false)
        {
            fireball = true;
            castTimer = CastTimer(fireballCastTime);
            state = DecisionState.Cast;
        }
    }
    private void FireBallCast()
    {
        castTimer -= Time.deltaTime;
        if (castTimer <= .1f)
        {
            mana -= fireballEnergyRequired;
            fireballCooldownTimer = fireballCooldownTime;
            FireBallProjectile();
            fireball = false;
            state = DecisionState.Downtime;
        }
    }
    private void FireBallProjectile()
    {
        Projectile p = Instantiate(GameObjectList.instance.playerProjectile);
        p.transform.position = transform.position;
        p.GetComponent<Animator>().runtimeAnimatorController = GameObjectList.instance.fireball;
        p.effectAnimator = GameObjectList.instance.explosion;
        p.speed = 7f;
        p.damage = SpellPower() * fireballDamage / 100 * magicDamageMod;
        p.aggro = Utility.instance.Threat(p.damage, fireballThreat);
        p.aoe = true;
        p.range = fireballRadius;
        p.target = target;
        p.attacker = GetComponent<Agent>();
    }
    private void TimeDecay()
    {
        action = $"Casting Time Decay";
        if (timeDecay == false)
        {
            timeDecay = true;
            castTimer = CastTimer(timeDecayCastTime);
            state = DecisionState.Cast;
        }
    }
    private void TimeDecayCast()
    {
        castTimer -= Time.deltaTime;
        if (castTimer <= .1f)
        {
            mana -= timeDecayEnergyRequired;
            timeDecayCooldownTimer = timeDecayCooldownTime;
            TimeDecayBuff();
            TimeDecayDebuff();
            timeDecay = false;
            state = DecisionState.Downtime;
        }
    }
    private void TimeDecayBuff()
    {
        foreach(Agent a in EncounterManager.instance.currentEncounter.PlayerAndMinion())
        {
            TimeDecayBuff r = Instantiate(GameObjectList.instance.timeDecayBuff, a.transform);
            r.moveChange = timeDecayMoveBonus;
            r.timer = timeDecayTime;
            r.target = a.GetComponent<Character>();
        }
    }

    private void TimeDecayDebuff()
    {
        foreach(Agent a in EncounterManager.instance.currentEncounter.BossAndMinion())
        {
            TimeDecayDebuff r = Instantiate(GameObjectList.instance.timeDecayDebuff, a.transform);
            r.attacker = GetComponent<Agent>();
            r.damage = SpellPower() * timeDecayDotDamage / 100;
            r.threat = r.damage * timeDecayThreat / 100;
            r.threshHold = timeDecayThreshHold.ToList();
            r.timer = timeDecayTime;
            r.target = a.GetComponent<Character>();
        }        
    }


    //////
    /////
    ////
    ///
    //CHECKS
    ///
    ////
    /////
    public bool CastingArcaneShackles()
    {
        foreach (Agent e in EncounterManager.instance.currentEncounter.Mage()) if (e.GetComponent<Character>().state == DecisionState.Attack3) return true;
        return false;
    }
    public Effect ArcaneTendril(Character target)
    {
        foreach (Effect e in target.debuff) if (e.GetType() == typeof(ArcaneTendrils)) return e;
        return null;
    }

}