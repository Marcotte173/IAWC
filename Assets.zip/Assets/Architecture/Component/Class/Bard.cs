using System;
using System.Linq;
using System.Collections.Generic;
using UnityEngine;
public class Bard : Class
{
    [HideInInspector]
    public Character primaryHealTarget;
    [HideInInspector]
    public Character healTarget;
    [Header("------------------------------------------------------")]
    [Header("REDEMPTIVE")]
    [Header("Soothing Melody")]
    public float soothingMelodyPrimaryHealThreshold;
    public float soothingMelodyPartyHealThreshold;
    public float soothingMelodyRangeRequired;
    public float soothingMelodyEnergyRequired;
    public float soothingMelodyCooldownTime;
    [HideInInspector]
    public float soothingMelodyCooldownTimer;
    public float soothingMelodyCastTime;
    public float soothingMelodyThreat;
    public float soothingMelodyHotDamage;
    public float soothingMelodyHotThreat;
    public float soothingMelodyHotTime;
    [HideInInspector]
    public bool soothingMelody;
    [Header("Soothing Melody Hot")]
    public List<float> soothingMelodyHotThreshHold = new List<float> { 10, 8, 6, 4, 2, 0 };
    [HideInInspector]
    public int soothingMelodyCheck;
    [Header("Uplift")]
    public float upliftPrimaryThreshold;
    public float upliftPartyThreshold;
    public float upliftRangeRequired;
    public float upliftEnergyRequired;
    public float upliftCooldownTime;
    [HideInInspector]
    public float upliftCooldownTimer;
    public float upliftCastTime;
    public float upliftDamage;
    public float upliftThreat;
    [HideInInspector]
    public bool upliftHot;
    [Header("Uplift Hot")]
    public float upliftHotTime;
    public float upliftHotDamage;
    public float upliftHotThreat;
    [HideInInspector]
    public bool uplift;
    public List<float> upliftHotThreshHold = new List<float> { 10, 8, 6, 4, 2, 0 };
    [HideInInspector]
    public int upliftHotCheck;
    [Header("Dirge Of Demise")]
    public float dirgeOfDemisePrimaryHealThreshold;
    public float dirgeOfDemisePartyHealThreshold;
    public float dirgeOfDemiseRangeRequired;
    public float dirgeOfDemiseEnergyRequired;
    public float dirgeOfDemiseCooldownTime;
    [HideInInspector]
    public float dirgeOfDemiseCooldownTimer;
    public float dirgeOfDemiseCastTime;
    public float dirgeOfDemiseThreat;
    public float dirgeOfDemiseDamage;
    [HideInInspector]
    public bool dirgeOfDemise;
    [Header("Dirge Of Demise Buff")]
    public float dirgeOfDemiseTime;
    public float dirgeOfDemiseDamageBonus;
    [Header("Finale")]
    public float finalePrimaryHealThreshold;
    public float finalePartyHealThreshold;    
    public float finaleRangeRequired;
    public float finaleEnergyRequired;
    public float finaleCooldownTime;
    [HideInInspector]
    public float finaleCooldownTimer;
    public float finaleCastTime;
    public float finaleThreat;
    public float finaleHeal;
    public float finaleUpliftHealBonus;
    public float finaleSoothingMelodyHealBonus;
    [HideInInspector]
    public bool finale;
    [Header("Finale Buff")]
    public float finaleLength;
    public float finaleHasteBuff;
    public override void Create()
    {
        base.Create();       
        ChangeSpec();
        StartingEquipment();
        StartingCoreStats();
    }    
    public override void UpdateStuff()
    {
        base.UpdateStuff();
        if (primaryHealTarget == null) GetPrimaryHealTarget();
        Cooldowns();
        ManaRegen();
    }
    private void GetPrimaryHealTarget()
    {
        if (EncounterManager.instance.currentEncounter.Player().Count == 1) primaryHealTarget = this;
        else
        {
            List<Agent> potential = new List<Agent> { };
            foreach (Agent a in EncounterManager.instance.currentEncounter.Player()) if (a != GetComponent<Agent>()) if (a.GetComponent<Class>().spec == Spec.Stalwart) potential.Add(a);
            if (potential.Count == 0) foreach (Agent a in EncounterManager.instance.currentEncounter.Player()) if (a != GetComponent<Agent>()) if (a.GetComponent<Bard>() || a.GetComponent<Rogue>()) potential.Add(a);
            if (potential.Count == 0) foreach (Agent a in EncounterManager.instance.currentEncounter.Player()) if (a != GetComponent<Agent>()) potential.Add(a);
            primaryHealTarget = potential[0].GetComponent<Character>();
            if (potential.Count > 1) for (int i = 1; i < potential.Count; i++) if (potential[i].GetComponent<Character>().MaxHealth() > primaryHealTarget.MaxHealth()) primaryHealTarget = potential[i].GetComponent<Character>();
        }
    }

    private void ManaRegen()
    {
        manaRegenTimer -= Time.deltaTime;
        if (Mana() <= MaxMana())
        {
            if (manaRegenTimer <= 0)
            {
                mana += manaRegenValue;
                manaRegenTimer = manaRegenTime;
            }
        }
    }

    private void Cooldowns()
    {
        soothingMelodyCooldownTimer -= Time.deltaTime;
        upliftCooldownTimer -= Time.deltaTime;
        finaleCooldownTimer -= Time.deltaTime;
        dirgeOfDemiseCooldownTimer -= Time.deltaTime;
    }
    public override void Cast()
    {
        if (soothingMelody) SoothingMelodyCast();
        else if (uplift) UpliftCast();
        else if (finale) FinaleCast();
        else if (dirgeOfDemise) DirgeOfDemiseCast();
        else if (basicAttack) Attack1Cast();
    }

    

    public override void Death()
    {
        base.Death();
        basicAttack = false;
        soothingMelody = false;
        uplift = false;
        finale = false;
        dirgeOfDemise = false;
    }
    public override void Decision()
    {
        if (spec == Spec.Inspiring)
        {
            
        }
        else if (spec == Spec.Tranquil)
        {
            if (primaryHealTarget.Health() / primaryHealTarget.MaxHealth() < dirgeOfDemisePrimaryHealThreshold / 100 && dirgeOfDemiseCooldownTimer <= 0) DirgeOfDemise(primaryHealTarget);
            ///////////
            ////HEALS//
            ///////////
            ////FINALE TANK
            //if (primaryHealTarget.Health() / primaryHealTarget.MaxHealth() < finalePrimaryHealThreshold / 100 && finaleCooldownTimer <= 0) Finale(primaryHealTarget);
            ////FINALE PARTY
            //else if (SecondaryHealTarget(finalePartyHealThreshold) != null && finaleCooldownTimer <= 0) Finale(SecondaryHealTarget(finalePartyHealThreshold));
            ////DIRGE OF DEMISE TANK
            //else if (primaryHealTarget.Health() / primaryHealTarget.MaxHealth() < dirgeOfDemisePrimaryHealThreshold / 100 && dirgeOfDemiseCooldownTimer <= 0) DirgeOfDemise(primaryHealTarget);
            ////DIRG OF DEMISE SELF
            //else if (Health() / MaxHealth() < dirgeOfDemisePrimaryHealThreshold / 100 && dirgeOfDemiseCooldownTimer <= 0) DirgeOfDemise(this);
            ////UPLIFT TANK
            //else if (primaryHealTarget.Health() / primaryHealTarget.MaxHealth() < upliftPrimaryThreshold / 100 && upliftCooldownTimer <= 0) Uplift(primaryHealTarget);
            ////UPLIFT SELF
            //else if (Health() / MaxHealth() < upliftPrimaryThreshold / 100 && upliftCooldownTimer <= 0) Uplift(this);
            ////UPLIFT PARTY
            //else if (primaryHealTarget.Health() / primaryHealTarget.MaxHealth() < upliftPartyThreshold / 100 && upliftCooldownTimer <= 0) Uplift(primaryHealTarget);
            ////SOOTHING MELODY TANK
            //else if (primaryHealTarget.Health() / primaryHealTarget.MaxHealth() < soothingMelodyPrimaryHealThreshold / 100 && soothingMelodyCooldownTimer <= 0) SoothingMelody(primaryHealTarget);
            ////DIG OF DEMISE PARTY
            //else if (SecondaryHealTarget(dirgeOfDemisePartyHealThreshold) != null && dirgeOfDemiseCooldownTimer <= 0) DirgeOfDemise(SecondaryHealTarget(dirgeOfDemisePartyHealThreshold));
            ////SOOTHING MELODY  SELF
            //else if (Health() / MaxHealth() < soothingMelodyPrimaryHealThreshold / 100 && soothingMelodyCooldownTimer <= 0) SoothingMelody(this);
            ////SOOTHING MELODY  PARTY
            //else if (SecondaryHealTarget(soothingMelodyPartyHealThreshold) != null && soothingMelodyCooldownTimer <= 0) SoothingMelody(SecondaryHealTarget(soothingMelodyPartyHealThreshold));
            //END HEALS
            //BASIC ATTACK
            else if (basicAttackCooldownTimer <= 0)
            {
                action = $"Attacking {target.GetComponent<Boss>().characterName}";
                state = DecisionState.Attack1;
            }
        }
    }

    

    public override void ChangeSpec()
    {
        spec = (specNumber == 0) ? Spec.Tranquil : Spec.Inspiring;
    }
    public override void SpriteOn()
    {
        characterNameText.text = characterName;
        GetComponent<SpriteRenderer>().sprite = SpriteList.instance.bardSprite[specNumber];
    }

    public override void StartingEquipment()
    {
        Equip.instance.EquipHead((spec == Spec.Tranquil) ? ItemList.instance.startingHead[2] : ItemList.instance.startingHead[1], head);
        Equip.instance.EquipChest((spec == Spec.Tranquil) ? ItemList.instance.startingChest[2] : ItemList.instance.startingChest[1], chest);
        Equip.instance.EquipLegs((spec == Spec.Tranquil) ? ItemList.instance.startingLegs[2] : ItemList.instance.startingLegs[1], legs);
        Equip.instance.EquipFeet((spec == Spec.Tranquil) ? ItemList.instance.startingFeet[2] : ItemList.instance.startingFeet[1], feet);
        Equip.instance.EquipTrinket((spec == Spec.Tranquil) ? ItemList.instance.startingTrinket[2] : ItemList.instance.startingTrinket[0], trinket);
        Equip.instance.EquipWeapon((spec == Spec.Tranquil) ? ItemList.instance.startingWeapon[2] : ItemList.instance.startingWeapon[0], weapon);
        Equip.instance.EquipOffHand((spec == Spec.Tranquil) ? ItemList.instance.startingOffHand[2] : ItemList.instance.startingOffHand[0], offHand);
    }
    public override void Attack2()
    {
        base.Attack2();
        if (spec == Spec.Tranquil && InRange(soothingMelodyRangeRequired)) SoothingMelody();
        else { }
    }
    public override void Attack3()
    {
        base.Attack3();
        if (spec == Spec.Tranquil && InRange(upliftRangeRequired)) Uplift();
        else { }
    }
    public override void Attack4()
    {
        base.Attack4();
        if (spec == Spec.Tranquil && InRange(dirgeOfDemiseRangeRequired)) DirgeOfDemise();
        else { }
    }
    public override void Attack5()
    {
        base.Attack5();
        if (spec == Spec.Tranquil && InRange(finaleRangeRequired)) Finale();
        else { }
    }

    //////
    /////
    ////
    ///
    //ABILITIES
    ///
    ////
    /////
    //////

    private void DirgeOfDemise(Character target)
    {
        if (Mana() >= dirgeOfDemiseEnergyRequired)
        {
            healTarget = target;
            state = DecisionState.Attack4;
            action = $"Moving Towards {healTarget.GetComponent<Class>().characterName}";
        }
        else
        {
            action = $"Waiting to cast";
        }
    }
    private void DirgeOfDemise()
    {
        action = $"Casting Dirge Of Demise on {healTarget.characterName}";
        if (dirgeOfDemise == false)
        {
            dirgeOfDemise = true;
            castTimer = CastTimer(dirgeOfDemiseCastTime);
            state = DecisionState.Cast;
        }
    }
    private void DirgeOfDemiseCast()
    {
        castTimer -= Time.deltaTime;
        if (castTimer <= 0)
        {
            dirgeOfDemise = false;
            mana -= dirgeOfDemiseEnergyRequired;
            dirgeOfDemiseCooldownTimer = dirgeOfDemiseCooldownTime;
            Utility.instance.DamageNumber(this, "Dirge Of Demise", SpriteList.instance.bard);
            healTarget.Heal(dirgeOfDemiseDamage * SpellPower() / 100);
            foreach (Agent a in EncounterManager.instance.currentEncounter.Boss()) Utility.instance.Aggro(a.GetComponent<Boss>(), GetComponent<Agent>(), (dirgeOfDemiseDamage / 100 * SpellPower()) * dirgeOfDemiseThreat / 100);
            if (DirgeOfDemiseBuffCheck(healTarget.GetComponent<Character>()) == null) DirgeOfDemiseBuff();
            else DirgeOfDemiseBuffCheck(healTarget.GetComponent<Character>()).timer = dirgeOfDemiseTime;
            state = DecisionState.Downtime;
        }
    }
    private void DirgeOfDemiseBuff()
    {
        DirgeOfDemiseBuff h = Instantiate(GameObjectList.instance.dirgeOfDemiseBuff, healTarget.transform);
        h.attacker = GetComponent<Agent>();
        h.damage = SpellPower() * dirgeOfDemiseDamageBonus / 100;
        h.timer = soothingMelodyHotTime;
        h.target = healTarget.GetComponent<Character>();
    }

    private void Finale(Character target)
    {
        if (Mana() >= finaleEnergyRequired)
        {
            healTarget = target;
            state = DecisionState.Attack5;
            action = $"Moving Towards {healTarget.GetComponent<Class>().characterName}";
        }
        else
        {
            action = $"Waiting to cast";
        }
    }
    private void Finale()
    {
        action = $"Casting Finale on {healTarget.characterName}";
        if (finale == false)
        {
            finale = true;
            castTimer = CastTimer(finaleCastTime);
            state = DecisionState.Cast;
        }
    }
    private void FinaleCast()
    {
        castTimer -= Time.deltaTime;
        if (castTimer <= 0)
        {
            float healBonus = 0;
            mana -= finaleEnergyRequired;
            finaleCooldownTimer = finaleCooldownTime;
            finale = false;
            if (MySoothingMelody(target.GetComponent<Character>()) != null)
            {
                SoothingMelodyHot r = MySoothingMelody(target.GetComponent<Character>());
                target.GetComponent<Character>().buff.Remove(r);
                Destroy(r.gameObject.gameObject);
                healBonus += finaleSoothingMelodyHealBonus;
            }
            if (MyUplift(target.GetComponent<Character>()))
            {
                UpliftHot r = MyUplift(target.GetComponent<Character>());
                target.GetComponent<Character>().buff.Remove(r);
                Destroy(r.gameObject.gameObject);
                healBonus += finaleUpliftHealBonus;
            }
            float damage = SpellPower() * (finaleHeal + healBonus) / 100 * magicDamageMod;
            target.GetComponent<Boss>().TakeDamage(GetComponent<Agent>(), damage, Utility.instance.Threat(damage, finaleThreat), false);
            state = DecisionState.Downtime;
        }
    }
    private void FinaleBuff()
    {
        
    }

    private void SoothingMelody(Character target)
    {
        if (Mana() >= soothingMelodyEnergyRequired)
        {
            healTarget = target;
            state = DecisionState.Attack2;
            action = $"Moving Towards {healTarget.GetComponent<Class>().characterName}";
        }
        else
        {
            action = $"Waiting to cast";
        }
    }
    private void SoothingMelody()
    {
        action = $"Casting Soothing Melody on {healTarget.characterName}";
        if (soothingMelody == false)
        {
            soothingMelody = true;
            castTimer = CastTimer(finaleCastTime);
            state = DecisionState.Cast;
        }
    }
    
    private void SoothingMelodyCast()
    {
        castTimer -= Time.deltaTime;
        if (castTimer <= 0)
        {
            soothingMelody = false;
            mana -= soothingMelodyEnergyRequired;
            soothingMelodyCooldownTimer = soothingMelodyCooldownTime;
            Utility.instance.DamageNumber(this, "Soothing Melody", SpriteList.instance.bard);
            if (SoothingMelodyHotCheck(healTarget.GetComponent<Character>()) == null) SoothingMelodyHot();
            else SoothingMelodyHotCheck(healTarget.GetComponent<Character>()).timer = soothingMelodyHotTime;
            state = DecisionState.Downtime;
        }
    }
    private void SoothingMelodyHot()
    {
        SoothingMelodyHot h = Instantiate(GameObjectList.instance.soothingMelodyHot, healTarget.transform);
        h.attacker = GetComponent<Agent>();
        h.damage = SpellPower() * soothingMelodyHotDamage / 100;
        h.threat = h.damage * soothingMelodyHotThreat / 100;
        h.threshHold = soothingMelodyHotThreshHold.ToList();
        h.timer = soothingMelodyHotTime;
        h.target = healTarget.GetComponent<Character>();
    }
    private void Uplift(Character target)
    {
        if (Mana() >= upliftEnergyRequired && upliftCooldownTimer <= 0)
        {
            healTarget = target;
            state = DecisionState.Attack3;
            action = $"Moving Towards {healTarget.GetComponent<Class>().characterName}";
        }
        else
        {
            action = $"Waiting to cast";
        }
    }
    private void Uplift()
    {
        action = $"Casting Uplift on {healTarget.characterName}";
        if (uplift == false)
        {
            uplift = true;
            castTimer = CastTimer(upliftCastTime);
            state = DecisionState.Cast;
        }
    }
    private void UpliftCast()
    {
        Debug.Log("Poo");
        castTimer -= Time.deltaTime;
        if (castTimer <= 0)
        {
            uplift = false;
            mana -= upliftEnergyRequired;
            upliftCooldownTimer = upliftCooldownTime;
            Utility.instance.DamageNumber(this, "Uplift", SpriteList.instance.bard);
            healTarget.Heal(upliftDamage * SpellPower() / 100);
            foreach (Agent a in EncounterManager.instance.currentEncounter.Boss()) Utility.instance.Aggro(a.GetComponent<Boss>(), GetComponent<Agent>(), (upliftDamage / 100 * SpellPower()) * upliftThreat / 100);
            if (UpliftHotCheck(healTarget.GetComponent<Character>()) == null) UpliftHot();
            else UpliftHotCheck(healTarget.GetComponent<Character>()).timer = upliftHotTime;
            state = DecisionState.Downtime;
        }
    }
    private void UpliftHot()
    {
        UpliftHot h = Instantiate(GameObjectList.instance.upliftHot, healTarget.transform);
        h.attacker = GetComponent<Agent>();
        h.damage = SpellPower() * upliftHotDamage / 100;
        h.threat = h.damage * upliftHotThreat / 100;
        h.threshHold = upliftHotThreshHold.ToList();
        h.timer = upliftHotTime;
        h.target = healTarget.GetComponent<Character>();
    }






    //////
    /////
    ////
    ///
    //CHECKS
    ///
    ////
    /////
    /////

    private Character SecondaryHealTarget(float threshold)
    {
        if (EncounterManager.instance.currentEncounter.Player().Count > 1)
        {
            List<Agent> potential = new List<Agent> { };
            foreach (Agent a in EncounterManager.instance.currentEncounter.Player()) if (a != GetComponent<Agent>() && a.GetComponent<Class>().spec != Spec.Stalwart && a.GetComponent<Character>().Health() / a.GetComponent<Character>().MaxHealth() < threshold / 100) potential.Add(a);
            if (potential.Count > 0)
            {
                Character target = potential[0].GetComponent<Character>();
                if (potential.Count > 1) for (int i = 1; i < potential.Count; i++) if (potential[i].GetComponent<Character>().Health() < target.Health()) target = potential[i].GetComponent<Character>();
                return target;
            }
        }
        return null;
    }
    public Effect UpliftHotCheck(Character target)
    {
        foreach (Effect e in target.buff) if (e.GetType() == typeof(UpliftHot)) return e;
        return null;
    }
    public Effect SoothingMelodyHotCheck(Character target)
    {
        foreach (Effect e in target.buff) if (e.GetType() == typeof(SoothingMelodyHot)) return e;
        return null;
    }
    public Effect DirgeOfDemiseBuffCheck(Character target)
    {
        foreach (Effect e in target.buff) if (e.GetType() == typeof(DirgeOfDemiseBuff)) return e;
        return null;
    }
    public SoothingMelodyHot MySoothingMelody(Character target)
    {
        foreach (Effect e in target.debuff) if (e.GetType() == typeof(SoothingMelodyHot) && e.attacker == GetComponent<Agent>()) return (SoothingMelodyHot)e;
        return null;
    }
    public UpliftHot MyUplift(Character target)
    {
        foreach (Effect e in target.debuff) if (e.GetType() == typeof(UpliftHot) && e.attacker == GetComponent<Agent>()) return (UpliftHot)e;
        return null;
    }
}