using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class ShieldBearer : Class
{    
    public override void Create()
    {
        base.Create();
        ChangeSpec();
        StartingEquipment();
        StartingCoreStats();
    }
    public override void Death()
    {
        base.Death();
        basicAttack = false;
    }
    public override void UpdateStuff()
    {
        base.UpdateStuff();
        manaRegenTimer -= Time.deltaTime;
        if (Mana() <= MaxMana())
        {
            if (manaRegenTimer <= 0)
            {
                mana += manaRegenValue;
                manaRegenTimer = manaRegenTime;
            }
        }
    }    
    public override void ChangeSpec()
    {
        spec = (specNumber == 0) ? Spec.Stalwart : Spec.Inspiring;
    }
    public override void SpriteOn()
    {
        characterNameText.text = characterName;
        GetComponent<SpriteRenderer>().sprite = SpriteList.instance.shieldBearerSprite[specNumber];
    }
    public override void StartingEquipment()
    {
        Equip.instance.EquipHead((spec == Spec.Stalwart) ? ItemList.instance.startingHead[5]: ItemList.instance.startingHead[4], head);
        Equip.instance.EquipChest((spec == Spec.Stalwart) ? ItemList.instance.startingChest[5]: ItemList.instance.startingChest[4], chest);
        Equip.instance.EquipLegs((spec == Spec.Stalwart) ? ItemList.instance.startingLegs[5]: ItemList.instance.startingLegs[4], legs);
        Equip.instance.EquipFeet((spec == Spec.Stalwart) ? ItemList.instance.startingFeet[5]: ItemList.instance.startingFeet[4], feet);
        Equip.instance.EquipTrinket((spec == Spec.Stalwart)?ItemList.instance.startingTrinket[3]: ItemList.instance.startingTrinket[2], trinket);
        Equip.instance.EquipWeapon((spec == Spec.Stalwart) ? ItemList.instance.startingWeapon[3]:ItemList.instance.startingWeapon[2], weapon);
        Equip.instance.EquipOffHand((spec == Spec.Stalwart) ? ItemList.instance.startingOffHand[3]: ItemList.instance.startingOffHand[2], offHand);
    }
    public override void Attack1()
    {

    }
    public override void Attack2()
    {

    }
    public override void Attack3()
    {

    }
    public override void Attack4()
    {

    }
}