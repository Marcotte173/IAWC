using System;
using System.Linq;
using System.Collections.Generic;
using UnityEngine;


public class Beserker : Class
{   
    [Header("Taunt")]
    [Header("------------------------------------------------------")]
    [Header("STALWART")]   
    public float tauntRangeRequired;
    public float tauntEnergyRequired;
    public float tauntCooldownTime;
    [HideInInspector]
    public float tauntCooldownTimer;
    [HideInInspector]
    public bool taunt;
    public float tauntCastTime;
    public float tauntTime;    
    [Header("Raging Endurance")]
    public float ragingEnduranceCooldownTime;
    [HideInInspector]
    public float ragingEnduranceCooldownTimer;
    public float ragingEnduranceHeal;
    public float ragingEnduranceHealthThreshhold;
    [HideInInspector]
    public bool ragingEnduranceNextAttackMitigate;
    public float ragingEnduranceNextAttackMitigation;
    public float ragingEnduranceCastTime;
    [HideInInspector]
    public bool ragingEndurance;
    [Header("Too Angry to Die")]
    public float tooAngryToDieEnergyRequired;
    public float tooAngryToDieCooldownTime;
    [HideInInspector]
    public float tooAngryToDieCooldownTimer;
    public float tooAngryToDieTime;
    [HideInInspector]
    public float tooAngryToDieTimer;
    public float tooAngryToDieVampBonus;
    public float tooAngryToDieVampBonusParty;
    public float tooAngryToDieThreshHold;
    public float tooAngryToDieCastTime;
    [HideInInspector]
    public bool tooAngryToDie;
    [Header("------------------------------------------------------")]
    [Header("FOCUSED")]
    [Header("Slam")]
    public float slamRangeRequired;
    public float slamEnergyRequired;
    public float slamCooldownTime;
    [HideInInspector]
    public float slamCooldownTimer;
    public float slamDamage;
    public float slamThreat;
    public float slamCastTime;
    [HideInInspector]
    public bool slam;
    [Header("Savage Blow")]
    public float savageBlowRangeRequired;
    public float savageBlowEnergyRequired;
    public float savageBlowCooldownTime;
    [HideInInspector]
    public float savageBlowCooldownTimer;
    public float savageBlowDamage;
    public float savageBlowThreat;
    public float savageBlowDotTime;
    public float savageBlowDotDamage;
    public float savageBlowCastTime;
    [HideInInspector]
    public bool savageBlow;
    public List<float> savageBlowThreshHold = new List<float> { 10, 8, 6, 4, 2, 0 };
    [Header("Warcry")]  
    public float warCryRequiredEnergy;
    public float warCryCooldownTime;
    [HideInInspector]
    public float warCryCooldownTimer;
    public float warCryCritBonus;
    public float warCryLengthTime;
    [HideInInspector]
    public float warCryLengthTimer;
    public float warCryCastTime;
    [HideInInspector]
    public bool warCry;
    [Header("------------------------------------------------------")]
    [Header("Universal")]
    [Header("Reckless Swing")]
    public float recklessSwingRangeRequired;
    public float recklessSwingEnergyRequired;
    public float recklessSwingCooldownTime;
    [HideInInspector]
    public float recklessSwingCooldownTimer;
    public float recklessSwingDamagePrimary;
    public float recklessSwingDamageSecondary;
    public float recklessSwingDefenceNerfAmount;
    public float recklessSwingDefenceNerfTime;
    public float recklessSwingThreat;
    public float recklessSwingCastTime;
    [HideInInspector]
    public bool recklessSwing;
    [Header("Energy Gain On Hit")]
    public float energyGainOnHit;
    public float energyGainOnReceiveHit;

    public override void UpdateStuff()
    {
        base.UpdateStuff();
        Cooldowns();        
    }
    public override void Cast()
    {
        if (basicAttack) Attack1Cast();
        else if (slam) SlamCast();
        else if (tooAngryToDie) TooAngryToDieCast();
        else if (taunt) TauntCast();
        else if (ragingEndurance) RagingEnduranceCast();
        else if (warCry) WarcryCast();
        else if (savageBlow) SavageBlowCast();
        else if (recklessSwing) RecklessSwingCast();
    }
    public override void Death()
    {
        base.Death();
        slam = false;
        tooAngryToDie = false;
        taunt = false;
        ragingEndurance = false;
        warCry = false;
        savageBlow = false;
        recklessSwing = false;
        basicAttack = false;
    }
    private void Cooldowns()
    {
        slamCooldownTimer -= Time.deltaTime;
        tooAngryToDieCooldownTimer -= Time.deltaTime;
        tauntCooldownTimer -= Time.deltaTime;
        ragingEnduranceCooldownTimer -= Time.deltaTime;
        warCryCooldownTimer -= Time.deltaTime;
        savageBlowCooldownTimer -= Time.deltaTime;
        recklessSwingCooldownTimer -= Time.deltaTime;
    }

    public override void Create()
    {
        base.Create();
        ChangeSpec();
        StartingEquipment();
        StartingCoreStats();
    }
    
    public override void ChangeSpec()
    {
        spec = (specNumber == 0) ?Spec.Stalwart:Spec.Focused;
    }
    public override void SpriteOn()
    {
        characterNameText.text = characterName;
        GetComponent<SpriteRenderer>().sprite = SpriteList.instance.beserkerSprite[specNumber];
    }
    public override void Decision()
    {
        if(spec == Spec.Stalwart)
        {
            //Too Angry To die
            if (Health()/MaxHealth()<tooAngryToDieThreshHold && tooAngryToDieCooldownTimer <= 0&& Mana() >= tooAngryToDieEnergyRequired)
            {
                state = DecisionState.Attack4;
            }
            //Taunt
            else if (GetComponent<Character>().target.GetComponent<Boss>().aggro.Count > 0&& tauntCooldownTimer<=0 && GetComponent<Character>().target.GetComponent<Boss>().aggro[0] != GetComponent<Agent>() && Mana() >= tauntEnergyRequired)
            {
                action = $"Moving towards {target.GetComponent<Boss>().characterName}";
                state = DecisionState.Attack3;               
            }
            //RECKLESS SWING
            else if (EnemiesInRange(this, recklessSwingRangeRequired).Count > 1 && Mana() >= recklessSwingEnergyRequired && Vector2.Distance(transform.position, target.transform.position) <= recklessSwingRangeRequired && recklessSwingCooldownTimer <= 0) state = DecisionState.Attack2;
            //Basic attack
            else if(basicAttackCooldownTimer <= 0)
            {
                action = $"Moving towards {target.GetComponent<Boss>().characterName}";
                state = DecisionState.Attack1;
            }
        }
        else if (spec == Spec.Focused)
        {
            //WARCRY
            if(Mana()>= warCryRequiredEnergy && warCryCooldownTimer <= 0) state = DecisionState.Attack4;
            //RECKLESS SWING
            else if (EnemiesInRange(this, recklessSwingRangeRequired).Count > 1 && Mana() >= recklessSwingEnergyRequired && Vector2.Distance(transform.position, target.transform.position) <= recklessSwingRangeRequired && recklessSwingCooldownTimer <= 0) state = DecisionState.Attack2;
            //SAVAGE BLOW
            else if (Mana() >= savageBlowEnergyRequired && warCryCooldownTimer > 0 && savageBlowCooldownTimer<=0) state = DecisionState.Attack5;           
            //SLAM
            else if (Mana() >= slamEnergyRequired && slamCooldownTimer <= 0&& warCryCooldownTimer>0&& savageBlowCooldownTimer>0)
            {
                action = $"Moving towards {target.GetComponent<Boss>().characterName}";
                state = DecisionState.Attack3;
            }
            //Basic attack
            else if (basicAttackCooldownTimer <= 0)
            {
                action = $"Moving towards {target.GetComponent<Boss>().characterName}";
                state = DecisionState.Attack1;
            }
        }        
    }
    public override void StartingEquipment()
    {
        Equip.instance.EquipHead((spec == Spec.Stalwart)?ItemList.instance.startingHead[5]: ItemList.instance.startingHead[3], head);
        Equip.instance.EquipChest((spec == Spec.Stalwart)?ItemList.instance.startingChest[5]: ItemList.instance.startingChest[3], chest);
        Equip.instance.EquipLegs((spec == Spec.Stalwart)?ItemList.instance.startingLegs[5]: ItemList.instance.startingLegs[3], legs);
        Equip.instance.EquipFeet((spec == Spec.Stalwart)?ItemList.instance.startingFeet[5]: ItemList.instance.startingFeet[3], feet);
        Equip.instance.EquipTrinket((spec == Spec.Stalwart)?ItemList.instance.startingTrinket[3]: ItemList.instance.startingTrinket[1], trinket);
        Equip.instance.EquipWeapon((spec == Spec.Stalwart) ? ItemList.instance.startingWeapon[3]: ItemList.instance.startingWeapon[1], weapon);
        Equip.instance.EquipOffHand((spec == Spec.Stalwart) ? ItemList.instance.startingOffHand[3]: ItemList.instance.startingOffHand[1], offHand);
    }
    public override void Attack1Cast()
    {
        base.Attack1Cast();          
    }

    public override void EnergyGain()
    {
        if (mana + energyGainOnHit <= 100) mana += energyGainOnHit;
    }

    public override void Attack2()
    {
        base.Attack2();
        if (rangeToTarget <= recklessSwingRangeRequired && !move.unwalkable.Contains(move.currentTile)) RecklessSwing();
    }
    

    public override void Attack3()
    {
        base.Attack3();
        if (spec == Spec.Stalwart && InRange(tauntRangeRequired)) Taunt();
        else if (spec == Spec.Focused && InRange(slamRangeRequired)) Slam();
    }    

    public override void Attack4()
    {
        base.Attack4();
        if (spec == Spec.Stalwart) TooAngryToDie();
        else if (spec == Spec.Focused) Warcry();
    }   

    public override void Attack5()
    {
        base.Attack5();
        if (InRange(savageBlowRangeRequired)) SavageBlow();
    }    

    public override void Move()
    {
        base.Move();
    }
    public override void StopDPS()
    {
        base.StopDPS();
    }
    public override void TakeDamage(Agent attacker, float damage, bool physical)
    {
        bool crit = false;
        Character character = GetComponent<Character>();
        Character aChar = attacker.GetComponent<Character>();
        //Damage
        if (physical)
        {
            if (UnityEngine.Random.Range(1, 101) < attacker.GetComponent<Character>().Crit())
            {
                damage *= 2;
                crit = true;
                if(spec == Spec.Stalwart&&ragingEnduranceCooldownTimer <= 0)RagingEndurance();
            }
        }
        if (physical) damage *= (200 / (200 + character.Defence()));
        if (spec == Spec.Stalwart && ragingEnduranceNextAttackMitigate)
        {
            damage *= ragingEnduranceNextAttackMitigation;
            ragingEnduranceNextAttackMitigate = false;
        }
        mana += Mathf.Round(damage * energyGainOnReceiveHit);
        health -= damage;
        if (spec == Spec.Stalwart && Health() / MaxHealth() <= ragingEnduranceHealthThreshhold&& ragingEnduranceCooldownTimer<=0) RagingEndurance();
        if (aChar.Vamp() > 0) aChar.Heal(damage * aChar.Vamp() / 100f);
        Utility.instance.DamageNumber(this, Convert.ToInt32(damage).ToString(), (crit) ? SpriteList.instance.critColor : (physical) ? SpriteList.instance.damageColor : SpriteList.instance.magicColor);
        if (Health() <= 0) Death();
    }

    ////
    ///
    //ABILITIES
    ///
    ////

    private void RagingEndurance()
    {
        action = $"Casting Raging Endurance";
        if (!ragingEndurance)
        {
            ragingEndurance = true;
            castTimer = CastTimer(ragingEnduranceCastTime);            
            state = DecisionState.Cast;
        }        
    }
    public void RagingEnduranceCast()
    {
        castTimer -= Time.deltaTime;
        if (castTimer <= .1f)
        {
            ragingEnduranceCooldownTimer = ragingEnduranceCooldownTime;
            ragingEndurance = false;
            Heal(MaxHealth() * ragingEnduranceHeal);
            ragingEnduranceNextAttackMitigate = true;            
            Utility.instance.DamageNumber(this, "Raging Endurance", SpriteList.instance.beserker);
            state = DecisionState.Downtime;
        }
    }

    private void RecklessSwing()
    {
        action = $"Casting Reckless Swing at {target.GetComponent<Boss>().characterName}";
        if (!recklessSwing)
        {
            recklessSwing = true;            
            castTimer = CastTimer(recklessSwingCastTime);            
            state = DecisionState.Cast;
        }       
    }

    public void RecklessSwingCast()
    {
        castTimer -= Time.deltaTime;
        if (castTimer <= .1f)
        {
            mana -= recklessSwingEnergyRequired;
            recklessSwingCooldownTimer = recklessSwingCooldownTime;
            recklessSwing = false;
            Utility.instance.DamageNumber(GetComponent<Character>(), $"Reckless Swing", SpriteList.instance.beserker);
            float primaryDam = Damage() * recklessSwingDamagePrimary / 100;
            float secondaryDamage = Damage() * recklessSwingDamageSecondary / 100;
            List<Character> enemies = EnemiesInRange(this, recklessSwingRangeRequired);
            foreach (Character c in enemies)
            {
                if (c != target)
                {
                    c.GetComponent<Boss>().TakeDamage(GetComponent<Agent>(), secondaryDamage, Utility.instance.Threat(secondaryDamage, slamThreat), true);
                    break;
                }
            }            
            RecklessSwingDefenceNerf();
            target.GetComponent<Boss>().TakeDamage(GetComponent<Agent>(), primaryDam, Utility.instance.Threat(primaryDam, slamThreat), true);
            state = DecisionState.Downtime;
        }
    }
    void RecklessSwingDefenceNerf()
    {
        RecklessSwingDefenceNerf r = Instantiate(GameObjectList.instance.recklessSwingDefenceNerf, target.transform);
        r.attacker = GetComponent<Agent>();
        r.damage = recklessSwingDefenceNerfAmount;
        r.timer = recklessSwingDefenceNerfTime;
        r.target = GetComponent<Character>();
    }
    
    private void SavageBlow()
    {
        action = $"Casting Savage Blow at {target.GetComponent<Boss>().characterName}";
        if (!savageBlow)
        {
            savageBlow = true;           
            castTimer = CastTimer(savageBlowCastTime);           
            state = DecisionState.Cast;
        }        
    }
    public void SavageBlowCast()
    {
        castTimer -= Time.deltaTime;
        if (castTimer <= .1f)
        {
            mana -= savageBlowEnergyRequired;
            savageBlowCooldownTimer = savageBlowCooldownTime;
            Utility.instance.DamageNumber(this, "Savage Blow", SpriteList.instance.beserker);
            SavageBlowDot();
            savageBlow = false;
            float damage = Damage() * savageBlowDamage / 100;
            target.GetComponent<Boss>().TakeDamage(GetComponent<Agent>(), damage, Utility.instance.Threat(damage, savageBlowThreat), true);
            state = DecisionState.Downtime;
        }
    }
    public void SavageBlowDot()
    {
        SavageBlowDot r = Instantiate(GameObjectList.instance.savageBlowDot, target.transform);
        r.attacker = GetComponent<Agent>();
        r.damage = Damage() * savageBlowDotDamage / 100;
        r.timer = savageBlowDotTime;
        r.target = target.GetComponent<Character>();
        r.threshHold = savageBlowThreshHold.ToList();
    }

    private void Slam()
    {
        action = $"Casting Slam at {target.GetComponent<Boss>().characterName}";
        if (!slam)
        {
            slam = true;           
            castTimer = CastTimer(slamCastTime);           
            state = DecisionState.Cast;
        }       
    }
    public void SlamCast()
    {
        castTimer -= Time.deltaTime;
        if (castTimer <= .1f)
        {
            mana -= slamEnergyRequired;
            slamCooldownTimer = slamCooldownTime;
            slam = false;
            float damage = Damage() * slamDamage / 100;
            target.GetComponent<Boss>().TakeDamage(GetComponent<Agent>(), damage, Utility.instance.Threat(damage, slamThreat), true);
            Utility.instance.DamageNumber(this, "Slam", SpriteList.instance.beserker);
            state = DecisionState.Downtime;
        }
    }

    private void Taunt()
    {
        action = $"Casting Taunt at {target.GetComponent<Boss>().characterName}";
        if (!taunt)
        {
            taunt = true;            
            castTimer = CastTimer(tauntCastTime);            
            state = DecisionState.Cast;
        }    
    }
    public void TauntCast()
    {
        castTimer -= Time.deltaTime;
        if (castTimer <= .1f)
        {
            mana -= tauntEnergyRequired;
            tauntCooldownTimer = tauntCooldownTime;
            TauntDot();
            state = DecisionState.Downtime;
        }
    }

    private void TauntDot()
    {
        Taunt r = Instantiate(GameObjectList.instance.taunt, target.transform);
        r.attacker = GetComponent<Agent>();
        r.timer = tauntTime;
        taunt = false;
        r.target = target.GetComponent<Character>();
    }

    private void TooAngryToDie()
    {
        action = $"Casting Too Angry to Die";
        if (!tooAngryToDie)
        {
            tooAngryToDie = true;           
            castTimer = CastTimer(tooAngryToDieCastTime);           
            state = DecisionState.Cast;
        }        
    }
    public void TooAngryToDieCast()
    {
        castTimer -= Time.deltaTime;
        if (castTimer <= .1f)
        {
            mana -= tooAngryToDieEnergyRequired;
            tooAngryToDieCooldownTimer = tooAngryToDieCooldownTime;
            tooAngryToDie = false;
            foreach (Agent a in EncounterManager.instance.currentEncounter.Player()) TooAngryToDieBuff(a);
            Utility.instance.DamageNumber(this, "Too Angry To Die!", SpriteList.instance.beserker);
            state = DecisionState.Downtime;
        }
    }

    void TooAngryToDieBuff(Agent a)
    {
        TooAngryToDie r = Instantiate(GameObjectList.instance.tooAngryToDie, a.transform);
        r.attacker = GetComponent<Agent>();
        r.timer = tooAngryToDieTime;
        r.target = a.GetComponent<Character>();
        if (a != GetComponent<Agent>()) r.damage = tooAngryToDieVampBonusParty;
        else r.damage = tooAngryToDieVampBonus;
    }
    private void Warcry()
    {
        action = $"Casting Warcry";
        if (!warCry)
        {
            warCry = true;            
            castTimer = CastTimer(warCryCastTime);           
            state = DecisionState.Cast;
        }        
    }
    public void WarcryCast()
    {
        castTimer -= Time.deltaTime;
        if (castTimer <= .1f)
        {
            mana -= warCryRequiredEnergy;
            warCryCooldownTimer = warCryCooldownTime;
            warCry = false;
            foreach (Agent a in EncounterManager.instance.currentEncounter.Player()) WarcryBuff(a);
            Utility.instance.DamageNumber(this, "Warcry", SpriteList.instance.beserker);
            state = DecisionState.Downtime;
        }
    }

    void WarcryBuff(Agent a)
    {
        Warcry r = Instantiate(GameObjectList.instance.warcry, a.transform);
        r.attacker = GetComponent<Agent>();
        r.timer = warCryLengthTime;
        r.target = a.GetComponent<Character>();        
    }
}