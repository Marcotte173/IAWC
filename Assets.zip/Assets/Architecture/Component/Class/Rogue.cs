using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Rogue : Class
{    
   public override void Create()
    {
        base.Create();
        ChangeSpec();
        StartingEquipment();
        StartingCoreStats();
    }
    public override void ChangeSpec()
    {
        spec = (specNumber == 0) ? Spec.Focused : Spec.Wrathful;
    }
    public override void Death()
    {
        base.Death();
        basicAttack = false;
    }
    public override void SpriteOn()
    {
        characterNameText.text = characterName;
        GetComponent<SpriteRenderer>().sprite = SpriteList.instance.rogueSprite[specNumber];
    }

    public override void UpdateStuff()
    {
        base.UpdateStuff();
        manaRegenTimer -= Time.deltaTime;
        if (Mana() <= MaxMana())
        {
            if (manaRegenTimer <= 0)
            {
                mana += manaRegenValue;
                manaRegenTimer = manaRegenTime;
            }
        }
    }
    public override void StartingEquipment()
    {
        Equip.instance.EquipHead(ItemList.instance.startingHead[1], head);
        Equip.instance.EquipChest(ItemList.instance.startingChest[1], chest);
        Equip.instance.EquipLegs(ItemList.instance.startingLegs[1], legs);
        Equip.instance.EquipFeet(ItemList.instance.startingFeet[1], feet);
        Equip.instance.EquipTrinket(ItemList.instance.startingTrinket[1], trinket);
        Equip.instance.EquipWeapon(ItemList.instance.startingWeapon[1], weapon);
        Equip.instance.EquipOffHand(ItemList.instance.startingOffHand[1], offHand);
    }
    public override void Attack1()
    {

    }
    public override void Attack2()
    {

    }
    public override void Attack3()
    {

    }
    public override void Attack4()
    {

    }
}