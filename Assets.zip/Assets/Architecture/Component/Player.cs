using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public enum AggroDecision {Avoid,Kite,Bezerk };
public enum HazardDecision {Avoid,RunThrough,Tank };
public class Player : MonoBehaviour
{
    public string playerName;
    public float decisionTime;
    public float downTime;
    public float hazardAware;
    public float hazardAwareTimer;
    public float aggroReact;
    public float aggroBelief;
    public float aggroReactTimer;
    public float aggroThreshold;
    public float skill;
    public Tile moveTarget;
    public AggroDecision aggroDec;
    public HazardDecision hazardDec;
    private void Awake()
    {
        decisionTime = UnityEngine.Random.Range(0.2f, 1.4f);
        downTime = UnityEngine.Random.Range(0.2f, 1.4f);
        hazardAware = UnityEngine.Random.Range(0.2f, 2.2f);
        aggroReact = UnityEngine.Random.Range(0.2f, 5.6f);
        GetComponent<Class>().decisionTime = decisionTime;
        GetComponent<Class>().downTime     = downTime;
        hazardAwareTimer = hazardAware / UnityEngine.Random.Range(0.5f, 2.9f); 
        aggroReactTimer = aggroReact / UnityEngine.Random.Range(0.5f, 2.9f);
    }

    internal bool AggroHigh()
    {
        
        Agent target = (GetComponent<Class>().target != null) ? GetComponent<Class>().target : EncounterManager.instance.currentEncounter.Boss()[0];
        if(target.GetComponent<Boss>().aggro.Count > 0)
        {
            //if (GetComponent<Class>().target.GetComponent<Boss>().aggro[0].agent == GetComponent<Agent>()|| BelieveClose())
            //{
            //    Debug.Log(GetComponent<Character>().characterName);
            //    if (GetComponent<Class>().state != DecisionState.StopDPS)
            //    {
            //        if (GetComponent<Class>().spec == Spec.Stalwart) return false;
            //        else return true;
            //    }
            //}
        }
        return false;
    }

    private bool BelieveClose()=>aggroBelief>= GetComponent<Class>().target.GetComponent<Boss>().aggro[0].aggro;

    internal void AggroInterupt()
    {
        aggroReactTimer -= Time.deltaTime;
        if (aggroReactTimer <= 0)
        {            
            aggroReactTimer = aggroReact/UnityEngine.Random.Range(0.9f,2.9f);
            GetComponent<Character>().state = DecisionState.StopDPS;
        }
    }

    internal void HazardInterupt()
    {
        hazardAwareTimer -= Time.deltaTime;
        if (hazardAwareTimer <= 0)
        {
            hazardAwareTimer = hazardAware / UnityEngine.Random.Range(0.9f, 2.9f);
            Utility.instance.DamageNumber(GetComponent<Character>(), "Moving", SpriteList.instance.damageColor);
            GetComponent<Character>().state = DecisionState.Move;
        }
    }
}
