using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Effect : MonoBehaviour
{
    public Agent attacker;
    public Character target;
    public float threat;
    public float timer;
    public float damage;
    public Sprite sprite;
}
