using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class EssenceBurn : Effect
{
    public float cost;
    private void Start()
    {
        Utility.instance.DamageNumber(target.GetComponent<Character>(), "Esssence Burn", SpriteList.instance.mage);
        target.buff.Add(this);
        target.magicDamageMod += damage;
        target.energyCost += cost;
    }

    void Update()
    {
        timer -= Time.deltaTime;
        if (timer <= 0)
        {
            target.buff.Remove(this);
            target.magicDamageMod -= damage;
            target.energyCost -= cost;
            target.GetComponent<Mage>().EssenceRecoveryHot();
            Destroy(gameObject);
        }
    }
}
