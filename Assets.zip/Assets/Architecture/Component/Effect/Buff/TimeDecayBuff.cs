using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class TimeDecayBuff : Effect
{
    public float moveChange;
    void Start()
    {
        Utility.instance.DamageNumber(target, $"+ Time Decay", SpriteList.instance.mage);
        target.buff.Add(this);
        target.GetComponent<Move>().moveBonus += moveChange;        
    }
    void Update()
    {
        timer -= Time.deltaTime;
        if (timer <= 0)
        {
            target.GetComponent<Move>().moveBonus += moveChange;
            Utility.instance.DamageNumber(target, $"- Time Decay", SpriteList.instance.mage);
            target.buff.Remove(this);
            Destroy(gameObject);
        }
    }
}
