using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class DirgeOfDemiseBuff : Effect
{
    public float cost;
    private void Start()
    {
        Utility.instance.DamageNumber(target.GetComponent<Character>(), "+ Damage", SpriteList.instance.mage);
        target.buff.Add(this);
        target.magicDamageMod += damage;
        target.physicalDamageMod += damage;
        target.energyCost += cost;
    }

    void Update()
    {
        timer -= Time.deltaTime;
        if (timer <= 0)
        {
            Utility.instance.DamageNumber(target.GetComponent<Character>(), "- Damage", SpriteList.instance.mage);
            target.buff.Remove(this);
            target.magicDamageMod -= damage;
            target.physicalDamageMod -= damage;
            target.energyCost -= cost;
            Destroy(gameObject);
        }
    }
}
