using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class TooAngryToDie : Effect
{
    // Start is called before the first frame update
    void Start()
    {
        Utility.instance.DamageNumber(target, $"+ {damage} vamp", SpriteList.instance.beserker);
        target.buff.Add(this);
        target.bonusVamp += damage;
    }

    // Update is called once per frame
    void Update()
    {
        timer -= Time.deltaTime;
        if (timer <= 0)
        {
            target.bonusVamp -= damage;
            Utility.instance.DamageNumber(target, $"- {damage} vamp", SpriteList.instance.beserker);
            target.buff.Remove(this);
            Destroy(gameObject);
        }
    }
}
