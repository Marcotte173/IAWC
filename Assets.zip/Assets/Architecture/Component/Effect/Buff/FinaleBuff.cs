using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class FinaleBuff : Effect
{
    public float moveChange;
    void Start()
    {
        Utility.instance.DamageNumber(target, $"+ Haste", SpriteList.instance.mage);
        target.buff.Add(this);
        target.GetComponent<Class>().bonusHaste += damage;
    }
    void Update()
    {
        timer -= Time.deltaTime;
        if (timer <= 0)
        {
            target.GetComponent<Class>().bonusHaste -= damage;
            Utility.instance.DamageNumber(target, $"- Haste", SpriteList.instance.mage);
            target.buff.Remove(this);
            Destroy(gameObject);
        }
    }
}
