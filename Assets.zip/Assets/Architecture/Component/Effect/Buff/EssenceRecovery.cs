using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class EssenceRecovery : Effect
{
    private void Start()
    {
        Utility.instance.DamageNumber(target.GetComponent<Character>(), "Esssence Burn", SpriteList.instance.mage);
        target.buff.Add(this);
        target.manaRegenMod += damage;
        target.canCastSpells = false;
    }

    void Update()
    {
        timer -= Time.deltaTime;
        if (timer <= 0)
        {
            target.buff.Remove(this);
            target.manaRegenMod -= damage;
            target.canCastSpells = true;
            target.GetComponent<Mage>().EssenceRecoveryHot();
            Destroy(gameObject);
        }
    }
}
