using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Hibernate : Effect
{
    public List<float> threshHold = new List<float> { };
    public int check;
    private void Start()
    {
        Utility.instance.DamageNumber(target, $"+ Hot", SpriteList.instance.druid);
        Utility.instance.DamageNumber(target, $"Asleep", SpriteList.instance.druid);
        target.buff.Add(this);
        target.state = DecisionState.Asleep;
        target.action = "Asleep";
    }
    void Update()
    {
        timer -= Time.deltaTime;
        if (timer <= .1f)
        {
            target.Heal(damage);
            foreach (Agent a in EncounterManager.instance.currentEncounter.Boss()) Utility.instance.Aggro(a.GetComponent<Boss>(), attacker, threat);
            Utility.instance.DamageNumber(target, $"- Hot", SpriteList.instance.druid);
            target.buff.Remove(this);
            Utility.instance.DamageNumber(target, $"Awake", SpriteList.instance.druid);
            target.state = DecisionState.Decision;
            Destroy(gameObject);
        }
        if (timer <= threshHold[check])
        {
            target.Heal(damage);
            foreach (Agent a in EncounterManager.instance.currentEncounter.Boss())
            {
                Utility.instance.Aggro(a.GetComponent<Boss>(), attacker, threat);
            }
            check++;
        }
    }
}
