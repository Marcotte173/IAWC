using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Warcry : Effect
{
    // Start is called before the first frame update
    void Start()
    {
        Utility.instance.DamageNumber(target, $"+ {damage} Crit", SpriteList.instance.critColor);
        target.GetComponent<Class>().bonusCrit += damage;
        target.buff.Add(this);
    }

    // Update is called once per frame
    void Update()
    {
        timer -= Time.deltaTime;
        if (timer <= 0)
        {
            target.bonusCrit -= damage;
            Utility.instance.DamageNumber(target, $"- {damage} Crit", SpriteList.instance.beserker);
            target.buff.Remove(this);
            Destroy(gameObject);
        }
    }
}
