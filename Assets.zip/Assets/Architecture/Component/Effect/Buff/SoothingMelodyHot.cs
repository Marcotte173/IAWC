using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class SoothingMelodyHot : Effect
{
    public List<float> threshHold = new List<float> { };
    public int check;
    private void Start()
    {
        Utility.instance.DamageNumber(target, $"+ hot", SpriteList.instance.bard);
        target.buff.Add(this);
    }
    void Update()
    {
        timer -= Time.deltaTime;
        if (timer <= .1f)
        {
            target.Heal(damage);
            foreach (Agent a in EncounterManager.instance.currentEncounter.Boss()) Utility.instance.Aggro(a.GetComponent<Boss>(), attacker, threat);
            Utility.instance.DamageNumber(target, $"- hot", SpriteList.instance.bard);
            target.buff.Remove(this);
            Destroy(gameObject);
        }
        if (timer <= threshHold[check])
        {
            target.Heal(damage);
            foreach (Agent a in EncounterManager.instance.currentEncounter.Boss())
            {
                Utility.instance.Aggro(a.GetComponent<Boss>(), attacker, threat);
            }
            check++;
        }
    }
}
