using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class RecklessSwingDefenceNerf : Effect
{
    private void Start()
    {
        Utility.instance.DamageNumber(target, $"- {damage} Defence", SpriteList.instance.beserker);
        target.bonusDef -= damage;
        target.debuff.Add(this);
    }
    private void Update()
    {
        timer -= Time.deltaTime;
        if (timer <= .1f)
        {
            Utility.instance.DamageNumber(target, $"+ {damage} Defence", SpriteList.instance.beserker);
            target.bonusDef += damage;
            target.debuff.Remove(this);
            Destroy(gameObject);
        }
    }
}
