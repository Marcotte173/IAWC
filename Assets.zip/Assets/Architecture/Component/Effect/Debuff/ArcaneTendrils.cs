using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class ArcaneTendrils : Effect
{
    public float moveChange;
    public float hasteChange;
    private void Start()
    {
        Utility.instance.DamageNumber(target, $"- {moveChange*100}% Move/Attack Speed", SpriteList.instance.mage);
        target.bonusHaste -= hasteChange;
        target.GetComponent<Move>().moveBonus -= moveChange;
        target.debuff.Add(this);
    }
    private void Update()
    {
        timer -= Time.deltaTime;
        if (timer <= .1f)
        {
            Utility.instance.DamageNumber(target, $"+ {moveChange * 100}% Move/Attack Speed", SpriteList.instance.mage);
            target.bonusHaste += hasteChange;
            target.GetComponent<Move>().moveBonus += moveChange;
            target.debuff.Remove(this);
            Destroy(gameObject);
        }
    }
}
