using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Taunt : Effect
{
    private void Start()
    {
        target.targetFromTaunt = attacker ;
        Utility.instance.DamageNumber(attacker.GetComponent<Character>(), "Taunt", SpriteList.instance.beserker);
        target.debuff.Add(this);
    }
    
    void Update()
    {
        timer -= Time.deltaTime;
        if (timer <= 0)
        {
            target.targetFromTaunt = null;
            target.debuff.Remove(this);
            Destroy(gameObject);
        }
    }
}
