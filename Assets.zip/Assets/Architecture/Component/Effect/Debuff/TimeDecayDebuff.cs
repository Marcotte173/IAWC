using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class TimeDecayDebuff : Effect
{
    public List<float> threshHold = new List<float> { };
    public int check;
    private void Start()
    {
        Utility.instance.DamageNumber(target, $"+ Time Decay", SpriteList.instance.druid);
        target.debuff.Add(this);
    }
    private void Update()
    {
        timer -= Time.deltaTime;
        if (timer <= .1f)
        {
            target.GetComponent<Boss>().TakeDamage(attacker, damage, Utility.instance.Threat(damage, threat), true);
            Utility.instance.DamageNumber(target, $"- Time Decay", SpriteList.instance.druid);
            target.debuff.Remove(this);
            Destroy(gameObject);
        }
        if (timer <= threshHold[check])
        {
            target.GetComponent<Boss>().TakeDamage(attacker, damage, Utility.instance.Threat(damage, threat), true);
            check++;
        }
    }
}
