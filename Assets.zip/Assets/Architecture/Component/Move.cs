using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Move : MonoBehaviour
{
    public Tile currentTile;
    public Tile nextTile;    
    public List<Tile> path;
    public List<Tile> unwalkable;
    public Vector2 prevPosition;
    public bool isMoving;
    public bool on;
    public float moveSpeed;
    public float moveBonus;

    private void Update()
    {
        if (on) currentTile = EncounterManager.instance.Location(new Vector2(Mathf.Round(transform.position.x), (Mathf.Round(transform.position.y))));
    }
    public List<Agent> PeopleWhoAreNotMeOrMyTarget()
    {
        List<Agent> newList = new List<Agent> { };
        foreach(Agent a in EncounterManager.instance.currentEncounter.Agents()) if (a != GetComponent<Agent>() && a != GetComponent<Character>().target) newList.Add(a);
        return newList;
    }
    public bool GonnaCollide()
    {
        foreach (Agent a in EncounterManager.instance.currentEncounter.Agents())
        {
            Move aMove = a.GetComponent<Move>();
            if (aMove!=this)
            {                
                if (aMove.isMoving && nextTile == aMove.nextTile) return true;
                if(nextTile = aMove.currentTile) return true;
            }
        }
        return false;
    }
}
