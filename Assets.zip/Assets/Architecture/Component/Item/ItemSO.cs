using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public enum ItemType {Head,Chest,Legs,Feet,Weapon,OffHand,Trinket};
public enum Rarity { Uncommon,Rare, Epic, Legendary };
public enum ArmorType { Cloth, Leather, Plate };
[CreateAssetMenu(fileName = "Data", menuName = "Item", order = 1)]
public class ItemSO : ScriptableObject
{
    public int id;
    public string itemName;
    public Rarity rarity;
    public ItemType type;
    public ArmorType armorType;
    public int health;    
    public int defence;
    public int crit;
    public int attackPower;
    public int spellpower;
    public int mana;
    public int damage;
    public int score;
    public int value;
    public int vamp;
}
