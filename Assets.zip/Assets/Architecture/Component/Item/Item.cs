using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;


public class Item : MonoBehaviour
{
    public int id;
    public string itemName;
    public Rarity rarity;
    public ItemType type;
    public int health;
    public int mana;
    public int defence;
    public int crit;
    public int attackPower;
    public int spellpower;    
    public int score;
    public int value;
    public int vamp;
}
