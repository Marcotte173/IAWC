using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Summon : Class
{
    public float time;
    private void Update()
    {
        if(!GetComponent<Agent>().ko)
        {
            time -= Time.deltaTime;
            if (time <= 0) Death();
        }        
    }
}
