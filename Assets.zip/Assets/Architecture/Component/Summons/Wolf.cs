using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Wolf : Summon
{
    public override void Decision()
    {
        action = $"Moving Towards {target.GetComponent<Boss>().characterName}";
        state = DecisionState.Attack1;
    }
    public override void Cast()
    {
        if (basicAttack) Attack1Cast();
    }
    
}
