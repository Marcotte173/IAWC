using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class ProjectileEnemy : Projectile
{
    public override void ProjectileEffect()
    {
        if (target.GetComponent<Class>()) target.GetComponent<Class>().TakeDamage(attacker, damage, false);
        Destroy(gameObject);
    }
}
