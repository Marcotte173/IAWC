using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Projectile : MonoBehaviour
{
    public Agent target;
    public float speed;
    public float damage;
    public float aoeDamage;
    public float aggro;
    public Agent attacker;
    public RuntimeAnimatorController projectileAnimator;
    public RuntimeAnimatorController effectAnimator;
    public bool aoe;
    public float range;

    private void Update()
    {
        if (target != null|| EncounterManager.instance.currentEncounter.raidMode == RaidMode.After)
        {
            transform.right = target.transform.position - transform.position;
            transform.position = Vector2.MoveTowards(transform.position, target.transform.position, speed * Time.deltaTime);
            if (Vector2.Distance(transform.position, target.transform.position) < 0.3f)
            {
                ProjectileEffect();
            }
        }
        else Destroy(gameObject);
    }

    public virtual void ProjectileEffect()
    {
        if (target.GetComponent<Boss>()) target.GetComponent<Boss>().TakeDamage(attacker, damage, aggro,false);
        else if (target.GetComponent<Class>()) target.GetComponent<Class>().TakeDamage(attacker, damage,false);
        Destroy(gameObject);
    }
}
