using System.Linq;
using System.Collections.Generic;
using UnityEngine;

public class Encounter : MonoBehaviour
{
    public int id;
    public List<int> bossSummon;
    public List<Agent> boss;
    public List<Agent> player;
    public List<Agent> playerMinionSummons;
    public List<Agent> bossMinionSummons;
    public List<Tile> tileList;
    public List<Tile> placeTiles;
    public List<Tile> occupied;
    public int arena;
    public int arenaSizeX;
    public int arenaSizeY;
    public float cameraY;
    public List<ItemSO> drops;
    public string flavor;
    public List<Hazard> enemyHazards;
    public List<Hazard> playerHazards;
    public RaidMode raidMode;
    public float maximumYPlace;
    public List<Agent> Agents()
    {
        List<Agent> newList = new List<Agent> { };
        foreach (Agent a in boss) if (!a.ko)newList.Add(a);
        foreach (Agent a in player) if (!a.ko) newList.Add(a);
        foreach (Agent a in playerMinionSummons) if (!a.ko) newList.Add(a);
        foreach (Agent a in playerMinionSummons) if (!a.ko) newList.Add(a);
        return newList;
    }
    public List<Agent> Player()
    {
        List<Agent> newList = new List<Agent> { };
        foreach (Agent a in player) if (!a.ko) newList.Add(a);
        return newList;
    }
    public List<Agent> PlayerMinion()
    {
        List<Agent> newList = new List<Agent> { };
        foreach (Agent a in playerMinionSummons) if (!a.ko) newList.Add(a);
        return newList;
    }
    public List<Agent> PlayerAndMinion()
    {
        List<Agent> newList = new List<Agent> { };
        foreach (Agent a in player) if (!a.ko) newList.Add(a);
        foreach (Agent a in playerMinionSummons) if (!a.ko) newList.Add(a);
        return newList;
    }
    public List<Agent> BossMinion()
    {
        List<Agent> newList = new List<Agent> { };
        foreach (Agent a in bossMinionSummons) if (!a.ko) newList.Add(a);
        return newList;
    }
    public List<Agent> Bard()
    {
        List<Agent> newList = new List<Agent> { };
        foreach (Agent a in player) if (a.GetComponent<Bard>()) newList.Add(a);
        return newList;
    }
    public List<Agent> Mage()
    {
        List<Agent> newList = new List<Agent> { };
        foreach (Agent a in player) if (a.GetComponent<Mage>()) newList.Add(a);
        return newList;
    }
    public List<Agent> Beserker()
    {
        List<Agent> newList = new List<Agent> { };
        foreach (Agent a in player) if (a.GetComponent<Beserker>()) newList.Add(a);
        return newList;
    }
    public List<Agent> Shieldbearer()
    {
        List<Agent> newList = new List<Agent> { };
        foreach (Agent a in player) if (a.GetComponent<ShieldBearer>()) newList.Add(a);
        return newList;
    }
    public List<Agent> Rogue()
    {
        List<Agent> newList = new List<Agent> { };
        foreach (Agent a in player) if (a.GetComponent<Rogue>()) newList.Add(a);
        return newList;
    }
    public List<Agent> Druid()
    {
        List<Agent> newList = new List<Agent> { };
        foreach (Agent a in player) if (a.GetComponent<Druid>()) newList.Add(a);
        return newList;
    }
    public List<Agent> KOPlayer()
    {
        List<Agent> newList = new List<Agent> { };
        foreach (Agent a in player) if (a.ko) newList.Add(a);
        return newList;
    }
    public List<Agent> Boss()
    {
        List<Agent> newList = new List<Agent> { };
        foreach (Agent a in boss) if (!a.ko) newList.Add(a);
        return newList;
    }
    public List<Agent> BossAndMinion()
    {
        List<Agent> newList = new List<Agent> { };
        foreach (Agent a in boss) if (!a.ko) newList.Add(a);
        foreach (Agent a in bossMinionSummons) if (!a.ko) newList.Add(a);
        return newList;
    }
    public List<Agent> KOBoss()
    {
        List<Agent> newList = new List<Agent> { };
        foreach (Agent a in boss) if (a.ko) newList.Add(a);
        return newList;
    }
    //public List<Tile> HazardTile()
    //{
    //    List<Tile> newList = new List<Tile> { } ;
    //    foreach (Tile t in tileList) if (t.playerHazards.Count > 0) newList.Add(t);
    //    return newList;
    //}
    //public List<Tile> NoHazardTile()
    //{
    //    List<Tile> newList = new List<Tile> { };
    //    foreach (Tile t in tileList) if (t.playerHazards.Count <1) newList.Add(t);
    //    return newList;
    //}
}

