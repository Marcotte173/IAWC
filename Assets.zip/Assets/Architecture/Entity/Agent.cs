using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Agent : MonoBehaviour
{
    public int id;
    public bool ko; 
    
    internal Head head;
    internal Chest chest;
    internal Legs legs;
    internal Feet feet;
    internal Trinket trinket;
    internal Weapon weapon;
    internal OffHand offHand;
   
    private void Awake()
    {
        head = GetComponent<Character>().head =  GetComponentInChildren<Head>();
        chest = GetComponent<Character>().chest = GetComponentInChildren<Chest>();
        legs = GetComponent<Character>().legs = GetComponentInChildren<Legs>();
        feet = GetComponent<Character>().feet = GetComponentInChildren<Feet>();
        trinket = GetComponent<Character>().trinket = GetComponentInChildren<Trinket>();
        weapon = GetComponent<Character>().weapon = GetComponentInChildren<Weapon>();
        offHand = GetComponent<Character>().offHand = GetComponentInChildren<OffHand>();
    }
    
}