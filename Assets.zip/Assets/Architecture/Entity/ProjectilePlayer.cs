using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class ProjectilePlayer : Projectile
{
    public override void ProjectileEffect()
    {
        if (target.GetComponent<Boss>()) target.GetComponent<Boss>().TakeDamage(attacker, damage, aggro, false);        
        if (aoe)
        {
            List<Agent> targets = new List<Agent> { };
            foreach(Agent a in EncounterManager.instance.currentEncounter.Agents()) if (a.GetComponent<Boss>() && a != target) targets.Add(a);
            if (targets.Count > 0) foreach (Agent a in targets) if (Vector2.Distance(a.transform.position, target.transform.position) < range) a.GetComponent<Boss>().TakeDamage(attacker, damage, aggro, false);
        }
        if (effectAnimator != null)
        {
            Animator r = Instantiate(GameObjectList.instance.animator);
            r.GetComponent<DestroyOverTime>().time = 0.5f;
            r.transform.position = new Vector3(target.transform.position.x, target.transform.position.y);
            r.runtimeAnimatorController = effectAnimator;
            r.transform.localScale = new Vector3(range*3,range*3,range*3);
        }
        Destroy(gameObject);
    }
}
