using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Event : MonoBehaviour
{
    public string eventName;
    public int id;
    public int maxPlayers;
    public List<Agent> agentsInEvent; 
    public int recommendedGearScore;
    public List<string> description;
    public List<EncounterSO> encounter;
    public int currentEncounter;
}
