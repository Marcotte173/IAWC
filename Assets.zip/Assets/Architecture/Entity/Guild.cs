using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Guild : MonoBehaviour
{
    public static Guild instance;
    public List<Agent> roster;
    private void Awake()
    {
        instance = this;
    }
}
