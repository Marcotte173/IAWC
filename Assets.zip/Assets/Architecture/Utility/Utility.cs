using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Utility : MonoBehaviour
{
    public static Utility instance;
    public float tankMultiplier;
    private void Awake()
    {
        instance = this;
    }
    public string Class(Agent a)
    {
        if (a.GetComponent<Beserker>()) return "Beserker";
        if (a.GetComponent<Bard>()) return "Bard";
        if (a.GetComponent<Druid>()) return "Druid";
        if (a.GetComponent<Mage>()) return "Mage";
        if (a.GetComponent<Rogue>()) return "Rogue";
        if (a.GetComponent<ShieldBearer>()) return "ShieldBearer";
        if (a.GetComponent<Orc>()) return "Orc";
        return null;
    }
    public string SpecName(Agent a)
    {
        if (a.GetComponent<Beserker>()&& a.GetComponent<Beserker>().spec == Spec.Stalwart) return "Stalwart Beserker";
        if (a.GetComponent<Beserker>() && a.GetComponent<Beserker>().spec == Spec.Focused) return "Focused Beserker";
        if (a.GetComponent<Bard>() && a.GetComponent<Bard>().spec == Spec.Tranquil) return "Tranquil Bard";
        if (a.GetComponent<Bard>() && a.GetComponent<Bard>().spec == Spec.Inspiring) return "Inspiring Inspiring";
        if (a.GetComponent<Druid>() && a.GetComponent<Druid>().spec == Spec.Wrathful) return "Wrathful Druid";
        if (a.GetComponent<Druid>() && a.GetComponent<Druid>().spec == Spec.Redemptive) return "Redemptive Druid";
        if (a.GetComponent<Mage>() && a.GetComponent<Mage>().spec == Spec.Focused) return "Focused Mage";
        if (a.GetComponent<Mage>() && a.GetComponent<Mage>().spec == Spec.Explosive) return "Explosive Mage";
        if (a.GetComponent<Rogue>() && a.GetComponent<Rogue>().spec == Spec.Wrathful) return "Focused Rogue";
        if (a.GetComponent<Rogue>() && a.GetComponent<Rogue>().spec == Spec.Focused) return "Explosive Rogue";
        if (a.GetComponent<ShieldBearer>() && a.GetComponent<ShieldBearer>().spec == Spec.Inspiring) return "Inspiring ShieldBearer";
        if (a.GetComponent<ShieldBearer>() && a.GetComponent<ShieldBearer>().spec == Spec.Stalwart) return "Stalwart ShieldBearer";
        if (a.GetComponent<Orc>()) return "Orc";
        return null;
    }
    public void TurnOn(GameObject g)
    {
        if (!g.activeSelf) g.SetActive(true);
    }
    public void TurnOff(GameObject g)
    {
        if (g.activeSelf) g.SetActive(false);
    }
    public void DamageNumber(Character a,string message, Color32 color)
    {
        DamageNumbers dn = Instantiate(GameObjectList.instance.damageNumbers, a.transform);
        dn.transform.position = new Vector2(a.transform.position.x + Random.Range(-.6f, .61f), a.transform.position.y + 1);
        dn.message = message;
        dn.displayNumber.color = color;
    }
    public void Aggro(Boss b,Agent attacker,float aggroNumber)
    {
        //Aggro
        bool aggroThere = false;
        if (b.aggro.Count > 0)
        {
            for (int i = 0; i < b.aggro.Count; i++)
            {
                if (b.aggro[i].agent == attacker)
                {
                    aggroThere = true;
                    b.aggro[i].ChangeAggro(aggroNumber);
                    break;
                }
            }
        }
        if (aggroThere == false) b.CreateAggro(attacker, aggroNumber);
    }
    public float Threat(float damage,float threat,bool tank)
    {
        return (tank)?damage * threat/100* tankMultiplier : damage * threat / 100;
    }
    public float Threat(float damage, float threat)
    {
        return Threat(damage, threat, false);
    }
    public void SortAggro(List<Aggro> list)
    {
        Aggro temp;
        for (int j = 0; j <= list.Count - 2; j++)
        {
            for (int i = 0; i <= list.Count - 2; i++)
            {
                if (list[i].aggro < list[i + 1].aggro)
                {
                    temp = list[i + 1];
                    list[i + 1] = list[i];
                    list[i] = temp;
                }
            }
        }
    }   
    
}
