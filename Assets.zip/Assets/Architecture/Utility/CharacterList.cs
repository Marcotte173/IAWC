using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class CharacterList : MonoBehaviour
{
    public static CharacterList instance;
    public List<Player> charactersInTheGame;
    private void Awake()
    {
        instance = this;
    }
}