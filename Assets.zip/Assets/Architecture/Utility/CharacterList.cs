using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class CharacterList : MonoBehaviour
{
    public static CharacterList instance;
    public List<Agent> charactersInTheGame;
    private void Awake()
    {
        instance = this;
    }
}