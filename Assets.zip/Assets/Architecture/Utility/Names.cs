using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Names : MonoBehaviour
{
    public static Names instance;
    private void Awake()
    {
        instance = this;
    }
    public List<string> playerList = new List<string>
    {
            "Adam","Alex","Anthony","Alistair","Alfred","Austin","Angela","Amy", "Anna","Alison","Alexa","Ainsley",
            "Beuford", "Bernard", "Bill", "Bryce", "Barrie","Ben","Beth", "Bonnie", "Bailey","Barbara","Belle",
            "Cole", "Charles","Chris","Chance", "Caleb","Caddie", "Connor", "Carl","Cory","Cody","Carol", "Candice", "Cindy","Caitlyn",
            "Doug",  "Don", "Dwight", "Dexter", "Devon","Donna", "Deborah","Daphne",
            "Edward", "Eric", "Elaine","Emily",
            "Fred","Frank","Farrah","Fran",
             "George", "Gerald", "Gina", "Gina","Grace",
              "Harold","Hank","Heather",
             "Ian","Isabelle",
              "Jake", "James", "Jackson", "Jesse", "John", "Jack","Jolene","Janet",
             "Karl", "Keon", "Kevan","Kyra","Katherine",
            "Lewis","Larry","Laura",
             "Matt","Martin","Melvin", "Maddox","Meagen","Marvin","Mitch","Micah","Mark","Micheal", "Mary","Maebel","Magda","Mia",
            "Oliver","Oscar","Odyn","Olivea",
            "Paul","Pierce","Piper","Pam",
            "Sara",
            "Wesley","Winston"
    };
    public List<string> userName = new List<string>
    {
       "FemboyEthnoState",
       "BabyDoll","EatHeelz","L33tH34ls",
        "Senjack","Mini","Wumbo","Mift","Pixaboo","Asmongold","Smorc","Sniper","Martyr","Joeroguen","Oomhammer","Stabetha","Borc",
    };
    public List<string> warriorPlayerList = new List<string> {"Travis","Dave","Derek","Jamie","John"};
    public List<string> roguePlayerList = new List<string> { "Marc", "Daniel", "Kayden", "Stuart", "Dave" };
    public List<string> magePlayerList = new List<string> { "Bailey", "Nic", "Darren", "Kyra", "Sara" };
    public List<string> priestPlayerList = new List<string> { "Clara", "Danyelle", "Dan", "Steven", "Dave" };
    public List<string> paladinPlayerList = new List<string> { "Kennard", "Laura", "Glen", "Tom", "Murray" };
    public List<string> druidPlayerList = new List<string> { "Malikai", "Scott", "Darrel", "Eric", "Justin" };
    public List<string> warriorCharacterList = new List<string> { "Marcotte", "Wernar", "Hjalti", "Uriel", "Sprinkle" };
    public List<string> rogueCharacterList = new List<string> { "Swank", "Bonk", "Ronin", "LittleMan", "Stabbins" };
    public List<string> mageCharacterList = new List<string> { "Hildeth", "TooHot", "Ragnar", "ShadowHeart", "Snuggs" };
    public List<string> priestCharacterList = new List<string> { "Kitties", "Ellynad", "Nuaurpy", "Healbot", "StopDotnRoll" };
    public List<string> paladinCharacterList = new List<string> { "Dranek", "UnicornVenom", "BigMan", "TipTop", "Fergus" };
    public List<string> druidCharacterList = new List<string> { "Spider", "Gelato", "StopDots", "Healzor", "Ingvar" };

}
