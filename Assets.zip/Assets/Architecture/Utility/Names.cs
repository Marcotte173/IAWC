using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Names : MonoBehaviour
{
    public static Names instance;
    private void Awake()
    {
        instance = this;
    }
    public List<string> playerList = new List<string>
    {
            "Adam","Alex","Anthony","Alistair","Alfred","Austin","Angela","Amy", "Anna","Alison","Alexa","Ainsley",
            "Beuford", "Bernard", "Bill", "Bryce", "Barrie","Ben","Beth", "Bonnie", "Bailey","Barbara","Belle",
            "Cole", "Charles","Chris","Chance", "Caleb","Caddie", "Connor", "Carl","Cory","Cody","Carol", "Candice", "Cindy","Caitlyn",
            "Doug",  "Don", "Dwight", "Dexter", "Devon","Donna", "Deborah","Daphne",
            "Edward", "Eric", "Elaine","Emily",
            "Fred","Frank","Farrah","Fran",
             "George", "Gerald", "Gina", "Gina","Grace",
              "Harold","Hank","Heather",
             "Ian","Isabelle",
              "Jake", "James", "Jackson", "Jesse", "John", "Jack","Jolene","Janet",
             "Karl", "Keon", "Kevan","Kyra","Katherine",
            "Lewis","Larry","Laura",
             "Matt","Martin","Melvin", "Maddox","Meagen","Marvin","Mitch","Micah","Mark","Micheal", "Mary","Maebel","Magda","Mia",
            "Oliver","Oscar","Odyn","Olivea",
            "Paul","Pierce","Piper","Pam",
            "Sara",
            "Wesley","Winston"
    };
    
    public List<string> userName = new List<string>
    {
       "BabyDoll","EatHeelz","L33tH34ls",
       "Mini","Wumbo","Mift","Pixaboo","Asmongold","Smorc","Sniper",
        "Martyr","Joeroguen","Oomhammer","Stabetha","Borc","Senjak", 
        "Bonk", "Ronin", "LittleMan", "Stabbins","Sprinkle","UnicornVenom",
        "BigMan", "TooHot", "Ragnar", "ShadowHeart", "Snuggs",
        "Healbot", "StopDotnRoll", "StopDots", "Healzor", "Ingvar","Gelato"
    };
    
    public List<string> warriorCharacterList = new List<string> { "Dranek",  "Uriel",  };
    public List<string> rogueCharacterList = new List<string> { "Wernar", "Hjalti", };
    public List<string> mageCharacterList = new List<string> { "Marcotte", "Kitties"  };
    public List<string> druidCharacterList = new List<string> { "Ellynad", "Nuaurpy",  };
    public List<string> shieldBearerCharacterList = new List<string> { "Hildeth", "Fergus" };
    public List<string> bardCharacterList = new List<string> { "Tip Top", "MalEdm17"};

}
