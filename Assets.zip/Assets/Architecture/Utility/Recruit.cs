using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class Recruit : MonoBehaviour
{
    public static Recruit instance;
    public int leftPage;
    public int rightPage;
    public List<Button> leftButton;
    public List<Button> rightButton;
    public Agent target;
    public Text playerName;
    public Text characterName;
    public Text characterClass;
    public Text health;
    public Text healthNumber;
    public Text mana;
    public Text manaNumber;
    public Text crit;
    public Text critNumber;
    public Text spellPower;
    public Text spellPowerNumber;
    public Text damage;
    public Text damageNumber;
    public Text defence;
    public Text defenceNumber;
    public Text head;
    public Text body;
    public Text legs;
    public Text feet;
    public Text trinket;
    public Text weapon;
    public Text offHand;
    public Text headArmor;
    public Text bodyArmor;
    public Text legsArmor;
    public Text feetArmor;
    public Text trinketSlot;
    public Text weaponSlot;
    public Text offHandSlot;
    public Text gearScore;
    public Text gearScoreNumber;
    public Button actionButton;
    public Button nullTarget;
    public Text leftSide;
    public Text rightSide;
    public bool recruit;
    public Button enterDungeonButton;
    public bool pveLoad;
    public Button leftPageButton;
    public Button rightPageButton;
    public Button leftPageButton1;
    public Button rightPageButton1;
    public int amountOfPlayerPerPage;
    public bool info;
    public bool progress;
    public bool rankings;
    private void Awake()
    {
        instance = this;
        amountOfPlayerPerPage = 10;
    }
    public void UpdateInfo()
    {
        SortId(CharacterList.instance.charactersInTheGame);
        SortId(Guild.instance.roster);
        if(pveLoad && Menu.instance.target.agentsInEvent.Count>0) SortId(Menu.instance.target.agentsInEvent);
        if (!pveLoad)
        {
            actionButton.GetComponentInChildren<Text>().text = (CharacterList.instance.charactersInTheGame.Contains(target)) ? "Recruit" : "Fire";
            Utility.instance.TurnOff(enterDungeonButton.gameObject);
            Utility.instance.TurnOn(leftPageButton1.gameObject);
            Utility.instance.TurnOn(rightPageButton1.gameObject);
            rightSide.text = "Roster";            
            if (recruit)
            {

                SortId(CharacterList.instance.charactersInTheGame);
                UpdateList(CharacterList.instance.charactersInTheGame, leftPage, leftButton);
                leftSide.text = "Recruit";
                Utility.instance.TurnOn(leftPageButton.gameObject);
                Utility.instance.TurnOn(rightPageButton.gameObject);
            }
            else
            {
                foreach (Button b in leftButton) b.GetComponentInChildren<Text>().text = "";
                foreach (Button b in leftButton) b.interactable = false;
                leftSide.text = "Guild Information";
                leftButton[0].GetComponentInChildren<Text>().color = SpriteList.instance.playerName;
                leftButton[1].GetComponentInChildren<Text>().color = SpriteList.instance.playerName;
                leftButton[2].GetComponentInChildren<Text>().color = SpriteList.instance.playerName;
                leftButton[0].GetComponentInChildren<Text>().text = "Basic Info";
                leftButton[1].GetComponentInChildren<Text>().text = "Guild Progress";
                leftButton[2].GetComponentInChildren<Text>().text = "View Guild Rankings";
                leftButton[0].interactable = true;
                leftButton[1].interactable = true; 
                leftButton[2].interactable = true;
                Utility.instance.TurnOff(leftPageButton.gameObject);
                Utility.instance.TurnOff(rightPageButton.gameObject);
            }            
            UpdateList(Guild.instance.roster,rightPage,rightButton);
        }
        else
        {
            Utility.instance.TurnOn(enterDungeonButton.gameObject);
            Utility.instance.TurnOff(leftPageButton1.gameObject);
            Utility.instance.TurnOff(rightPageButton1.gameObject);
            UpdateList(Menu.instance.target.agentsInEvent, rightPage, rightButton);
            UpdateList(Guild.instance.roster, leftPage, leftButton);
            leftSide.text = "Roster";
            rightSide.text = "Fighting";
            actionButton.GetComponentInChildren<Text>().text = (Guild.instance.roster.Contains(target)) ? "Send to fight" : "Remove from fight";
        }
        if (target == null) Utility.instance.TurnOff(nullTarget.gameObject);
        else Utility.instance.TurnOn(nullTarget.gameObject);        
        DisplayTargetInfo();
    }

    private void SortId(List<Agent> list)
    {
        Agent temp;
        for (int j = 0; j <= list.Count - 2; j++)
        {
            for (int i = 0; i <= list.Count - 2; i++)
            {
                if (list[i].id > list[i + 1].id)
                {
                    temp = list[i + 1];
                    list[i + 1] = list[i];
                    list[i] = temp;
                }
            }
        }
    }

    private void DisplayTargetInfo()
    {
        int w = 0;
        int p = 0;
        int m = 0;
        int pa = 0;
        int d = 0;
        int r = 0;
        foreach (Agent a in Guild.instance.roster)
        {
            if (a.GetComponent<Beserker>()) w++;
            else if (a.GetComponent<Druid>()) p++;
            else if (a.GetComponent<Mage>()) m++;
            else if (a.GetComponent<ShieldBearer>()) pa++;
            else if (a.GetComponent<Bard>()) d++;
            else if (a.GetComponent<Rogue>()) r++;
        }
        string w1 = (w == 1) ? "Warrior" : "Warriors";
        string p1 = (p == 1) ? "Priest" : "Priests";
        string m1 = (m == 1) ? "Mage" : "Mages";
        string pa1 = (pa == 1) ? "Paladin" : "Paladins";
        string d1 = (d == 1) ? "Druid" : "Druids";
        string r1 = (r == 1) ? "Rogue" : "Rogues";
        if (target == null)
        {
            playerName.text = "";
            characterName.text = "";
            characterClass.text = "";
            health.text = "";
            healthNumber.text = "";
            mana.text = "";
            manaNumber.text = "";
            crit.text = "";
            critNumber.text = "";
            defence.text = "";
            defenceNumber.text = "";
            damage.text = "";
            damageNumber.text = "";
            spellPower.text = "";
            spellPowerNumber.text = "";
            head.text = "";
            body.text = "";
            legs.text = "";
            feet.text = "";
            trinket.text = "";
            weapon.text = "";
            offHand.text = "";
            headArmor.color = Color.white;
            trinketSlot.color = Color.white;
            weaponSlot.color = Color.white;
            legsArmor.color = Color.white;
            headArmor.text = (recruit)?"Please Select a Character":"";
            bodyArmor.text = "";
            legsArmor.text = (recruit) ? "You Have":"";
            feetArmor.text = "";
            trinketSlot.text = (recruit) ? $"{ w} {w1} - {p} {p1} - {r} {r1} " : "";
            weaponSlot.text = (recruit) ? $"{ m} {m1} - {d} {d1} - {pa} {pa1}" : "";
            offHandSlot.text = "";
            gearScore.text = "";
            gearScoreNumber.text = "";
            Utility.instance.TurnOff(actionButton.gameObject);
        }
        else
        {
            Character core = (target == null) ? null : target.GetComponent<Character>();
            Utility.instance.TurnOn(actionButton.gameObject);
            if (target.GetComponent<Beserker>()) characterClass.GetComponentInChildren<Text>().color = SpriteList.instance.beserker;
            else if (target.GetComponent<Druid>()) characterClass.GetComponentInChildren<Text>().color = SpriteList.instance.druid;
            else if (target.GetComponent<Mage>()) characterClass.GetComponentInChildren<Text>().color = SpriteList.instance.mage;
            else if (target.GetComponent<Bard>()) characterClass.GetComponentInChildren<Text>().color = SpriteList.instance.bard;
            else if (target.GetComponent<Rogue>()) characterClass.GetComponentInChildren<Text>().color = SpriteList.instance.rogue;
            else if (target.GetComponent<ShieldBearer>()) characterClass.GetComponentInChildren<Text>().color = SpriteList.instance.shieldBearer;
            playerName.text = target.GetComponent<Player>().playerName;
            characterName.text = core.characterName;
            characterClass.text = Utility.instance.SpecName(target);
            spellPower.text = "Spell Power";
            spellPowerNumber.text = core.SpellPower().ToString();
            crit.text = "Crit";
            critNumber.text = core.Crit().ToString();
            defence.text = "Defence";
            defenceNumber.text = core.Defence().ToString();
            damage.text = "Damage";
            damageNumber.text = core.Damage().ToString();
            health.text = "Health";
            healthNumber.text = core.MaxHealth() + "/" + core.MaxHealth();
            mana.text = (target.GetComponent<Beserker>()) ? "Rage" : (target.GetComponent<Rogue>()) ? "Energy" : "Mana";
            if (target.GetComponent<Beserker>()) manaNumber.color = Color.red;
            else if (target.GetComponent<Rogue>()) manaNumber.color = Color.yellow;
            else manaNumber.color = SpriteList.instance.mana;
            manaNumber.text = (target.GetComponent<Beserker>()) ? "0/100" : (target.GetComponent<Rogue>()) ? "100/100" : core.MaxMana() + "/" + core.MaxMana();
            head.text ="Head";
            body.text ="Chest";
            legs.text ="Legs";
            feet.text = "Feet";
            trinket.text = "Trinket";
            weapon.text = "Weapon";
            offHand.text = "OffHand";
            headArmor.text =  core.head.itemName;
            headArmor.color = (core.head.rarity == Rarity.Rare) ? SpriteList.instance.rare : (core.head.rarity == Rarity.Epic) ? SpriteList.instance.epic : (core.head.rarity == Rarity.Epic) ? SpriteList.instance.legendary : SpriteList.instance.uncommon;
            bodyArmor.text =  core.chest.itemName;
            bodyArmor.color = (core.head.rarity == Rarity.Rare) ? SpriteList.instance.rare : (core.head.rarity == Rarity.Epic) ? SpriteList.instance.epic : (core.head.rarity == Rarity.Epic) ? SpriteList.instance.legendary : SpriteList.instance.uncommon;
            legsArmor.text =  core.legs.itemName;
            legsArmor.color = (core.head.rarity == Rarity.Rare) ? SpriteList.instance.rare : (core.head.rarity == Rarity.Epic) ? SpriteList.instance.epic : (core.head.rarity == Rarity.Epic) ? SpriteList.instance.legendary : SpriteList.instance.uncommon;
            feetArmor.text = core.feet.itemName;
            feetArmor.color = (core.head.rarity == Rarity.Rare) ? SpriteList.instance.rare : (core.head.rarity == Rarity.Epic) ? SpriteList.instance.epic : (core.head.rarity == Rarity.Epic) ? SpriteList.instance.legendary : SpriteList.instance.uncommon;
            trinketSlot.text = core.trinket.itemName;
            trinketSlot.color = (core.head.rarity == Rarity.Rare) ? SpriteList.instance.rare : (core.head.rarity == Rarity.Epic) ? SpriteList.instance.epic : (core.head.rarity == Rarity.Epic) ? SpriteList.instance.legendary : SpriteList.instance.uncommon;
            weaponSlot.text =  core.weapon.itemName;
            weaponSlot.color = (core.head.rarity == Rarity.Rare) ? SpriteList.instance.rare : (core.head.rarity == Rarity.Epic) ? SpriteList.instance.epic : (core.head.rarity == Rarity.Epic) ? SpriteList.instance.legendary : SpriteList.instance.uncommon;
            offHandSlot.text = core.offHand.itemName;
            offHandSlot.color = (core.head.rarity == Rarity.Rare) ? SpriteList.instance.rare : (core.head.rarity == Rarity.Epic) ? SpriteList.instance.epic : (core.head.rarity == Rarity.Epic) ? SpriteList.instance.legendary : SpriteList.instance.uncommon;
            gearScore.text = "Gear Score";
            gearScoreNumber.text = (core.head.score + core.chest.score + core.legs.score + core.feet.score + core.trinket.score + core.weapon.score + core.offHand.score).ToString();
        }           
    }

    private void UpdateList(List<Agent> list, int page, List<Button> button)
    {
        int start = page * amountOfPlayerPerPage;
        int end = (start + amountOfPlayerPerPage > list.Count) ? list.Count : start + amountOfPlayerPerPage;
        foreach (Button b in button) b.GetComponentInChildren<Text>().text = "";
        foreach (Button b in button) b.interactable = false;
        for (int i = start; i < end; i++)
        {
            button[i - start].GetComponentInChildren<Text>().text = list[i].GetComponent<Character>().characterName;
            if (list[i].GetComponent<Beserker>()) button[i - start].GetComponentInChildren<Text>().color = SpriteList.instance.beserker;
            else if (list[i].GetComponent<Druid>()) button[i - start].GetComponentInChildren<Text>().color = SpriteList.instance.druid;
            else if (list[i].GetComponent<Mage>()) button[i - start].GetComponentInChildren<Text>().color = SpriteList.instance.mage;
            else if (list[i].GetComponent<Bard>()) button[i - start].GetComponentInChildren<Text>().color = SpriteList.instance.bard;
            else if (list[i].GetComponent<Rogue>()) button[i - start].GetComponentInChildren<Text>().color = SpriteList.instance.rogue;
            else if (list[i].GetComponent<ShieldBearer>()) button[i - start].GetComponentInChildren<Text>().color = SpriteList.instance.shieldBearer;
            button[i - start].interactable = true;
        }
    }

    public void RecruitNext()
    {
        leftPage = ((leftPage + 1) * amountOfPlayerPerPage > CharacterList.instance.charactersInTheGame.Count) ? leftPage : leftPage + 1;
        UpdateInfo();
    }
    public void RecruitBack()
    {
        leftPage = (leftPage == 0) ? leftPage : leftPage - 1;
        UpdateInfo();
    }
    public void GuildNext() 
    { 
        rightPage = ((rightPage + 1) * amountOfPlayerPerPage > Guild.instance.roster.Count) ? rightPage : rightPage + 1;
        UpdateInfo();
    }
    public void GuildBack()
    {
        rightPage = (rightPage == 0) ? rightPage : rightPage - 1;
        UpdateInfo();

    }
    public void RecruitButton1()
    {
        if (recruit||pveLoad) target = (pveLoad) ? Guild.instance.roster[leftPage * amountOfPlayerPerPage] : CharacterList.instance.charactersInTheGame[leftPage * amountOfPlayerPerPage];
        else
        {

        }
        UpdateInfo(); 
    }

    public void RecruitButton2() 
    {
        if (recruit || pveLoad) target = (pveLoad) ? Guild.instance.roster[leftPage * amountOfPlayerPerPage+1] : CharacterList.instance.charactersInTheGame[leftPage * amountOfPlayerPerPage + 1];
        else
        {

        }
        UpdateInfo(); 
    }

    public void RecruitButton3() 
    {
        if (recruit || pveLoad) target = (pveLoad) ? Guild.instance.roster[leftPage * amountOfPlayerPerPage + 2] : CharacterList.instance.charactersInTheGame[leftPage * amountOfPlayerPerPage + 2]; else
        {

        }
        UpdateInfo();
    }

    public void RecruitButton4() 
    {
        target = (pveLoad)? Guild.instance.roster[leftPage * amountOfPlayerPerPage + 3] : CharacterList.instance.charactersInTheGame[leftPage * amountOfPlayerPerPage + 3];     
        UpdateInfo();
    }

    public void RecruitButton5() 
    {
        target = (pveLoad) ? Guild.instance.roster[leftPage * amountOfPlayerPerPage + 4] : CharacterList.instance.charactersInTheGame[leftPage * amountOfPlayerPerPage + 4];     
        UpdateInfo();
    }

    public void RecruitButton6() 
    {
        target = (pveLoad) ? Guild.instance.roster[leftPage * amountOfPlayerPerPage + 5] : CharacterList.instance.charactersInTheGame[leftPage * amountOfPlayerPerPage + 5];     
        UpdateInfo();
    }

    public void RecruitButton7() 
    {
        target = (pveLoad) ? Guild.instance.roster[leftPage * amountOfPlayerPerPage + 6] : CharacterList.instance.charactersInTheGame[leftPage * amountOfPlayerPerPage + 6];     
        UpdateInfo();
    }

    public void RecruitButton8() 
    {
        target = (pveLoad) ? Guild.instance.roster[leftPage * amountOfPlayerPerPage + 7] : CharacterList.instance.charactersInTheGame[leftPage * amountOfPlayerPerPage + 7];     
        UpdateInfo();
    }

    public void RecruitButton9() 
    {
        target = (pveLoad) ? Guild.instance.roster[leftPage * amountOfPlayerPerPage + 8] : CharacterList.instance.charactersInTheGame[leftPage * amountOfPlayerPerPage + 8];  
        UpdateInfo();
    }
    public void RecruitButton10()
    {
        target = (pveLoad) ? Guild.instance.roster[leftPage * amountOfPlayerPerPage + 9] : CharacterList.instance.charactersInTheGame[leftPage * amountOfPlayerPerPage + 9];
        UpdateInfo();
    }
    public void GuildButton1() 
    {
        target = (pveLoad) ? Menu.instance.target.agentsInEvent[leftPage * amountOfPlayerPerPage] : Guild.instance.roster[rightPage * amountOfPlayerPerPage];
        UpdateInfo();
    }
    public void GuildButton2() 
    {
        target = (pveLoad) ? Menu.instance.target.agentsInEvent[leftPage * amountOfPlayerPerPage+1] : Guild.instance.roster[rightPage * amountOfPlayerPerPage + 1]; 
        UpdateInfo();
    }
    public void GuildButton3() 
    {
        target = (pveLoad) ? Menu.instance.target.agentsInEvent[leftPage * amountOfPlayerPerPage + 2] : Guild.instance.roster[rightPage * amountOfPlayerPerPage + 2];
        UpdateInfo();
    }
    public void GuildButton4() 
    {
        target = (pveLoad) ? Menu.instance.target.agentsInEvent[leftPage * amountOfPlayerPerPage + 3] : Guild.instance.roster[rightPage * amountOfPlayerPerPage + 3];
        UpdateInfo();
    }
    public void GuildButton5() 
    {
        target = (pveLoad) ? Menu.instance.target.agentsInEvent[leftPage * amountOfPlayerPerPage + 4] : Guild.instance.roster[rightPage * amountOfPlayerPerPage + 4];
        UpdateInfo();
    }
    public void GuildButton6()
    {
        target = (pveLoad) ? Menu.instance.target.agentsInEvent[leftPage * amountOfPlayerPerPage + 5] : Guild.instance.roster[rightPage * amountOfPlayerPerPage + 5];
        UpdateInfo();
    }
    public void GuildButton7() 
    {
        target = (pveLoad) ? Menu.instance.target.agentsInEvent[leftPage * amountOfPlayerPerPage + 6] : Guild.instance.roster[rightPage * amountOfPlayerPerPage + 6];
        UpdateInfo();
    }
    public void GuildButton8() 
    {
        target = (pveLoad) ? Menu.instance.target.agentsInEvent[leftPage * amountOfPlayerPerPage + 7] : Guild.instance.roster[rightPage * amountOfPlayerPerPage + 7];
        UpdateInfo();
    }
    public void GuildButton9() 
    {
        target = (pveLoad) ? Menu.instance.target.agentsInEvent[leftPage * amountOfPlayerPerPage + 8] : Guild.instance.roster[rightPage * amountOfPlayerPerPage + 8];
        UpdateInfo();
    }
    public void GuildButton10()
    {
        target = (pveLoad) ? Menu.instance.target.agentsInEvent[leftPage * amountOfPlayerPerPage + 9] : Guild.instance.roster[rightPage * amountOfPlayerPerPage + 9];
        UpdateInfo();
    }
    public void RecruitFire()
    {
        if (pveLoad)
        {
            if (Guild.instance.roster.Contains(target))
            {
                if (Menu.instance.target.agentsInEvent.Count < Menu.instance.target.maxPlayers)
                {
                    Guild.instance.roster.Remove(target);
                    Menu.instance.target.agentsInEvent.Add(target);                    
                }                
                else Debug.Log("Too many players");
                target = null;

            }
            else if (Menu.instance.target.agentsInEvent.Contains(target))
            {
                Guild.instance.roster.Add(target);
                Menu.instance.target.agentsInEvent.Remove(target);
                target = null;
            }
        }
        else
        {
            if (CharacterList.instance.charactersInTheGame.Contains(target))
            {
                Guild.instance.roster.Add(target);
                CharacterList.instance.charactersInTheGame.Remove(target);
                target = null;
            }
            else
            {
                Guild.instance.roster.Remove(target);
                CharacterList.instance.charactersInTheGame.Add(target);
                target = null;
            }
        }
        UpdateInfo();
    }

    public void NullifyTarget()
    {
        target = null;
        UpdateInfo();
    }
}
