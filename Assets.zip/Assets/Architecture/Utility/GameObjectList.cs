using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class GameObjectList : MonoBehaviour
{
    public static GameObjectList instance;
    public Tile tile;
    public Agent agent;
    public Encounter encounter;
    public Aggro aggro;
    public Agent beserker;
    public Agent druid;
    public Agent shieldBearer;
    public Agent rogue;
    public Agent mage;
    public Agent bard;
    public Agent wolf;
    public Projectile simpleProjectile;
    public ProjectilePlayer playerProjectile;
    public ProjectileEnemy enemyProjectile;
    public Hazard enemyHazard;
    public PlayerHazard playerHazard;
    public Animator animator;
    public EssenceBurn essenceBurn;
    public EssenceRecovery essenceRecovery;
    public Rot rot;
    public SnakeBite snakeBite;
    public SavageBlowDot savageBlowDot;
    public Taunt taunt;
    public ArcaneTendrils arcaneTendrils;
    public TooAngryToDie tooAngryToDie;
    public Warcry warcry;
    public TimeDecayBuff timeDecayBuff;
    public TimeDecayDebuff timeDecayDebuff;    
    public RecklessSwingDefenceNerf recklessSwingDefenceNerf;
    public GreaterHealHot greaterHealHot;
    public Hibernate hibernate;
    public SoothingMelodyHot soothingMelodyHot;
    public UpliftHot upliftHot;
    public DirgeOfDemiseBuff dirgeOfDemiseBuff;
    public FinaleBuff finaleBuff;
    public DamageNumbers damageNumbers;
    public RuntimeAnimatorController disintigrate;
    public RuntimeAnimatorController explosion;
    public RuntimeAnimatorController fireball;
    private void Awake()
    {
        instance = this;
    }
}
