using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class DamageNumbers : MonoBehaviour
{
    public float moveSpeed;
    public string message;
    public Text displayNumber;
    private void Awake()
    {
        displayNumber = GetComponentInChildren<Text>();
    }
    private void Update()
    {
        displayNumber.text = message;
        transform.position = new Vector3(transform.position.x, transform.position.y + (moveSpeed * Time.deltaTime), transform.position.z);
    }
}
