using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class EventList : MonoBehaviour
{
    public static EventList instance;
    public List<Event> events;
    private void Awake()
    {
        instance = this;
    }

    internal void MakeEvents()
    {
        for (int i = 0; i < events.Count; i++)
        {
            Event e = Instantiate(events[i], transform);
            e.name = events[i].eventName;
            events[i] = e;
        }
    }
}
