using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

public class MainMenu : MonoBehaviour
{
    public GameObject logo;
    public GameObject menu;
    public float logoTime;

    private void Awake()
    {
        logo.SetActive(true);
    }
    public void Update()
    {
        logoTime -= Time.deltaTime;
        if (logoTime <= 0)
        {
            logo.SetActive(false);
            menu.SetActive(true);
        }
    }

    public void NewGame()
    {           
        SceneManager.LoadScene("Game");
    }

    public void Quit()
    {
        Application.Quit();
    }
}
