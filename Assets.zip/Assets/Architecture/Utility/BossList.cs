using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class BossList : MonoBehaviour
{
    public static BossList instance;
    public List<Agent> boss;
    private void Awake()
    {
        instance = this;
        for (int i = 0; i < boss.Count; i++)
        {
            Agent a = Instantiate(boss[i], transform);
            a.name = boss[i].name;
            boss[i] = a;
        }        
    }
}
