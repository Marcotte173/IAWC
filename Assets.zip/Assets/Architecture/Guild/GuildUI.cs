using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using TMPro;
using System;

public class GuildUI : MonoBehaviour
{
    public static GuildUI instance;
    public List<TMP_Text> playerInfo;
    public List<TMP_Text> characterInfo;  
    public List<Button> characterButton;
    public List<Button> guildButton;
    public List<Button> playerButton;
    public List<TMP_Text> playerButtonNames;
    public List<TMP_Text> playerButtonClasses;
    public List<TMP_Text> playerButtonCost;
    public List<TMP_Text> guildInfo;
    public GameObject buttonHeading;
    public Button button;
    public GameObject playerBox;
    public GameObject paperDoll;
    public List<Image> paperDollImages;
    //Turn information on an off in a block. Used for tasks and scheduling
    public GameObject playerInformationObject;
    public GameObject characterInformationObject;
    public GameObject taskObject;
    public GameObject itemTooltip;
    public List<TMP_Text> ItemTooltipInfo;
    public GameObject guildTooltip;
    public List<TMP_Text> guildTooltipInfo;


    private void Update()
    {
        if (Input.GetMouseButtonUp(1) || Input.GetKeyUp(KeyCode.Escape))
        {
            if (Guild.instance.guildToolTipHold)
            {
                Guild.instance.guildToolTipHold = false;
                Guild.instance.GuildTooltipOff();
            }
            else if (Guild.instance.itemToolTipHold)
            {
                
                Guild.instance.itemToolTipHold = false;
                Guild.instance.ItemTooltipOff();
            }
        }
    }
    private void Awake()
    {
        instance = this;
        for (int i = 0; i <30; i++)
        {
            Button b = Instantiate(button, buttonHeading.transform);
            GiveInfo g = b.GetComponent<GiveInfo>();
            playerButtonNames.Add(g.strings[0]);
            playerButtonClasses.Add(g.strings[1]);
            playerButtonCost.Add(g.strings[2]);
            playerButton.Add(b);
            g.id = i;
        }
        foreach (Button b in playerButton) Utility.instance.TurnOff(b.gameObject);
    }
}
