using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class MoreRosters : GuildUpgrade
{
    public override void Effect()
    {

    }
}
