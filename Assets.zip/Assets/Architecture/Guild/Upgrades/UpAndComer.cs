using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class UpAndComer : GuildUpgrade
{
    public override void Effect()
    {

    }
}
