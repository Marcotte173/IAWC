using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class RaidRoster : MonoBehaviour
{
    public Dungeon dungeon;
    public int day;
    public List<Character> roster;
    public bool ready;
}
