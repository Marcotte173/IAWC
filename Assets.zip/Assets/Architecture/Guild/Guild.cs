using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SocialPlatforms.Impl;
using UnityEngine.UI;
using TMPro;
using static UnityEditor.Experimental.GraphView.GraphView;
using UnityEngine.XR;

public enum ManageState {Recruit, View,Assign, Schedule,Codex,Upgrades}
public class Guild : MonoBehaviour
{
    public static Guild instance;
    public List<Player> roster;
    public List<Player> availableToday;
    public int mainRaidDay;
    public int farmRaidDay;
    public float guildRenown;
    public float guildCurrency;
    public float orderCooldown;
    public Player targetPlayer;
    public ManageState manageState;
    public bool seeHidden;
    public Sprite unknown;
    public bool itemToolTipHold;
    public bool guildToolTipHold;
    public int scheduleDay;
    public bool showPlayer;
    public List<ItemSO> itemList;
    public int displayYear;
    public int displayMonth;
    public Color32 today= new Color32(227, 74, 248, 255);
    public Color32 ahead= new Color32(227, 74, 248, 255);
    public Color32 behind= new Color32(227, 74, 248, 255);
    public string green= "09FF00";
    public string red = "FF0000";
    public string darkGreen = "FF0000";    
    public RosterEvent nextRoster;
    public List<GuildUpgrade> availableUpgrades;
    public List<GuildUpgrade> currentUpgrades;
    public GuildUpgrade targetUpgrade;
    

    private void Start()
    {
        instance = this;
        guildCurrency = guildRenown = 10;
        EventList.instance.MakeRosterEvent();            
    }
    public void NullifyTarget()
    {
        targetPlayer = null;
        Manage();
    }
    internal void ItemTooltipOff()
    {
        Utility.instance.TurnOff(GuildUI.instance.itemTooltip.gameObject);
    }

    public void ShowItemToolTip(Item i)
    {
        Utility.instance.TurnOn(GuildUI.instance.itemTooltip.gameObject);
        GuildUI.instance.ItemTooltipInfo[0].text = i.itemName;
        GuildUI.instance.ItemTooltipInfo[1].text = i.health.ToString();
        GuildUI.instance.ItemTooltipInfo[2].text = i.mana.ToString();
        GuildUI.instance.ItemTooltipInfo[3].text = i.damage.ToString();
        GuildUI.instance.ItemTooltipInfo[4].text = i.crit.ToString();
        GuildUI.instance.ItemTooltipInfo[5].text = i.defence.ToString();
        GuildUI.instance.ItemTooltipInfo[6].text = i.spellpower.ToString();
        GuildUI.instance.ItemTooltipInfo[7].text = i.range.ToString();
        GuildUI.instance.ItemTooltipInfo[8].text = i.haste.ToString();
        GuildUI.instance.ItemTooltipInfo[9].text = i.vamp.ToString();
        GuildUI.instance.ItemTooltipInfo[10].text = i.movement.ToString();
        GuildUI.instance.ItemTooltipInfo[11].text = i.score.ToString();
        GuildUI.instance.ItemTooltipInfo[12].text = i.flavor[0];
        GuildUI.instance.ItemTooltipInfo[13].text = i.flavor[1];
        GuildUI.instance.ItemTooltipInfo[14].text = i.flavor[2];
    }
    public void ShowItemToolTip(ItemSO i)
    {
        Utility.instance.TurnOn(GuildUI.instance.itemTooltip.gameObject);
        GuildUI.instance.ItemTooltipInfo[0].text = i.itemName;
        GuildUI.instance.ItemTooltipInfo[1].text = i.health.ToString();
        GuildUI.instance.ItemTooltipInfo[2].text = i.mana.ToString();
        GuildUI.instance.ItemTooltipInfo[3].text = i.damage.ToString();
        GuildUI.instance.ItemTooltipInfo[4].text = i.crit.ToString();
        GuildUI.instance.ItemTooltipInfo[5].text = i.defence.ToString();
        GuildUI.instance.ItemTooltipInfo[6].text = i.spellpower.ToString();
        GuildUI.instance.ItemTooltipInfo[7].text = i.range.ToString();
        GuildUI.instance.ItemTooltipInfo[8].text = i.haste.ToString();
        GuildUI.instance.ItemTooltipInfo[9].text = i.vamp.ToString();
        GuildUI.instance.ItemTooltipInfo[10].text = i.movement.ToString();
        GuildUI.instance.ItemTooltipInfo[11].text = i.score.ToString();
        GuildUI.instance.ItemTooltipInfo[12].text = i.flavor[0];
        GuildUI.instance.ItemTooltipInfo[13].text = i.flavor[1];
        GuildUI.instance.ItemTooltipInfo[14].text = i.flavor[2];
    }

    internal void ItemTooltipOn(int id)
    {
        Item i = id == 0 ? targetPlayer.currentClass.head : id == 1 ? targetPlayer.currentClass.chest : id == 2 ? targetPlayer.currentClass.legs : id == 3 ? targetPlayer.currentClass.feet : id == 4 ? targetPlayer.currentClass.weapon : id == 5 && targetPlayer.currentClass.weapon.hands==Hands.Two? targetPlayer.currentClass.weapon :id == 5 ? targetPlayer.currentClass.offHand: targetPlayer.currentClass.trinket;
        ShowItemToolTip(i);
    }
    internal void DropItemTooltipOn(int id)
    {
        ShowItemToolTip(itemList[id]);
    }
    internal void GuildTooltipOff()
    {
        Utility.instance.TurnOff(GuildUI.instance.guildTooltip.gameObject);
    }

    internal void GuildTooltipOn(int id, Vector2 position)
    {
        if (id == 1) 
        {
            if (targetPlayer.traits.Count > 1) GuildTooltipOn(targetPlayer.traits[0].flavor,position);
            else GuildTooltipOn(new List<string> { "Player has no traits" }, position);
        }
        else if (id == 2) GuildTooltipOn(targetPlayer.traits[1].flavor, position);
        else if (id == 3) GuildTooltipOn(targetPlayer.traits[2].flavor, position);
    }
    internal void GuildTooltipOn(List<string> flavor, Vector2 position)
    {
        Utility.instance.TurnOn(GuildUI.instance.guildTooltip.gameObject);
        GuildUI.instance.guildTooltip.transform.position =new Vector2(position.x+200,position.y);
        foreach (TMP_Text t in GuildUI.instance.guildTooltipInfo) t.text = "";
        for (int i = 0; i < flavor.Count; i++) GuildUI.instance.guildTooltipInfo[i].text = flavor[i];
    }
    public void RecruitOrFireTarget()
    {
        if (!roster.Contains(targetPlayer))
        {
            if (guildCurrency >= Math.Floor(targetPlayer.currentSkill))
            {
                guildCurrency -= (float)Math.Floor(targetPlayer.currentSkill);
                targetPlayer.guildLoyalty = 60;
                roster.Add(targetPlayer);
                targetPlayer.transform.SetParent(GameManager.instance.guild.transform);
                CharacterList.instance.charactersInTheGame.Remove(targetPlayer);
            }
        }
        else
        {
            targetPlayer.guildLoyalty = 5;
            roster.Remove(targetPlayer);
            targetPlayer.transform.SetParent(GameManager.instance.freeAgent.transform);
            CharacterList.instance.charactersInTheGame.Add(targetPlayer);
            targetPlayer = null;
        }
        NullifyTarget();
    }
    public void ScheduleDropdown()
    {        
        scheduleDay = GuildUI.instance.scheduleDropdown.value +1;
        if(nextRoster!=null)nextRoster.roster.roster.Clear();
        Manage();
    }
    public void RaidDropdown()
    {
        nextRoster.roster.dungeon = DungeonManager.instance.pve[GuildUI.instance.raidDropdown.value];
        OpenBossInfo();
        BossInfo(99);
        Manage();
    }
    public void OpenBossInfo()
    {
        Utility.instance.TurnOn(GuildUI.instance.raidInfoBox);
        Utility.instance.TurnOn(GuildUI.instance.bossInfoButton[0].gameObject);
        GuildUI.instance.bossInfoButton[0].GetComponent<ItemSprite>().button.GetComponent<Image>().sprite = SpriteList.instance.pveBackGround[0];
        for (int i = 1; i < GuildUI.instance.bossInfoButton.Count; i++) Utility.instance.TurnOff(GuildUI.instance.bossInfoButton[i].gameObject);
        for (int i = 1; i < nextRoster.roster.dungeon.encounter.Count+1; i++)
        {
            Utility.instance.TurnOn(GuildUI.instance.bossInfoButton[i].gameObject);
            GuildUI.instance.bossInfoButton[i].GetComponent<ItemSprite>().button.GetComponent<Image>().sprite = nextRoster.roster.dungeon.encounter[i - 1].bossSummon[0].GetComponent<SpriteRenderer>().sprite;
        }        
    }
    public void CloseBackground()
    {
        Utility.instance.TurnOff(GuildUI.instance.raidInfoBox);
        GuildTooltipOff();
        ItemTooltipOff();
    }

    public void Button1()
    {
        if (manageState == ManageState.Recruit) manageState = ManageState.View;
        else if (manageState == ManageState.View) manageState = ManageState.Recruit;
        else if (manageState == ManageState.Assign) manageState = ManageState.Recruit;
        else if (manageState == ManageState.Schedule) manageState = ManageState.Recruit;
        else if (manageState == ManageState.Upgrades) manageState = ManageState.Recruit;
        else if (manageState == ManageState.Codex) manageState =roster.Count>0? ManageState.View:ManageState.Recruit;
        targetPlayer = null;
        Manage();
    }
    public void Button2()
    {
        if (manageState == ManageState.Recruit) manageState = ManageState.Assign;
        else if (manageState == ManageState.View) manageState = ManageState.Assign;
        else if (manageState == ManageState.Assign) manageState = ManageState.View;
        else if (manageState == ManageState.Schedule) manageState = ManageState.View;
        else if (manageState == ManageState.Upgrades) manageState = ManageState.View;
        else if (manageState == ManageState.Codex) manageState = ManageState.Assign;
        targetPlayer = null;
        Manage();
    }
    public void Button3()
    {
        if (manageState == ManageState.Recruit) ScheduleRaid();
        else if (manageState == ManageState.View) ScheduleRaid();
        else if (manageState == ManageState.Assign) ScheduleRaid();
        else if (manageState == ManageState.Schedule) manageState = ManageState.Assign;
        else if (manageState == ManageState.Upgrades) manageState = ManageState.Assign;
        else if (manageState == ManageState.Codex) ScheduleRaid();
        targetPlayer = null;
        Manage();
    }
    public void Button4()
    {
        if (manageState == ManageState.Recruit) manageState = ManageState.Upgrades;
        else if (manageState == ManageState.View) manageState = ManageState.Upgrades;
        else if (manageState == ManageState.Assign) manageState = ManageState.Upgrades;
        else if (manageState == ManageState.Schedule) manageState = ManageState.Upgrades;
        else if (manageState == ManageState.Upgrades) ScheduleRaid();
        else if (manageState == ManageState.Codex) manageState = ManageState.Upgrades;
        targetPlayer = null;
        Manage();
    }
    public void Button5()
    {
        manageState = ManageState.Codex;
        targetPlayer = null;
        Manage();
    }
    public void ScheduleRaid()
    {
        nextRoster = null;
        foreach (RosterEvent r in EventList.instance.rosterEvents) if (!r.roster.ready) nextRoster = r;
        showPlayer = true;
        manageState = ManageState.Schedule;
        ScheduleDropdown();
    }    
    public void Confirm()
    {
        nextRoster.roster.ready = true;
        nextRoster.CurrentDayAvailable();
        if (scheduleDay >= nextRoster.available[0]) nextRoster.available[0] = scheduleDay;
        else
        {
            nextRoster.available[0] = scheduleDay;
            nextRoster.available[1]++;
            if (nextRoster.available[1] > 4)
            {
                nextRoster.available[1] -= 4;
                nextRoster.available[2]++;
            }
            if (nextRoster.available[2] > 12)
            {
                nextRoster.available[2] -= 12;
                nextRoster.available[3]++;
            }
        }
        nextRoster.ExpireMatchAvailable();
        EventList.instance.events.Add(nextRoster);
        nextRoster = null;
        Manage();
    }
    public void CloseCalendar()
    {
        Utility.instance.TurnOff(GuildUI.instance.calendar);
    }
    public void BossInfoFull() => BossInfo(99);
    public void BossInfo(int x)
    {
        itemList.Clear();
        if (!GuildUI.instance.raidInfoBox.activeSelf ) OpenBossInfo();
        GuildUI.instance.bossInfoText[2].text = $"{nextRoster.roster.dungeon.encountersCompleted}/{nextRoster.roster.dungeon.encounter.Count}";
        GuildUI.instance.bossInfoText[3].text = $"{nextRoster.roster.roster.Count}/{nextRoster.roster.dungeon.maxPlayers}";
        GuildUI.instance.bossInfoText[4].text = nextRoster.roster.dungeon.dungeonCompleted > 0 ? nextRoster.roster.dungeon.dungeonCompleted.ToString() : "";
        GuildUI.instance.bossInfoText[5].text = nextRoster.roster.dungeon.recommendedGearScore.ToString();
        GuildUI.instance.bossAbilityImages[4].sprite = nextRoster.roster.dungeon.dungeonCompleted > 0 ? GuildUI.instance.roleSprites[4] : GuildUI.instance.roleSprites[5];
        if (x == 99)
        {
            nextRoster.roster.dungeon.description[0]= nextRoster.roster.dungeon.description[0].Replace("\\n", "\n");
            GuildUI.instance.bossInfoText[0].text = nextRoster.roster.dungeon.description[0];
            GuildUI.instance.bossInfoText[1].text = "";
            GuildUI.instance.bossInfoText[10].text = "Select a boss to see their abilities";
            foreach (Encounter e in nextRoster.roster.dungeon.encounter) foreach (ItemSO i in e.possibleDrops) if (!itemList.Contains(i)) itemList.Add(i);
            Utility.instance.TurnOff(GuildUI.instance.abilities);
        }
        else
        {
            Boss b = (Boss)nextRoster.roster.dungeon.encounter[x].bossSummon[0];
            Utility.instance.TurnOn(GuildUI.instance.abilities);
            b.flavor =b.flavor.Replace("\\n", "\n");
            GuildUI.instance.bossInfoText[0].text = b.flavor;
            GuildUI.instance.bossInfoText[1].text = b.characterName;
            GuildUI.instance.bossInfoText[10].text = "";
            foreach(Image i in GuildUI.instance.bossAbilityImages) Utility.instance.TurnOff(i.gameObject);
            GuildUI.instance.bossInfoText[6].text =   "";
            GuildUI.instance.bossInfoText[7].text =   "";
            GuildUI.instance.bossInfoText[8].text =   "";
            GuildUI.instance.bossInfoText[9].text = "";
            List < Ability > list = b.AbilityListReturn();
            if(list!= null)
            {
                for (int i = 0; i < list.Count; i++)
                {
                    Utility.instance.TurnOn(GuildUI.instance.bossAbilityImages[i].gameObject);
                    GuildUI.instance.bossAbilityImages[i].sprite = list[i].pic;
                    GuildUI.instance.bossInfoText[i + 6].text = list[i].abilityName;
                }
                foreach (ItemSO i in nextRoster.roster.dungeon.encounter[x].possibleDrops) if (!itemList.Contains(i)) itemList.Add(i);
            }
            else
            {
                GuildUI.instance.bossInfoText[10].text = "No abilities to speak of. Have At!";
            }
        }
           
        foreach (Image i in GuildUI.instance.bossDropSprite) Utility.instance.TurnOff(i.gameObject);
        for (int i = 0; i < itemList.Count; i++)
        {
            Utility.instance.TurnOn(GuildUI.instance.bossDropSprite[i].gameObject);
            GuildUI.instance.bossDropSprite[i].GetComponent<ItemSprite>().pic.sprite = itemList[i].pic;
        }
    }

    public void Manage()
    {
        foreach (TMP_Text t in GuildUI.instance.playerButtonNames) t.fontSize = 24;
        GuildUI.instance.raidInfo[0].text = "";        
        Utility.instance.TurnOff(GuildUI.instance.raidInformationObject);
        Utility.instance.TurnOff(GuildUI.instance.calendar);
        Utility.instance.TurnOff(GuildUI.instance.playerInformationObject);
        Utility.instance.TurnOff(GuildUI.instance.characterInformationObject);
        Utility.instance.TurnOff(GuildUI.instance.scheduleDropdown.gameObject);
        Utility.instance.TurnOff(GuildUI.instance.raidDropdown.gameObject);
        Utility.instance.TurnOff(GuildUI.instance.taskObject);
        Utility.instance.TurnOff(GuildUI.instance.characterButton[0].gameObject);
        //GET NAMES FOR BUTTONS
        List<string> rec = new List<string> { "View Roster", "Assign Tasks", "Schedule Raid", "Guild Upgrades" };
        List<string> vie = new List<string> { "Recruit", "Assign Tasks", "Schedule Raid", "Guild Upgrades" };
        List<string> ass = new List<string> { "Recruit", "View Roster", "Schedule Raid", "Guild Upgrades" };
        List<string> sched = new List<string> { "Recruit", "View Roster", "Assign Tasks", "Guild Upgrades" };
        List<string> up = new List<string> { "Recruit", "View Roster", "Assign Tasks", "Schedule Raid" };
        List<string> cod =roster.Count>0? new List<string> { "View Roster", "Assign Tasks", "Schedule Raid", "Guild Upgrades" } :new List<string> { "Recruit", "Assign Tasks", "Schedule Raid", "Guild Upgrades" };
        List<string> buttonNameList = manageState == ManageState.Recruit ? rec : manageState == ManageState.View ? vie : manageState == ManageState.Assign ? ass : manageState == ManageState.Schedule ? sched : manageState == ManageState.Upgrades ? up : cod;
        for (int i = 0; i < buttonNameList.Count; i++) GuildUI.instance.guildButton[i].GetComponentInChildren<TMP_Text>().text = buttonNameList[i];
        //Generic Stuff
        SortId(CharacterList.instance.charactersInTheGame);
        SortId(roster);
        GuildInfoShow();
        //Manage based on what state
        if (manageState == ManageState.Recruit || manageState == ManageState.View)
        {
            Utility.instance.TurnOff(GuildUI.instance.raidInfoBox);
            Utility.instance.TurnOn(GuildUI.instance.characterButton[0].gameObject);
            foreach (GameObject g in GuildUI.instance.backgroundObject) Utility.instance.TurnOn(g);
            List<Player> list = manageState == ManageState.Recruit ? CharacterList.instance.charactersInTheGame : roster;
            ButtonStuff(list);
            for (int i = 0; i < list.Count; i++) GuildUI.instance.playerButtonCost[i].text = Mathf.Floor(list[i].currentSkill).ToString();
            if (targetPlayer == null) Utility.instance.TurnOff(GuildUI.instance.playerBox);
            else
            {
                Utility.instance.TurnOn(GuildUI.instance.playerBox);
                DisplayPlayerInfo();
                DisplayCharacterInfo();
            }
        }
        else if (manageState == ManageState.Assign)
        {
            Utility.instance.TurnOff(GuildUI.instance.raidInfoBox);
            foreach (GameObject g in GuildUI.instance.backgroundObject) Utility.instance.TurnOn(g);
            List<Player> list = manageState == ManageState.Recruit ? CharacterList.instance.charactersInTheGame : roster;
            ButtonStuff(list);
            for (int i = 0; i < list.Count; i++) GuildUI.instance.playerButtonCost[i].text = roster[i].task.ToString();
            if (targetPlayer == null) Utility.instance.TurnOff(GuildUI.instance.playerBox);
            else
            {
                Utility.instance.TurnOn(GuildUI.instance.playerBox);
                DisplayPlayerInfo();
                Utility.instance.TurnOn(GuildUI.instance.taskObject);
            }
        }    
        else if (manageState == ManageState.Schedule)
        {
            availableToday.Clear();
            Utility.instance.TurnOn(GuildUI.instance.scheduleDropdown.gameObject);
            Utility.instance.TurnOn(GuildUI.instance.raidDropdown.gameObject);
            foreach (GameObject g in GuildUI.instance.backgroundObject) Utility.instance.TurnOn(g);
            if (nextRoster != null)
            {
                foreach (Player p in roster) if (p.availableDays.Contains(scheduleDay)) availableToday.Add(p);
                ButtonStuff(availableToday);
                for (int i = 0; i < availableToday.Count; i++) GuildUI.instance.playerButtonCost[i].text = nextRoster.roster.roster.Contains(availableToday[i].currentClass) ? "Yes" : "No";
            }
            else foreach (Button b in GuildUI.instance.playerButton) Utility.instance.TurnOff(b.gameObject);
            DisplayRaids();            
        }
        else if (manageState == ManageState.Upgrades)
        {
            Utility.instance.TurnOff(GuildUI.instance.raidInfoBox);
            Utility.instance.TurnOn(GuildUI.instance.upgradeInformationObject);            
            foreach (GameObject g in GuildUI.instance.backgroundObject) Utility.instance.TurnOn(g);
            foreach (Button b in GuildUI.instance.playerButton) Utility.instance.TurnOff(b.gameObject);
            foreach (Image i in GuildUI.instance.guildUpgradeImages) Utility.instance.TurnOff(i.gameObject);
            //Upgrade Buttons
            foreach (TMP_Text t in GuildUI.instance.playerButtonNames)t.fontSize = 20;
            for (int i = 0; i < availableUpgrades.Count; i++)
            {
                Utility.instance.TurnOn(GuildUI.instance.playerButton[i].gameObject);                
                GuildUI.instance.playerButtonNames[i].text = availableUpgrades[i].upgradeName;
                GuildUI.instance.playerButtonClasses[i].text = UpgradeAvailable(availableUpgrades[i]) ? "Available" : "Unavailable";
                GuildUI.instance.playerButtonClasses[i].color = UpgradeAvailable(availableUpgrades[i]) ? today : behind;
            }
            for (int i = 0; i < availableUpgrades.Count; i++) GuildUI.instance.playerButtonCost[i].text = UpgradeAvailable(availableUpgrades[i]) ? $"<color={darkGreen}>{availableUpgrades[i].cost}</color>" : $"<color={red}>{availableUpgrades[i].cost}</color>";
            Utility.instance.TurnOn(GuildUI.instance.playerBox);
            DisplayUpgrade();
        }
    }

    private bool UpgradeAvailable(GuildUpgrade guildUpgrade)
    {
        if(guildUpgrade.renownRequirement>guildRenown|| guildUpgrade.cost > guildCurrency) return false;
        if (guildUpgrade.preReq.Count == 0) return true;
        foreach (GuildUpgrade g in guildUpgrade.preReq) if (!currentUpgrades.Contains(g)) return false;
        return true;
    }

    private void DisplayUpgrade()
    {
        Utility.instance.TurnOn(GuildUI.instance.playerBox);
        Utility.instance.TurnOn(GuildUI.instance.upgradeInformationObject);
        //Right Side
        for (int i = 0; i < currentUpgrades.Count; i++)
        {
            Utility.instance.TurnOn(GuildUI.instance.guildUpgradeImages[i].gameObject);
            GuildUI.instance.guildUpgradeImages[i].GetComponent<ItemSprite>().flavor[0].text = currentUpgrades[i].upgradeName;
        }
        //Left Side
        if(targetUpgrade != null)
        {
            Utility.instance.TurnOn(GuildUI.instance.upgradeLeftSide);
            GuildUI.instance.upgradeInstruction.text = "";
            GuildUI.instance.upgradeLeftText[0].text = targetUpgrade.upgradeName;
            targetUpgrade.description = targetUpgrade.description.Replace("\\n", "\n");
            GuildUI.instance.upgradeLeftText[1].text = targetUpgrade.description;
            GuildUI.instance.upgradeLeftText[2].text = (guildRenown >= targetUpgrade.renownRequirement) ? $"<color={green}>{targetUpgrade.renownRequirement} Renown</color>" : $"<color={red}>{targetUpgrade.renownRequirement} Renown</color>";
            for (int i = 0; i < targetUpgrade.preReq.Count; i++) GuildUI.instance.upgradeLeftText[2].text += (currentUpgrades.Contains(targetUpgrade.preReq[i])) ? $", <color={green}>{targetUpgrade.preReq[i].upgradeName}</color>" : $", <color={red}>{targetUpgrade.preReq[i].upgradeName}</color>";
            GuildUI.instance.upgradeLeftText[3].text = UpgradeAvailable(targetUpgrade) ? $"<color={darkGreen}>{targetUpgrade.cost} Currency</color>" : $"<color={red}>{targetUpgrade.cost} Currency</color>";
        }
        else
        {
            Utility.instance.TurnOff(GuildUI.instance.upgradeLeftSide);
            GuildUI.instance.upgradeInstruction.text = "Please select an Upgrade";
        }
    }
    public void BuyUpgrade()
    {
        if (UpgradeAvailable(targetUpgrade))
        {
            guildCurrency -= targetUpgrade.cost;
            currentUpgrades.Add(targetUpgrade);
            availableUpgrades.Remove(targetUpgrade);
            targetUpgrade = null;
            Manage();
        }
    }

    private void DisplayRaids()
    {
        Utility.instance.TurnOn(GuildUI.instance.playerBox);
        if (nextRoster != null)
        {
            if (nextRoster.roster.dungeon == null)
            {
                nextRoster.roster.dungeon = DungeonManager.instance.pve[0];
                GuildUI.instance.raidDropdown.options.Clear();
                for (int i = 0; i < DungeonManager.instance.pve.Count; i++) GuildUI.instance.raidDropdown.AddOptions(new List<string> { DungeonManager.instance.pve[i].DungeonName });                
                BossInfo(99);
            }
            Utility.instance.TurnOn(GuildUI.instance.raidInformationObject);
            ////////////////
            //RIGHT SIDE
            ////////////////
            GuildUI.instance.guildInfo[2].text = nextRoster.roster.dungeon.DungeonName;
            //Load Player Info
            for (int i = 0; i < 7; i++)
            {
                if (nextRoster.roster.roster.Count > i)
                {
                    GuildUI.instance.raidInfo[i * 2 + 2].text = nextRoster.roster.roster[i].characterName;
                    GuildUI.instance.raidInfo[i * 2 + 3].text = Utility.instance.Class(nextRoster.roster.roster[i]);
                }
                else
                {
                    GuildUI.instance.raidInfo[i * 2 + 2].text = "";
                    GuildUI.instance.raidInfo[i * 2 + 3].text = "";
                }
            }
            GuildUI.instance.raidInfo[16].text = $"{nextRoster.roster.dungeon.encountersCompleted}/{nextRoster.roster.dungeon.encounter.Count}";
            GuildUI.instance.raidInfo[17].text = $"{nextRoster.roster.roster.Count}/{nextRoster.roster.dungeon.maxPlayers}";
            GuildUI.instance.raidInfo[18].text = nextRoster.roster.dungeon.dungeonCompleted > 0 ? nextRoster.roster.dungeon.dungeonCompleted.ToString() : "";
            GuildUI.instance.raidInfo[19].text = nextRoster.roster.dungeon.recommendedGearScore.ToString();
            GuildUI.instance.raidRoleImages[7].sprite = nextRoster.roster.dungeon.dungeonCompleted > 0 ? GuildUI.instance.roleSprites[4] : GuildUI.instance.roleSprites[5];
            //Load Player Role Pic
            for (int i = 0; i < 7; i++) Utility.instance.TurnOff(GuildUI.instance.raidRoleImages[i].gameObject);
            for (int i = 0; i < 7; i++)
            {
                if (nextRoster.roster.roster.Count > i)
                {
                    Utility.instance.TurnOn(GuildUI.instance.raidRoleImages[i].gameObject);
                    GuildUI.instance.raidRoleImages[i].sprite = Utility.instance.ReturnSpec(nextRoster.roster.roster[i]) == Spec.Stalwart ? GuildUI.instance.roleSprites[0] : (Utility.instance.ReturnSpec(nextRoster.roster.roster[i]) == Spec.Redemptive || Utility.instance.ReturnSpec(nextRoster.roster.roster[i]) == Spec.Tranquil) ? GuildUI.instance.roleSprites[1] : Utility.instance.ReturnSpec(nextRoster.roster.roster[i]) == Spec.Inspiring ? GuildUI.instance.roleSprites[3] : GuildUI.instance.roleSprites[2];
                }
            }
            ////////////////
            //LEFT SIDE
            ////////////////
            if (targetPlayer != null)
            {
                if (showPlayer) DisplayPlayerInfo();
                else DisplayCharacterInfo();
                Utility.instance.TurnOn(GuildUI.instance.raidButtons[1].gameObject);
                Utility.instance.TurnOn(GuildUI.instance.raidButtons[2].gameObject);
                GuildUI.instance.raidButtons[1].GetComponentInChildren<TMP_Text>().text = showPlayer ? "Character" : "Player";
                GuildUI.instance.raidButtons[2].GetComponentInChildren<TMP_Text>().text = nextRoster.roster.roster.Contains(targetPlayer.currentClass) ? "Remove from Raid" : "Add To Raid";
                GuildUI.instance.raidInfo[0].text = "";
            }
            else
            {
                Utility.instance.TurnOff(GuildUI.instance.raidButtons[1].gameObject);
                Utility.instance.TurnOff(GuildUI.instance.raidButtons[2].gameObject);
                GuildUI.instance.raidInfo[0].text = availableToday.Count == 0 ? "No One is Available Today\n\nSelect another day or Recruit more players" : "Please select a player to bring to the dungeon";
            }
        }
        else
        {
            GuildUI.instance.raidInfo[0].text = "All of your raids have been schduled for the week";
        }
    }
    private void DisplayCharacterInfo()
    {
        Utility.instance.TurnOn(GuildUI.instance.characterInformationObject);
        if (manageState == ManageState.Recruit || manageState == ManageState.View) GuildUI.instance.characterInformationObject.transform.localPosition = new Vector3(0, 0, 0);
        else GuildUI.instance.characterInformationObject.transform.localPosition = new Vector3(-570, 0, 0);
        GuildUI.instance.characterInfo[0].text = Utility.instance.Class(targetPlayer.currentClass);
        GuildUI.instance.characterInfo[1].text = Math.Floor(targetPlayer.currentSkill).ToString();
        GuildUI.instance.characterInfo[2].text = Utility.instance.SpecNameShort(targetPlayer.currentClass);
        GuildUI.instance.characterInfo[3].text = seeHidden || manageState != ManageState.Recruit ? $"{targetPlayer.currentClass.maxHealth.value}/{targetPlayer.currentClass.maxHealth.value}" : "???";
        GuildUI.instance.characterInfo[4].text = seeHidden || manageState != ManageState.Recruit ? $"{targetPlayer.currentClass.maxMana.value}/{targetPlayer.currentClass.maxMana.value}" : "???";
        GuildUI.instance.characterInfo[5].text = seeHidden || manageState != ManageState.Recruit ? targetPlayer.currentClass.damage.value.ToString() : "?";
        GuildUI.instance.characterInfo[6].text = seeHidden || manageState != ManageState.Recruit ? targetPlayer.currentClass.crit.value.ToString() : "?";
        GuildUI.instance.characterInfo[7].text = seeHidden || manageState != ManageState.Recruit ? targetPlayer.currentClass.defence.value.ToString() : "?";
        GuildUI.instance.characterInfo[8].text = seeHidden || manageState != ManageState.Recruit ? targetPlayer.currentClass.spellpower.value.ToString() : "?";
        int gs = targetPlayer.currentClass.head.score + targetPlayer.currentClass.chest.score + targetPlayer.currentClass.legs.score + targetPlayer.currentClass.feet.score + targetPlayer.currentClass.trinket.score + targetPlayer.currentClass.weapon.score + targetPlayer.currentClass.offHand.score;
        GuildUI.instance.characterInfo[9].text = seeHidden || manageState != ManageState.Recruit ? gs.ToString() : "???";
        GuildUI.instance.paperDollImages[0].sprite = !seeHidden && manageState == ManageState.Recruit ? unknown : targetPlayer.currentClass.head.pic;
        GuildUI.instance.paperDollImages[1].sprite = !seeHidden && manageState == ManageState.Recruit ? unknown : targetPlayer.currentClass.chest.pic;
        GuildUI.instance.paperDollImages[2].sprite = !seeHidden && manageState == ManageState.Recruit ? unknown : targetPlayer.currentClass.legs.pic;
        GuildUI.instance.paperDollImages[3].sprite = !seeHidden && manageState == ManageState.Recruit ? unknown : targetPlayer.currentClass.feet.pic;
        GuildUI.instance.paperDollImages[4].sprite = !seeHidden && manageState == ManageState.Recruit ? unknown : targetPlayer.currentClass.weapon.pic;
        GuildUI.instance.paperDollImages[5].sprite = !seeHidden && manageState == ManageState.Recruit ? unknown : targetPlayer.currentClass.weapon.hands == Hands.Two ? targetPlayer.currentClass.weapon.pic : targetPlayer.currentClass.offHand.pic;
        GuildUI.instance.paperDollImages[6].sprite = !seeHidden && manageState == ManageState.Recruit ? unknown : targetPlayer.currentClass.trinket.pic;
    }   

    private void DisplayPlayerInfo()
    {
        Utility.instance.TurnOn(GuildUI.instance.playerInformationObject);        
        GuildUI.instance.characterButton[0].GetComponentInChildren<TMP_Text>().text = manageState == ManageState.View ? "Fire" : "Recruit";
        if (targetPlayer.altClass != null) Utility.instance.TurnOn(GuildUI.instance.characterButton[1].gameObject);
        else Utility.instance.TurnOff(GuildUI.instance.characterButton[1].gameObject);
        GuildUI.instance.playerInfo[0].text = targetPlayer.playerName;
        List<string> d = new List<string> { "", "M", "Tu", "W", "Th", "F", "Sat", "Sun" };
        string days = "";
        for (int i = 0; i < targetPlayer.availableDays.Count; i++)
        {
            if (i == targetPlayer.availableDays.Count - 1) days += d[targetPlayer.availableDays[i]];
            else days += d[targetPlayer.availableDays[i]] + ", ";
        }
        GuildUI.instance.playerInfo[1].text = $"Available: {days}";
        GuildUI.instance.playerInfo[2].text = "Available Today: " + (targetPlayer.availableDays.Contains(TimeManagement.instance.day) ? "Yes" : "No");
        GuildUI.instance.playerInfo[3].text = manageState == ManageState.Recruit ? $"Cost: {Mathf.Floor(targetPlayer.currentSkill)}" : "";
        string a = "Ambition: ";
        a += seeHidden || manageState != ManageState.Recruit ? Math.Floor(targetPlayer.ambition) : "???";
        string b = "Guild Loyalty: ";
        b += seeHidden || manageState != ManageState.Recruit ? Math.Floor(targetPlayer.guildLoyalty) : "???";
        string c = "Shards: ";
        c += seeHidden || manageState != ManageState.Recruit ? Math.Floor(targetPlayer.enchantmentShards) : "???";
        GuildUI.instance.playerInfo[4].text = a;
        GuildUI.instance.playerInfo[5].text = b;
        GuildUI.instance.playerInfo[6].text = c;
        GuildUI.instance.playerInfo[7].text = !seeHidden && manageState == ManageState.Recruit ? "???" : targetPlayer.traits.Count > 0 ? targetPlayer.traits[0].traitName : "None";
        GuildUI.instance.playerInfo[8].text = !seeHidden && manageState == ManageState.Recruit ? "???" : targetPlayer.traits.Count > 1 ? targetPlayer.traits[1].traitName : "";
        GuildUI.instance.playerInfo[9].text = !seeHidden && manageState == ManageState.Recruit ? "???" : targetPlayer.traits.Count > 2 ? targetPlayer.traits[2].traitName : "";
        if (roster.Contains(targetPlayer)) GuildUI.instance.playerInfo[10].text = targetPlayer.task ==Task.None?"Task: None": $"Task: {targetPlayer.task} - {targetPlayer.timeOnTask} days";
        else GuildUI.instance.playerInfo[10].text = "";
    }

    public void GuildInfoShow()
    {
        GuildUI.instance.guildInfo[0].text = manageState == ManageState.Recruit ? "Recruit" :manageState == ManageState.View ?"View Roster":manageState == ManageState.Schedule ? "Schedule Raid":"Assign Tasks";
        GuildUI.instance.guildInfo[1].text = manageState == ManageState.Schedule ? "" : $"Guild Renown: {guildRenown}";
        GuildUI.instance.guildInfo[2].text = manageState == ManageState.Schedule ? "" : $"Guild Currency: {guildCurrency}";
    }
    public void AddRemoveFromRaid()
    {
        if (nextRoster.roster.roster.Contains(targetPlayer.currentClass)) nextRoster.roster.roster.Remove(targetPlayer.currentClass);
        else nextRoster.roster.roster.Add(targetPlayer.currentClass);
        Manage();
    }
    public void PlayerCharacterShow()
    {
        if (showPlayer) showPlayer = false;
        else showPlayer = true;
        Manage();
    }

    private void ButtonStuff(List<Player> list)
    {
        foreach (Button b in GuildUI.instance.playerButton) Utility.instance.TurnOff(b.gameObject);
        for (int i = 0; i < list.Count; i++)
        {
            Utility.instance.TurnOn(GuildUI.instance.playerButton[i].gameObject);
            GuildUI.instance.playerButtonNames[i].text = list[i].playerName;
            GuildUI.instance.playerButtonClasses[i].text = Utility.instance.Class(list[i].currentClass);
        }
    }
    private void SortId(List<Player> list)
    {
        Player temp;
        for (int j = 0; j <= list.Count - 2; j++)
        {
            for (int i = 0; i <= list.Count - 2; i++)
            {
                if (list[i].currentClass.id > list[i + 1].currentClass.id)
                {
                    temp = list[i + 1];
                    list[i + 1] = list[i];
                    list[i] = temp;
                }
            }
        }
    }

    public List<Player> NotInDungeon(List<Character> inFight)
    {
        List<Player> notInFight = new List<Player> { };
        foreach (Player a in roster) if (!inFight.Contains(a.currentClass)) notInFight.Add(a);
        return notInFight;
    }
    public List<Player> NotInDungeon(List<Player> inFight)
    {
        List<Player> notInFight = new List<Player> { };
        foreach (Player a in roster) if (!inFight.Contains(a)) notInFight.Add(a);
        return notInFight;
    }

    internal void ButtonPress(int id)
    {
        if (manageState == ManageState.Upgrades) targetUpgrade = availableUpgrades[id];
        else targetPlayer = manageState == ManageState.Recruit ? CharacterList.instance.charactersInTheGame[id] : manageState == ManageState.Schedule ? availableToday[id] : roster[id];
        Manage();
    }
    public void Assign(int id)
    {
        targetPlayer.task = (Task)id;
        Manage();
    }
    public void ChangeSpec()
    {
        targetPlayer.currentClass.ChangeSpec();
        targetPlayer.UpdateName();
        Manage();
    }
    public void SwitchCharacter()
    {
        targetPlayer.Switch();
        targetPlayer.UpdateName();
        Manage();
    }
    public void ViewCalendar()
    {
        displayYear = TimeManagement.instance.year;
        displayMonth = TimeManagement.instance.month;
        CalendarShow();
    }

    private void CalendarShow()
    {
        Utility.instance.TurnOn(GuildUI.instance.calendar);
        GuildUI.instance.calendarInfo[0].text = TimeManagement.instance.MonthDisplay(displayMonth);
        GuildUI.instance.calendarInfo[1].text = displayYear.ToString();
        //Show Events
        for (int i = 0; i < GuildUI.instance.guildDays.Count; i++)
        {
            GuildUI.instance.guildDays[i].GetComponent<ItemSprite>().flavor[1].text = "";
            if (i == 2 || i == 9 || i == 16 || i == 23) GuildUI.instance.guildDays[i].GetComponent<ItemSprite>().flavor[1].text = "Reset Dungeons";
            int gDay = i + 1;
            int gWeek = 1;
            while (gDay > 7)
            {
                gDay -= 7;
                gWeek++;
            }
            if (EventList.instance.CalendarEvents(gDay, gWeek, displayMonth, displayYear - 2021).Count > 0)
            {
                foreach (Event e in EventList.instance.CalendarEvents(gDay, gWeek, displayMonth, displayYear - 2021))
                {
                    if (e.id == 11)
                    {
                        RosterEvent r = (RosterEvent)e;
                        GuildUI.instance.guildDays[i].GetComponent<ItemSprite>().flavor[1].text += r.roster.dungeon.DungeonName;
                    }
                }
            }
        }
        if (displayYear > TimeManagement.instance.year || (displayYear == TimeManagement.instance.year && displayMonth > TimeManagement.instance.month)) foreach (Image i in GuildUI.instance.guildDays) i.GetComponent<ItemSprite>().flavor[0].color = ahead;
        else
        {
            for (int i = 0; i < GuildUI.instance.guildDays.Count; i++)
            {
                if (i + 1 == TimeManagement.instance.day + (TimeManagement.instance.week - 1) * 7) GuildUI.instance.guildDays[i].GetComponent<ItemSprite>().flavor[0].color = today;
                else if (i + 1 > TimeManagement.instance.day + (TimeManagement.instance.week - 1) * 7) GuildUI.instance.guildDays[i].GetComponent<ItemSprite>().flavor[0].color = ahead;
                else GuildUI.instance.guildDays[i].GetComponent<ItemSprite>().flavor[0].color = behind;                
            }
        }
    }

    public void ViewCalendarForward()
    {
        displayMonth++;
        if (displayMonth > 12)
        {
            displayMonth -= 12;
            displayYear++;
        }
        CalendarShow();
    }
    public void ViewCalendarBackward()
    {
        if(!(displayYear == TimeManagement.instance.year&& displayMonth == TimeManagement.instance.month))
        {
            displayMonth--;
            if (displayMonth <=0)
            {
                displayMonth += 12;
                displayYear--;
            }
        }
        CalendarShow();
    }
}