using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SocialPlatforms.Impl;
using UnityEngine.UI;
using TMPro;

public enum ManageState {Recruit, View,Assign, Schedule,Codex,Upgrades}
public class Guild : MonoBehaviour
{
    public static Guild instance;
    public List<Player> roster;
    public List<Player> mainRaidRoster;
    public List<Player> farmRaidRoster;
    public int mainRaidDay;
    public int farmRaidDay;
    public float guildRenown;
    public float guildCurrency;
    public float orderCooldown;
    public Player target;
    public ManageState manageState;
    public bool seeHidden;
    public Sprite unknown;
    public bool itemToolTipHold;
    public bool guildToolTipHold;

    private void Awake()
    {
        instance = this;
        guildCurrency = guildRenown = 10;
        //seeHidden = true;
    }
    public void NullifyTarget()
    {
        target = null;
        Manage();
    }
    internal void ItemTooltipOff()
    {
        Utility.instance.TurnOff(GuildUI.instance.itemTooltip.gameObject);
    }

    internal void ItemTooltipOn(int id)
    {
        Item i = id == 0 ? target.currentClass.head : id == 1 ? target.currentClass.chest : id == 2 ? target.currentClass.legs : id == 3 ? target.currentClass.feet : id == 4 ? target.currentClass.weapon : id == 5 && target.currentClass.weapon.hands==Hands.Two? target.currentClass.weapon :id == 5 ? target.currentClass.offHand: target.currentClass.trinket;
        Utility.instance.TurnOn(GuildUI.instance.itemTooltip.gameObject);
        GuildUI.instance.ItemTooltipInfo[0].text = i.itemName;
        GuildUI.instance.ItemTooltipInfo[1].text = i.health.ToString();
        GuildUI.instance.ItemTooltipInfo[2].text = i.mana.ToString();
        GuildUI.instance.ItemTooltipInfo[3].text =  i.damage.ToString();
        GuildUI.instance.ItemTooltipInfo[4].text =  i.crit.ToString();
        GuildUI.instance.ItemTooltipInfo[5].text =  i.defence.ToString();
        GuildUI.instance.ItemTooltipInfo[6].text = i.spellpower.ToString();
        GuildUI.instance.ItemTooltipInfo[7].text =  i.range.ToString();
        GuildUI.instance.ItemTooltipInfo[8].text =  i.haste.ToString();
        GuildUI.instance.ItemTooltipInfo[9].text = i.vamp.ToString();
        GuildUI.instance.ItemTooltipInfo[10].text = i.movement.ToString();
        GuildUI.instance.ItemTooltipInfo[11].text = i.score.ToString();
        GuildUI.instance.ItemTooltipInfo[12].text =i.flavor[0];
        GuildUI.instance.ItemTooltipInfo[13].text =i.flavor[1];
        GuildUI.instance.ItemTooltipInfo[14].text = i.flavor[2];
    }
    internal void GuildTooltipOff()
    {
        Utility.instance.TurnOff(GuildUI.instance.guildTooltip.gameObject);
    }

    internal void GuildTooltipOn(int id, Vector2 position)
    {
        if (id == 1) 
        {
            if (target.traits.Count > 1) GuildTooltipOn(target.traits[0].flavor,position);
            else GuildTooltipOn(new List<string> { "Player has no traits" }, position);
        }
        else if (id == 2) GuildTooltipOn(target.traits[1].flavor, position);
        else if (id == 3) GuildTooltipOn(target.traits[2].flavor, position);
    }
    internal void GuildTooltipOn(List<string> flavor, Vector2 position)
    {
        Utility.instance.TurnOn(GuildUI.instance.guildTooltip.gameObject);
        GuildUI.instance.guildTooltip.transform.position =new Vector2(position.x+200,position.y);
        foreach (TMP_Text t in GuildUI.instance.guildTooltipInfo) t.text = "";
        for (int i = 0; i < flavor.Count; i++) GuildUI.instance.guildTooltipInfo[i].text = flavor[i];
    }
    public void RecruitOrFireTarget()
    {
        if (!roster.Contains(target))
        {
            if (guildCurrency >= Math.Floor(target.currentSkill))
            {
                guildCurrency -= (float)Math.Floor(target.currentSkill);
                target.guildLoyalty = 60;
                roster.Add(target);
                target.transform.SetParent(GameManager.instance.guild.transform);
                CharacterList.instance.charactersInTheGame.Remove(target);
            }
        }
        else
        {
            target.guildLoyalty = 5;
            roster.Remove(target);
            target.transform.SetParent(GameManager.instance.freeAgent.transform);
            CharacterList.instance.charactersInTheGame.Add(target);
            target = null;
        }
        NullifyTarget();
    }

    public void Button1()
    {
        if (manageState == ManageState.Recruit) manageState = ManageState.View;
        else if (manageState == ManageState.View) manageState = ManageState.Recruit;
        else if (manageState == ManageState.Assign) manageState = ManageState.Recruit;
        else if (manageState == ManageState.Schedule) manageState = ManageState.Recruit;
        else if (manageState == ManageState.Upgrades) manageState = ManageState.Recruit;
        else if (manageState == ManageState.Codex) manageState =roster.Count>0? ManageState.View:ManageState.Recruit;
        target = null;
        Manage();
    }
    public void Button2()
    {
        if (manageState == ManageState.Recruit) manageState = ManageState.Assign;
        else if (manageState == ManageState.View) manageState = ManageState.Assign;
        else if (manageState == ManageState.Assign) manageState = ManageState.View;
        else if (manageState == ManageState.Schedule) manageState = ManageState.View;
        else if (manageState == ManageState.Upgrades) manageState = ManageState.View;
        else if (manageState == ManageState.Codex) manageState = ManageState.Assign;
        target = null;
        Manage();
    }
    public void Button3()
    {
        if (manageState == ManageState.Recruit) manageState = ManageState.Schedule;
        else if (manageState == ManageState.View) manageState = ManageState.Schedule;
        else if (manageState == ManageState.Assign) manageState = ManageState.Schedule;
        else if (manageState == ManageState.Schedule) manageState = ManageState.Assign;
        else if (manageState == ManageState.Upgrades) manageState = ManageState.Assign;
        else if (manageState == ManageState.Codex) manageState = ManageState.Schedule;
        target = null;
        Manage();
    }
    public void Button4()
    {
        if (manageState == ManageState.Recruit) manageState = ManageState.Upgrades;
        else if (manageState == ManageState.View) manageState = ManageState.Upgrades;
        else if (manageState == ManageState.Assign) manageState = ManageState.Upgrades;
        else if (manageState == ManageState.Schedule) manageState = ManageState.Upgrades;
        else if (manageState == ManageState.Upgrades) manageState = ManageState.Schedule;
        else if (manageState == ManageState.Codex) manageState = ManageState.Upgrades;
        target = null;
        Manage();
    }
    public void Button5()
    {
        manageState = ManageState.Codex;
        target = null;
        Manage();
    }

    public void Manage()
    {
        //GET NAMES FOR BUTTONS
        List<string> rec = new List<string> { "View", "Assign", "Schedule", "Upgrade" };
        List<string> vie = new List<string> { "Recruit", "Assign", "Schedule", "Upgrade" };
        List<string> ass = new List<string> { "Recruit", "View", "Schedule", "Upgrade" };
        List<string> sched = new List<string> { "Recruit", "View", "Assign", "Upgrade" };
        List<string> up = new List<string> { "Recruit", "View", "Assign", "Schedule" };
        List<string> cod =roster.Count>0? new List<string> { "View", "Assign", "Schedule","Upgrade" }:new List<string> { "Recruit", "Assign", "Schedule", "Upgrade" };
        List<string> buttonNameList = manageState == ManageState.Recruit ? rec : manageState == ManageState.View ? vie : manageState == ManageState.Assign ? ass : manageState == ManageState.Schedule ? sched : manageState == ManageState.Upgrades ? up : cod;
        for (int i = 0; i < buttonNameList.Count; i++) GuildUI.instance.guildButton[i].GetComponentInChildren<TMP_Text>().text = buttonNameList[i];
        //Manage based on what state
        if(manageState == ManageState.Recruit || manageState == ManageState.View)
        {
            List<Player> list = manageState == ManageState.Recruit ? CharacterList.instance.charactersInTheGame : roster;
            GenericInfo(list);
            for (int i = 0; i < list.Count; i++) GuildUI.instance.playerButtonCost[i].text = Mathf.Floor(list[i].currentSkill).ToString();
            if (target == null) NoTargetInfo();
            else DisplayTargetInfo();
        }
        else if (manageState == ManageState.Assign)
        {
            List<Player> list = manageState == ManageState.Recruit ? CharacterList.instance.charactersInTheGame : roster;
            GenericInfo(list);
            for (int i = 0; i < list.Count; i++) GuildUI.instance.playerButtonCost[i].text = roster[i].task.ToString();
            if (target == null) NoTargetInfo();
            else DisplayTask();
        }
        
    }

    private void GenericInfo(List<Player> list)
    {
        SortId(CharacterList.instance.charactersInTheGame);
        SortId(roster);
        GuildInfoShow();
        foreach (Button b in GuildUI.instance.playerButton) Utility.instance.TurnOff(b.gameObject);
        for (int i = 0; i < list.Count; i++)
        {
            Utility.instance.TurnOn(GuildUI.instance.playerButton[i].gameObject);
            GuildUI.instance.playerButtonNames[i].text = list[i].playerName;
            GuildUI.instance.playerButtonClasses[i].text = Utility.instance.Class(list[i].currentClass);            
        }
    }

    private void DisplayTargetInfo()
    {
        Utility.instance.TurnOn(GuildUI.instance.playerBox);
        DisplayPlayerInfo();
        DisplayCharacterInfo();       
    }
    public void DisplayTask()
    {
        Utility.instance.TurnOn(GuildUI.instance.playerBox);            
        DisplayPlayerInfo();
        Utility.instance.TurnOff(GuildUI.instance.characterButton[0].gameObject);
        DisplayTaskInfo();
    }

    private void DisplayTaskInfo()
    {
        Utility.instance.TurnOn(GuildUI.instance.taskObject);
        Utility.instance.TurnOff(GuildUI.instance.characterInformationObject);
    }

    private void DisplayCharacterInfo()
    {
        Utility.instance.TurnOff(GuildUI.instance.taskObject);
        Utility.instance.TurnOn(GuildUI.instance.characterInformationObject);
        GuildUI.instance.characterInfo[0].text = Utility.instance.Class(target.currentClass);
        GuildUI.instance.characterInfo[1].text = Math.Floor(target.currentSkill).ToString();
        GuildUI.instance.characterInfo[2].text = Utility.instance.SpecNameShort(target.currentClass);
        GuildUI.instance.characterInfo[3].text = seeHidden || manageState != ManageState.Recruit ? $"{target.currentClass.maxHealth.value}/{target.currentClass.maxHealth.value}" : "???";
        GuildUI.instance.characterInfo[4].text = seeHidden || manageState != ManageState.Recruit ? $"{target.currentClass.maxMana.value}/{target.currentClass.maxMana.value}" : "???";
        GuildUI.instance.characterInfo[5].text = seeHidden || manageState != ManageState.Recruit ? target.currentClass.damage.value.ToString() : "?";
        GuildUI.instance.characterInfo[6].text = seeHidden || manageState != ManageState.Recruit ? target.currentClass.crit.value.ToString() : "?";
        GuildUI.instance.characterInfo[7].text = seeHidden || manageState != ManageState.Recruit ? target.currentClass.defence.value.ToString() : "?";
        GuildUI.instance.characterInfo[8].text = seeHidden || manageState != ManageState.Recruit ? target.currentClass.spellpower.value.ToString() : "?";
        int gs = target.currentClass.head.score + target.currentClass.chest.score + target.currentClass.legs.score + target.currentClass.feet.score + target.currentClass.trinket.score + target.currentClass.weapon.score + target.currentClass.offHand.score;
        GuildUI.instance.characterInfo[9].text = seeHidden || manageState != ManageState.Recruit ? "Gear Score: " + gs.ToString() : "Gear Score: ???";
        GuildUI.instance.paperDollImages[0].sprite = !seeHidden && manageState == ManageState.Recruit ? unknown : target.currentClass.head.pic;
        GuildUI.instance.paperDollImages[1].sprite = !seeHidden && manageState == ManageState.Recruit ? unknown : target.currentClass.chest.pic;
        GuildUI.instance.paperDollImages[2].sprite = !seeHidden && manageState == ManageState.Recruit ? unknown : target.currentClass.legs.pic;
        GuildUI.instance.paperDollImages[3].sprite = !seeHidden && manageState == ManageState.Recruit ? unknown : target.currentClass.feet.pic;
        GuildUI.instance.paperDollImages[4].sprite = !seeHidden && manageState == ManageState.Recruit ? unknown : target.currentClass.weapon.pic;
        GuildUI.instance.paperDollImages[5].sprite = !seeHidden && manageState == ManageState.Recruit ? unknown : target.currentClass.weapon.hands == Hands.Two ? target.currentClass.weapon.pic : target.currentClass.offHand.pic;
        GuildUI.instance.paperDollImages[6].sprite = !seeHidden && manageState == ManageState.Recruit ? unknown : target.currentClass.trinket.pic;
    }

    private void DisplayPlayerInfo()
    {
        Utility.instance.TurnOn(GuildUI.instance.playerInformationObject);
        Utility.instance.TurnOn(GuildUI.instance.characterButton[0].gameObject);
        GuildUI.instance.characterButton[0].GetComponentInChildren<TMP_Text>().text = manageState == ManageState.View ? "Fire" : "Recruit";
        if (target.altClass != null) Utility.instance.TurnOn(GuildUI.instance.characterButton[1].gameObject);
        else Utility.instance.TurnOff(GuildUI.instance.characterButton[1].gameObject);
        GuildUI.instance.playerInfo[0].text = target.playerName;
        List<string> d = new List<string> { "", "M", "Tu", "W", "Th", "F", "Sat", "Sun" };
        string days = "";
        for (int i = 0; i < target.availableDays.Count; i++)
        {
            if (i == target.availableDays.Count - 1) days += d[target.availableDays[i]];
            else days += d[target.availableDays[i]] + ", ";
        }
        GuildUI.instance.playerInfo[1].text = $"Available: {days}";
        GuildUI.instance.playerInfo[2].text = "Available Today: " + (target.availableDays.Contains(TimeManagement.instance.day) ? "Yes" : "No");
        GuildUI.instance.playerInfo[3].text = manageState == ManageState.Recruit ? $"Cost: {Mathf.Floor(target.currentSkill)}" : "";
        string a = "Ambition: ";
        a += seeHidden || manageState != ManageState.Recruit ? Math.Floor(target.ambition) : "???";
        string b = "Guild Loyalty: ";
        b += seeHidden || manageState != ManageState.Recruit ? Math.Floor(target.guildLoyalty) : "???";
        string c = "Shards: ";
        c += seeHidden || manageState != ManageState.Recruit ? Math.Floor(target.enchantmentShards) : "???";
        GuildUI.instance.playerInfo[4].text = a;
        GuildUI.instance.playerInfo[5].text = b;
        GuildUI.instance.playerInfo[6].text = c;
        GuildUI.instance.playerInfo[7].text = !seeHidden && manageState == ManageState.Recruit ? "???" : target.traits.Count > 0 ? target.traits[0].traitName : "None";
        GuildUI.instance.playerInfo[8].text = !seeHidden && manageState == ManageState.Recruit ? "???" : target.traits.Count > 1 ? target.traits[1].traitName : "";
        GuildUI.instance.playerInfo[9].text = !seeHidden && manageState == ManageState.Recruit ? "???" : target.traits.Count > 2 ? target.traits[2].traitName : "";
        if (roster.Contains(target)) GuildUI.instance.playerInfo[10].text = target.task ==Task.None?"Task: None": $"Task: {target.task} - {target.timeOnTask} days";
        else GuildUI.instance.playerInfo[10].text = "";
    }

    public void GuildInfoShow()
    {
        GuildUI.instance.guildInfo[0].text = manageState == ManageState.Recruit ? "Available for Hire" : "Guild Roster";
        GuildUI.instance.guildInfo[1].text = $"Guild Renown: {guildRenown}";
        GuildUI.instance.guildInfo[2].text = $"Guild Currency: {guildCurrency}";
    }
    private void NoTargetInfo()
    {
        Utility.instance.TurnOff(GuildUI.instance.playerBox);
    }
    private void SortId(List<Player> list)
    {
        Player temp;
        for (int j = 0; j <= list.Count - 2; j++)
        {
            for (int i = 0; i <= list.Count - 2; i++)
            {
                if (list[i].currentClass.id > list[i + 1].currentClass.id)
                {
                    temp = list[i + 1];
                    list[i + 1] = list[i];
                    list[i] = temp;
                }
            }
        }
    }

    public List<Player> NotInDungeon(List<Character> inFight)
    {
        List<Player> notInFight = new List<Player> { };
        foreach (Player a in roster) if (!inFight.Contains(a.currentClass)) notInFight.Add(a);
        return notInFight;
    }
    public List<Player> NotInDungeon(List<Player> inFight)
    {
        List<Player> notInFight = new List<Player> { };
        foreach (Player a in roster) if (!inFight.Contains(a)) notInFight.Add(a);
        return notInFight;
    }

    internal void ButtonPress(int id)
    {
        target = manageState == ManageState.Recruit ? CharacterList.instance.charactersInTheGame[id] : roster[id];
        if (manageState == ManageState.Assign) DisplayTask();
        else DisplayTargetInfo();
    }
    public void Assign(int id)
    {
        target.task = (Task)id;
        Manage();
    }
    public void ChangeSpec()
    {
        target.currentClass.ChangeSpec();
        target.UpdateName();
        DisplayTargetInfo();
    }
    public void SwitchCharacter()
    {
        target.Switch();
        target.UpdateName();
        DisplayTargetInfo();
    }
}
