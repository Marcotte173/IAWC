using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SocialPlatforms.Impl;
using UnityEngine.UI;
using TMPro;
using static UnityEditor.Experimental.GraphView.GraphView;
using UnityEngine.XR;

public enum ManageState {Recruit, View,Assign, Schedule,Codex,Upgrades}
public class Guild : MonoBehaviour
{
    public static Guild instance;
    public List<Player> roster;
    public List<Player> availableToday;
    public int mainRaidDay;
    public int farmRaidDay;
    public float guildRenown;
    public float guildCurrency;
    public float orderCooldown;
    public Player targetPlayer;
    public ManageState manageState;
    public bool seeHidden;
    public Sprite unknown;
    public bool itemToolTipHold;
    public bool guildToolTipHold;
    public int scheduleDay;
    public bool showPlayer;
    public List<RaidRoster> raidRoster;
    public RaidRoster schedulingRoster;
    public RaidRoster todaysRoster;

    private void Awake()
    {
        instance = this;
        guildCurrency = guildRenown = 10;
        RaidRoster r = Instantiate(GameObjectList.instance.raidRoster, transform);
        r.name = "Roster " + raidRoster.Count + 1;
        raidRoster.Add(r);
        r.dungeon = DungeonManager.instance.pve[0];
        GuildUI.instance.raidDropdown.AddOptions(new List<string> { "Monastery of the Midnight Order" });
    }
    public void NullifyTarget()
    {
        targetPlayer = null;
        Manage();
    }
    internal void ItemTooltipOff()
    {
        Utility.instance.TurnOff(GuildUI.instance.itemTooltip.gameObject);
    }

    internal void ItemTooltipOn(int id)
    {
        Item i = id == 0 ? targetPlayer.currentClass.head : id == 1 ? targetPlayer.currentClass.chest : id == 2 ? targetPlayer.currentClass.legs : id == 3 ? targetPlayer.currentClass.feet : id == 4 ? targetPlayer.currentClass.weapon : id == 5 && targetPlayer.currentClass.weapon.hands==Hands.Two? targetPlayer.currentClass.weapon :id == 5 ? targetPlayer.currentClass.offHand: targetPlayer.currentClass.trinket;
        Utility.instance.TurnOn(GuildUI.instance.itemTooltip.gameObject);
        GuildUI.instance.ItemTooltipInfo[0].text = i.itemName;
        GuildUI.instance.ItemTooltipInfo[1].text = i.health.ToString();
        GuildUI.instance.ItemTooltipInfo[2].text = i.mana.ToString();
        GuildUI.instance.ItemTooltipInfo[3].text =  i.damage.ToString();
        GuildUI.instance.ItemTooltipInfo[4].text =  i.crit.ToString();
        GuildUI.instance.ItemTooltipInfo[5].text =  i.defence.ToString();
        GuildUI.instance.ItemTooltipInfo[6].text = i.spellpower.ToString();
        GuildUI.instance.ItemTooltipInfo[7].text =  i.range.ToString();
        GuildUI.instance.ItemTooltipInfo[8].text =  i.haste.ToString();
        GuildUI.instance.ItemTooltipInfo[9].text = i.vamp.ToString();
        GuildUI.instance.ItemTooltipInfo[10].text = i.movement.ToString();
        GuildUI.instance.ItemTooltipInfo[11].text = i.score.ToString();
        GuildUI.instance.ItemTooltipInfo[12].text =i.flavor[0];
        GuildUI.instance.ItemTooltipInfo[13].text =i.flavor[1];
        GuildUI.instance.ItemTooltipInfo[14].text = i.flavor[2];
    }
    internal void GuildTooltipOff()
    {
        Utility.instance.TurnOff(GuildUI.instance.guildTooltip.gameObject);
    }

    internal void GuildTooltipOn(int id, Vector2 position)
    {
        if (id == 1) 
        {
            if (targetPlayer.traits.Count > 1) GuildTooltipOn(targetPlayer.traits[0].flavor,position);
            else GuildTooltipOn(new List<string> { "Player has no traits" }, position);
        }
        else if (id == 2) GuildTooltipOn(targetPlayer.traits[1].flavor, position);
        else if (id == 3) GuildTooltipOn(targetPlayer.traits[2].flavor, position);
    }
    internal void GuildTooltipOn(List<string> flavor, Vector2 position)
    {
        Utility.instance.TurnOn(GuildUI.instance.guildTooltip.gameObject);
        GuildUI.instance.guildTooltip.transform.position =new Vector2(position.x+200,position.y);
        foreach (TMP_Text t in GuildUI.instance.guildTooltipInfo) t.text = "";
        for (int i = 0; i < flavor.Count; i++) GuildUI.instance.guildTooltipInfo[i].text = flavor[i];
    }
    public void RecruitOrFireTarget()
    {
        if (!roster.Contains(targetPlayer))
        {
            if (guildCurrency >= Math.Floor(targetPlayer.currentSkill))
            {
                guildCurrency -= (float)Math.Floor(targetPlayer.currentSkill);
                targetPlayer.guildLoyalty = 60;
                roster.Add(targetPlayer);
                targetPlayer.transform.SetParent(GameManager.instance.guild.transform);
                CharacterList.instance.charactersInTheGame.Remove(targetPlayer);
            }
        }
        else
        {
            targetPlayer.guildLoyalty = 5;
            roster.Remove(targetPlayer);
            targetPlayer.transform.SetParent(GameManager.instance.freeAgent.transform);
            CharacterList.instance.charactersInTheGame.Add(targetPlayer);
            targetPlayer = null;
        }
        NullifyTarget();
    }
    public void ScheduleDropdown()
    {
        scheduleDay = GuildUI.instance.scheduleDropdown.value +1;
        schedulingRoster.roster.Clear();
        Manage();
    }
    public void RaidDropdown()
    {
        schedulingRoster.dungeon = DungeonManager.instance.pve[GuildUI.instance.raidDropdown.value];
        Manage();
    }
    public void OpenBackground()
    {
        Utility.instance.TurnOn(GuildUI.instance.backgroundInfoObject);
        GuildUI.instance.backgroundInfoText[0].text = schedulingRoster.dungeon.DungeonName;
        GuildUI.instance.backgroundInfoText[1].text = schedulingRoster.dungeon.description[0];
    }
    public void CloseBackground()
    {
        Utility.instance.TurnOff(GuildUI.instance.backgroundInfoObject);
    }

    public void Button1()
    {
        if (manageState == ManageState.Recruit) manageState = ManageState.View;
        else if (manageState == ManageState.View) manageState = ManageState.Recruit;
        else if (manageState == ManageState.Assign) manageState = ManageState.Recruit;
        else if (manageState == ManageState.Schedule) manageState = ManageState.Recruit;
        else if (manageState == ManageState.Upgrades) manageState = ManageState.Recruit;
        else if (manageState == ManageState.Codex) manageState =roster.Count>0? ManageState.View:ManageState.Recruit;
        targetPlayer = null;
        Manage();
    }
    public void Button2()
    {
        if (manageState == ManageState.Recruit) manageState = ManageState.Assign;
        else if (manageState == ManageState.View) manageState = ManageState.Assign;
        else if (manageState == ManageState.Assign) manageState = ManageState.View;
        else if (manageState == ManageState.Schedule) manageState = ManageState.View;
        else if (manageState == ManageState.Upgrades) manageState = ManageState.View;
        else if (manageState == ManageState.Codex) manageState = ManageState.Assign;
        targetPlayer = null;
        Manage();
    }
    public void Button3()
    {
        if (manageState == ManageState.Recruit) GoToScheduleDay();
        else if (manageState == ManageState.View) GoToScheduleDay();
        else if (manageState == ManageState.Assign) GoToScheduleDay();
        else if (manageState == ManageState.Schedule) manageState = ManageState.Assign;
        else if (manageState == ManageState.Upgrades) manageState = ManageState.Assign;
        else if (manageState == ManageState.Codex) GoToScheduleDay();
        targetPlayer = null;
        Manage();
    }
    public void Button4()
    {
        if (manageState == ManageState.Recruit) manageState = ManageState.Upgrades;
        else if (manageState == ManageState.View) manageState = ManageState.Upgrades;
        else if (manageState == ManageState.Assign) manageState = ManageState.Upgrades;
        else if (manageState == ManageState.Schedule) manageState = ManageState.Upgrades;
        else if (manageState == ManageState.Upgrades) GoToScheduleDay();
        else if (manageState == ManageState.Codex) manageState = ManageState.Upgrades;
        targetPlayer = null;
        Manage();
    }
    public void Button5()
    {
        manageState = ManageState.Codex;
        targetPlayer = null;
        Manage();
    }
    public void GoToScheduleDay()
    {
        schedulingRoster = null;
        foreach (RaidRoster r in raidRoster) if (!r.ready) schedulingRoster = r;
        if (schedulingRoster != null)
        {
            showPlayer = true;
            manageState = ManageState.Schedule;
            ScheduleDropdown();
        }
    }    

    public void Manage()
    {
        Utility.instance.TurnOff(GuildUI.instance.raidInformationObject);
        Utility.instance.TurnOff(GuildUI.instance.playerInformationObject);
        Utility.instance.TurnOff(GuildUI.instance.characterInformationObject);
        Utility.instance.TurnOff(GuildUI.instance.scheduleDropdown.gameObject);
        Utility.instance.TurnOff(GuildUI.instance.raidDropdown.gameObject);
        Utility.instance.TurnOff(GuildUI.instance.taskObject);
        Utility.instance.TurnOff(GuildUI.instance.characterButton[0].gameObject);
        //GET NAMES FOR BUTTONS
        List<string> rec = new List<string> { "View Roster", "Assign Tasks", "Schedule Raid", "Guild Upgrades" };
        List<string> vie = new List<string> { "Recruit", "Assign Tasks", "Schedule Raid", "Guild Upgrades" };
        List<string> ass = new List<string> { "Recruit", "View Roster", "Schedule Raid", "Guild Upgrades" };
        List<string> sched = new List<string> { "Recruit", "View Roster", "Assign Tasks", "Guild Upgrades" };
        List<string> up = new List<string> { "Recruit", "View Roster", "Assign Tasks", "Schedule Raid" };
        List<string> cod =roster.Count>0? new List<string> { "View Roster", "Assign Tasks", "Schedule Raid", "Guild Upgrades" } :new List<string> { "Recruit", "Assign Tasks", "Schedule Raid", "Guild Upgrades" };
        List<string> buttonNameList = manageState == ManageState.Recruit ? rec : manageState == ManageState.View ? vie : manageState == ManageState.Assign ? ass : manageState == ManageState.Schedule ? sched : manageState == ManageState.Upgrades ? up : cod;
        for (int i = 0; i < buttonNameList.Count; i++) GuildUI.instance.guildButton[i].GetComponentInChildren<TMP_Text>().text = buttonNameList[i];
        //Generic Stuff
        SortId(CharacterList.instance.charactersInTheGame);
        SortId(roster);
        GuildInfoShow();
        //Manage based on what state
        if (manageState == ManageState.Recruit || manageState == ManageState.View)
        {            
            Utility.instance.TurnOn(GuildUI.instance.characterButton[0].gameObject);
            foreach (GameObject g in GuildUI.instance.backgroundObject) Utility.instance.TurnOn(g);
            List<Player> list = manageState == ManageState.Recruit ? CharacterList.instance.charactersInTheGame : roster;
            ButtonStuff(list);
            for (int i = 0; i < list.Count; i++) GuildUI.instance.playerButtonCost[i].text = Mathf.Floor(list[i].currentSkill).ToString();
            if (targetPlayer == null) NoTargetInfo();
            else
            {
                Utility.instance.TurnOn(GuildUI.instance.playerBox);
                DisplayPlayerInfo();
                DisplayCharacterInfo();
            }
        }
        else if (manageState == ManageState.Assign)
        {
            foreach (GameObject g in GuildUI.instance.backgroundObject) Utility.instance.TurnOn(g);
            List<Player> list = manageState == ManageState.Recruit ? CharacterList.instance.charactersInTheGame : roster;
            ButtonStuff(list);
            for (int i = 0; i < list.Count; i++) GuildUI.instance.playerButtonCost[i].text = roster[i].task.ToString();
            if (targetPlayer == null) NoTargetInfo();
            else
            {
                Utility.instance.TurnOn(GuildUI.instance.playerBox);
                DisplayPlayerInfo();
                Utility.instance.TurnOn(GuildUI.instance.taskObject);
            }
        }    
        else if (manageState == ManageState.Schedule)
        {
            availableToday.Clear();
            Utility.instance.TurnOn(GuildUI.instance.scheduleDropdown.gameObject);
            Utility.instance.TurnOn(GuildUI.instance.raidDropdown.gameObject);
            foreach (GameObject g in GuildUI.instance.backgroundObject) Utility.instance.TurnOn(g);
            foreach (Player p in roster) if (p.availableDays.Contains(scheduleDay)) availableToday.Add(p);
            ButtonStuff(availableToday);
            for (int i = 0; i < availableToday.Count; i++) GuildUI.instance.playerButtonCost[i].text = schedulingRoster.roster.Contains(availableToday[i].currentClass) ? "Yes" : "No";
            DisplayRaids();
        }
    }
    private void DisplayRaids()
    {
        Utility.instance.TurnOn(GuildUI.instance.playerBox);
        Utility.instance.TurnOn(GuildUI.instance.raidInformationObject);
        ////////////////
        //RIGHT SIDE
        ////////////////
        GuildUI.instance.raidInfo[1].text = schedulingRoster.dungeon.DungeonName;
        //Load Player Info
        for (int i = 0; i < 7; i++)
        {
            if (schedulingRoster.roster.Count > i)
            {
                GuildUI.instance.raidInfo[i*2+2].text = schedulingRoster.roster[i].characterName;
                GuildUI.instance.raidInfo[i*2+3].text = Utility.instance.Class(schedulingRoster.roster[i]);
            }
            else
            {
                GuildUI.instance.raidInfo[i * 2 + 2].text = "";
                GuildUI.instance.raidInfo[i * 2 + 3].text = "";
            }
        }
        GuildUI.instance.raidInfo[16].text = $"{schedulingRoster.dungeon.encountersCompleted}/{schedulingRoster.dungeon.encounter.Count}";
        GuildUI.instance.raidInfo[17].text = $"{schedulingRoster.roster.Count}/{schedulingRoster.dungeon.maxPlayers}";
        GuildUI.instance.raidInfo[18].text = schedulingRoster.dungeon.dungeonCompleted>0? schedulingRoster.dungeon.dungeonCompleted.ToString():"";
        GuildUI.instance.raidInfo[19].text = schedulingRoster.dungeon.recommendedGearScore.ToString();
        GuildUI.instance.raidRoleImages[7].sprite = schedulingRoster.dungeon.dungeonCompleted > 0 ? GuildUI.instance.roleSprites[4]: GuildUI.instance.roleSprites[5];
        //Load Player Role Pic
        for (int i = 0; i < 7; i++) Utility.instance.TurnOff(GuildUI.instance.raidRoleImages[i].gameObject);
        for (int i = 0; i < 7; i++)
        {
            if (schedulingRoster.roster.Count > i)
            {
                Utility.instance.TurnOn(GuildUI.instance.raidRoleImages[i].gameObject);
                GuildUI.instance.raidRoleImages[i].sprite = Utility.instance.ReturnSpec(schedulingRoster.roster[i]) == Spec.Stalwart ? GuildUI.instance.roleSprites[0]:(Utility.instance.ReturnSpec(schedulingRoster.roster[i]) == Spec.Redemptive|| Utility.instance.ReturnSpec(schedulingRoster.roster[i]) == Spec.Tranquil)? GuildUI.instance.roleSprites[1] : Utility.instance.ReturnSpec(schedulingRoster.roster[i]) == Spec.Inspiring? GuildUI.instance.roleSprites[3]: GuildUI.instance.roleSprites[2];
            }
        }      
        ////////////////
        //LEFT SIDE
        ////////////////
        if (targetPlayer != null)
        {            
            if (showPlayer) DisplayPlayerInfo();
            else DisplayCharacterInfo();
            Utility.instance.TurnOn(GuildUI.instance.raidButtons[1].gameObject);
            Utility.instance.TurnOn(GuildUI.instance.raidButtons[2].gameObject);
            GuildUI.instance.raidButtons[1].GetComponentInChildren<TMP_Text>().text = showPlayer ? "Character" : "Player";
            GuildUI.instance.raidButtons[2].GetComponentInChildren<TMP_Text>().text = schedulingRoster.roster.Contains(targetPlayer.currentClass) ? "Remove from Raid" : "Add To Raid";
            GuildUI.instance.raidInfo[0].text = "";
        }
        else
        {
            Utility.instance.TurnOff(GuildUI.instance.raidButtons[1].gameObject);
            Utility.instance.TurnOff(GuildUI.instance.raidButtons[2].gameObject);
            GuildUI.instance.raidInfo[0].text = availableToday.Count == 0 ? "No One is Available Today\n\nSelect another day or Recruit more players" : "Please select a player to bring to the dungeon";
        }
    }
    private void DisplayCharacterInfo()
    {
        Utility.instance.TurnOn(GuildUI.instance.characterInformationObject);
        if (manageState == ManageState.Recruit || manageState == ManageState.View) GuildUI.instance.characterInformationObject.transform.localPosition = new Vector3(0, 0, 0);
        else GuildUI.instance.characterInformationObject.transform.localPosition = new Vector3(-570, 0, 0);
        GuildUI.instance.characterInfo[0].text = Utility.instance.Class(targetPlayer.currentClass);
        GuildUI.instance.characterInfo[1].text = Math.Floor(targetPlayer.currentSkill).ToString();
        GuildUI.instance.characterInfo[2].text = Utility.instance.SpecNameShort(targetPlayer.currentClass);
        GuildUI.instance.characterInfo[3].text = seeHidden || manageState != ManageState.Recruit ? $"{targetPlayer.currentClass.maxHealth.value}/{targetPlayer.currentClass.maxHealth.value}" : "???";
        GuildUI.instance.characterInfo[4].text = seeHidden || manageState != ManageState.Recruit ? $"{targetPlayer.currentClass.maxMana.value}/{targetPlayer.currentClass.maxMana.value}" : "???";
        GuildUI.instance.characterInfo[5].text = seeHidden || manageState != ManageState.Recruit ? targetPlayer.currentClass.damage.value.ToString() : "?";
        GuildUI.instance.characterInfo[6].text = seeHidden || manageState != ManageState.Recruit ? targetPlayer.currentClass.crit.value.ToString() : "?";
        GuildUI.instance.characterInfo[7].text = seeHidden || manageState != ManageState.Recruit ? targetPlayer.currentClass.defence.value.ToString() : "?";
        GuildUI.instance.characterInfo[8].text = seeHidden || manageState != ManageState.Recruit ? targetPlayer.currentClass.spellpower.value.ToString() : "?";
        int gs = targetPlayer.currentClass.head.score + targetPlayer.currentClass.chest.score + targetPlayer.currentClass.legs.score + targetPlayer.currentClass.feet.score + targetPlayer.currentClass.trinket.score + targetPlayer.currentClass.weapon.score + targetPlayer.currentClass.offHand.score;
        GuildUI.instance.characterInfo[9].text = seeHidden || manageState != ManageState.Recruit ? gs.ToString() : "???";
        GuildUI.instance.paperDollImages[0].sprite = !seeHidden && manageState == ManageState.Recruit ? unknown : targetPlayer.currentClass.head.pic;
        GuildUI.instance.paperDollImages[1].sprite = !seeHidden && manageState == ManageState.Recruit ? unknown : targetPlayer.currentClass.chest.pic;
        GuildUI.instance.paperDollImages[2].sprite = !seeHidden && manageState == ManageState.Recruit ? unknown : targetPlayer.currentClass.legs.pic;
        GuildUI.instance.paperDollImages[3].sprite = !seeHidden && manageState == ManageState.Recruit ? unknown : targetPlayer.currentClass.feet.pic;
        GuildUI.instance.paperDollImages[4].sprite = !seeHidden && manageState == ManageState.Recruit ? unknown : targetPlayer.currentClass.weapon.pic;
        GuildUI.instance.paperDollImages[5].sprite = !seeHidden && manageState == ManageState.Recruit ? unknown : targetPlayer.currentClass.weapon.hands == Hands.Two ? targetPlayer.currentClass.weapon.pic : targetPlayer.currentClass.offHand.pic;
        GuildUI.instance.paperDollImages[6].sprite = !seeHidden && manageState == ManageState.Recruit ? unknown : targetPlayer.currentClass.trinket.pic;
    }   

    private void DisplayPlayerInfo()
    {
        Utility.instance.TurnOn(GuildUI.instance.playerInformationObject);        
        GuildUI.instance.characterButton[0].GetComponentInChildren<TMP_Text>().text = manageState == ManageState.View ? "Fire" : "Recruit";
        if (targetPlayer.altClass != null) Utility.instance.TurnOn(GuildUI.instance.characterButton[1].gameObject);
        else Utility.instance.TurnOff(GuildUI.instance.characterButton[1].gameObject);
        GuildUI.instance.playerInfo[0].text = targetPlayer.playerName;
        List<string> d = new List<string> { "", "M", "Tu", "W", "Th", "F", "Sat", "Sun" };
        string days = "";
        for (int i = 0; i < targetPlayer.availableDays.Count; i++)
        {
            if (i == targetPlayer.availableDays.Count - 1) days += d[targetPlayer.availableDays[i]];
            else days += d[targetPlayer.availableDays[i]] + ", ";
        }
        GuildUI.instance.playerInfo[1].text = $"Available: {days}";
        GuildUI.instance.playerInfo[2].text = "Available Today: " + (targetPlayer.availableDays.Contains(TimeManagement.instance.day) ? "Yes" : "No");
        GuildUI.instance.playerInfo[3].text = manageState == ManageState.Recruit ? $"Cost: {Mathf.Floor(targetPlayer.currentSkill)}" : "";
        string a = "Ambition: ";
        a += seeHidden || manageState != ManageState.Recruit ? Math.Floor(targetPlayer.ambition) : "???";
        string b = "Guild Loyalty: ";
        b += seeHidden || manageState != ManageState.Recruit ? Math.Floor(targetPlayer.guildLoyalty) : "???";
        string c = "Shards: ";
        c += seeHidden || manageState != ManageState.Recruit ? Math.Floor(targetPlayer.enchantmentShards) : "???";
        GuildUI.instance.playerInfo[4].text = a;
        GuildUI.instance.playerInfo[5].text = b;
        GuildUI.instance.playerInfo[6].text = c;
        GuildUI.instance.playerInfo[7].text = !seeHidden && manageState == ManageState.Recruit ? "???" : targetPlayer.traits.Count > 0 ? targetPlayer.traits[0].traitName : "None";
        GuildUI.instance.playerInfo[8].text = !seeHidden && manageState == ManageState.Recruit ? "???" : targetPlayer.traits.Count > 1 ? targetPlayer.traits[1].traitName : "";
        GuildUI.instance.playerInfo[9].text = !seeHidden && manageState == ManageState.Recruit ? "???" : targetPlayer.traits.Count > 2 ? targetPlayer.traits[2].traitName : "";
        if (roster.Contains(targetPlayer)) GuildUI.instance.playerInfo[10].text = targetPlayer.task ==Task.None?"Task: None": $"Task: {targetPlayer.task} - {targetPlayer.timeOnTask} days";
        else GuildUI.instance.playerInfo[10].text = "";
    }

    public void GuildInfoShow()
    {
        GuildUI.instance.guildInfo[0].text = manageState == ManageState.Recruit ? "Recruit" :manageState == ManageState.View ?"View Roster":manageState == ManageState.Schedule ? "Schedule Raid":"Assign Tasks";
        GuildUI.instance.guildInfo[1].text = manageState == ManageState.Schedule ? "" : $"Guild Renown: {guildRenown}";
        GuildUI.instance.guildInfo[2].text = manageState == ManageState.Schedule ? "" : $"Guild Currency: {guildCurrency}";
    }
    public void AddRemoveFromRaid()
    {
        if (schedulingRoster.roster.Contains(targetPlayer.currentClass)) schedulingRoster.roster.Remove(targetPlayer.currentClass);
        else schedulingRoster.roster.Add(targetPlayer.currentClass);
        Manage();
    }
    public void PlayerCharacterShow()
    {
        if (showPlayer) showPlayer = false;
        else showPlayer = true;
        Manage();
    }

    private void ButtonStuff(List<Player> list)
    {
        foreach (Button b in GuildUI.instance.playerButton) Utility.instance.TurnOff(b.gameObject);
        for (int i = 0; i < list.Count; i++)
        {
            Utility.instance.TurnOn(GuildUI.instance.playerButton[i].gameObject);
            GuildUI.instance.playerButtonNames[i].text = list[i].playerName;
            GuildUI.instance.playerButtonClasses[i].text = Utility.instance.Class(list[i].currentClass);
        }
    }
    private void NoTargetInfo()
    {
        Utility.instance.TurnOff(GuildUI.instance.playerBox);
    }
    private void SortId(List<Player> list)
    {
        Player temp;
        for (int j = 0; j <= list.Count - 2; j++)
        {
            for (int i = 0; i <= list.Count - 2; i++)
            {
                if (list[i].currentClass.id > list[i + 1].currentClass.id)
                {
                    temp = list[i + 1];
                    list[i + 1] = list[i];
                    list[i] = temp;
                }
            }
        }
    }

    public List<Player> NotInDungeon(List<Character> inFight)
    {
        List<Player> notInFight = new List<Player> { };
        foreach (Player a in roster) if (!inFight.Contains(a.currentClass)) notInFight.Add(a);
        return notInFight;
    }
    public List<Player> NotInDungeon(List<Player> inFight)
    {
        List<Player> notInFight = new List<Player> { };
        foreach (Player a in roster) if (!inFight.Contains(a)) notInFight.Add(a);
        return notInFight;
    }

    internal void ButtonPress(int id)
    {
        targetPlayer = manageState == ManageState.Recruit ? CharacterList.instance.charactersInTheGame[id] : manageState == ManageState.Schedule?availableToday[id]: roster[id];
        Manage();
    }
    public void Assign(int id)
    {
        targetPlayer.task = (Task)id;
        Manage();
    }
    public void ChangeSpec()
    {
        targetPlayer.currentClass.ChangeSpec();
        targetPlayer.UpdateName();
        Manage();
    }
    public void SwitchCharacter()
    {
        targetPlayer.Switch();
        targetPlayer.UpdateName();
        Manage();
    }
}
