using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.EventSystems;

public class GuildTooltip : MonoBehaviour, IPointerExitHandler, IPointerEnterHandler, IPointerClickHandler
{
    public int id;
    public List<string> flavor;
    public bool generate;

    public void OnPointerClick(PointerEventData eventData)
    {
        if (generate)
        {
            if (id == 0 && Guild.instance.manageState != ManageState.Recruit) Guild.instance.GuildTooltipOn(flavor, transform.position);
            else if (id == 1 && (Guild.instance.seeHidden || Guild.instance.manageState != ManageState.Recruit)) Guild.instance.GuildTooltipOn(id, transform.position);
            else if (id == 2 && Guild.instance.target.traits.Count > 1 && (Guild.instance.seeHidden || Guild.instance.manageState != ManageState.Recruit)) Guild.instance.GuildTooltipOn(id, transform.position);
            else if (id == 3 && Guild.instance.target.traits.Count > 2 && (Guild.instance.seeHidden || Guild.instance.manageState != ManageState.Recruit)) Guild.instance.GuildTooltipOn(id, transform.position);
        }
        else Guild.instance.GuildTooltipOn(flavor, transform.position);
        Guild.instance.guildToolTipHold = true;
    }
    public void OnPointerEnter(PointerEventData eventData)
    {
        if (generate)
        {
            if(id == 0&& Guild.instance.manageState != ManageState.Recruit) Guild.instance.GuildTooltipOn(flavor, transform.position);
            else if(id ==1&& (Guild.instance.seeHidden ||Guild.instance.manageState!=ManageState.Recruit)) Guild.instance.GuildTooltipOn(id, transform.position);
            else if (id ==2 && Guild.instance.target.traits.Count>1 && (Guild.instance.seeHidden || Guild.instance.manageState != ManageState.Recruit)) Guild.instance.GuildTooltipOn(id, transform.position);
            else if (id == 3 && Guild.instance.target.traits.Count > 2 && (Guild.instance.seeHidden || Guild.instance.manageState != ManageState.Recruit)) Guild.instance.GuildTooltipOn(id, transform.position);
        }
        else Guild.instance.GuildTooltipOn(flavor,transform.position);
    }
    public void OnPointerExit(PointerEventData eventData)
    {
        if (!Guild.instance.guildToolTipHold) Guild.instance.GuildTooltipOff();
    }
}
