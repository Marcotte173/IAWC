using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using UnityEngine.EventSystems;
using TMPro;

public class ItemTooltip : MonoBehaviour, IPointerExitHandler, IPointerEnterHandler,IPointerClickHandler
{
    public int id;
    
    public void OnPointerClick(PointerEventData eventData)
    {
        if (Guild.instance.manageState == ManageState.View || (Guild.instance.manageState == ManageState.Recruit && Guild.instance.seeHidden)) Guild.instance.ItemTooltipOn(id);
        Guild.instance.itemToolTipHold = true;
    }
    public void OnPointerEnter(PointerEventData eventData)
    {
        if(Guild.instance.manageState==ManageState.View || (Guild.instance.manageState == ManageState.Recruit&& Guild.instance.seeHidden)) Guild.instance.ItemTooltipOn(id);
    }
    public void OnPointerExit(PointerEventData eventData)
    {
        if(!Guild.instance.itemToolTipHold) Guild.instance.ItemTooltipOff();
    }
}
